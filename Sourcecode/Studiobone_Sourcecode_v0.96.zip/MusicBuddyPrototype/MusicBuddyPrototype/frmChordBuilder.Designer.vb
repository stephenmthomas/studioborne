﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmChordBuilder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmChordBuilder))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbRoot = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cbQuick = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbSymbol = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbIntervals = New System.Windows.Forms.ComboBox()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmdShow = New System.Windows.Forms.Button()
        Me.chkAutoDisplay = New System.Windows.Forms.CheckBox()
        Me.chkOnTop = New System.Windows.Forms.CheckBox()
        Me.cmdSize = New System.Windows.Forms.Button()
        Me.cb1 = New System.Windows.Forms.CheckBox()
        Me.cb2 = New System.Windows.Forms.CheckBox()
        Me.cb4 = New System.Windows.Forms.CheckBox()
        Me.cb3 = New System.Windows.Forms.CheckBox()
        Me.cb8 = New System.Windows.Forms.CheckBox()
        Me.cb7 = New System.Windows.Forms.CheckBox()
        Me.cb6 = New System.Windows.Forms.CheckBox()
        Me.cb5 = New System.Windows.Forms.CheckBox()
        Me.cb12 = New System.Windows.Forms.CheckBox()
        Me.cb11 = New System.Windows.Forms.CheckBox()
        Me.cb10 = New System.Windows.Forms.CheckBox()
        Me.cb9 = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.lblShort = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.lblSpec = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.cb0 = New System.Windows.Forms.CheckBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Timer = New System.Windows.Forms.Timer(Me.components)
        Me.cmdShowChord = New System.Windows.Forms.Button()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.cb13 = New System.Windows.Forms.CheckBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.cb14 = New System.Windows.Forms.CheckBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.cb15 = New System.Windows.Forms.CheckBox()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.lbld13 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.cb24 = New System.Windows.Forms.CheckBox()
        Me.cb23 = New System.Windows.Forms.CheckBox()
        Me.cb22 = New System.Windows.Forms.CheckBox()
        Me.cb21 = New System.Windows.Forms.CheckBox()
        Me.cb20 = New System.Windows.Forms.CheckBox()
        Me.cb19 = New System.Windows.Forms.CheckBox()
        Me.cb18 = New System.Windows.Forms.CheckBox()
        Me.cb17 = New System.Windows.Forms.CheckBox()
        Me.cb16 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(4, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 14)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "ROOT:"
        '
        'cbRoot
        '
        Me.cbRoot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbRoot.FormattingEnabled = True
        Me.cbRoot.Items.AddRange(New Object() {"A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#"})
        Me.cbRoot.Location = New System.Drawing.Point(6, 21)
        Me.cbRoot.Name = "cbRoot"
        Me.cbRoot.Size = New System.Drawing.Size(43, 22)
        Me.cbRoot.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(55, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 14)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "CHORD TYPE:"
        '
        'cbQuick
        '
        Me.cbQuick.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbQuick.FormattingEnabled = True
        Me.cbQuick.Items.AddRange(New Object() {"Magic Chord", "Mu Chord", "Suspended Second", "Diminished Triad", "Half-Diminished Seventh", "Diminished Major Seventh", "Diminished Seventh", "Minor Triad", "Minor Seventh", "Lovely Little Chord*", "Minor Eleventh", "Minor Thirteenth", "Minor-Major Seventh", "Minor Ninth", "Minor Sixth", "Minor 7th Sharp 5th", "Flat Five", "Dom 7th Flat Five", "Augmented Sixth (French)", "Ninth Flat Fifth", "Major 7th Flat Five", "Major Triad", "Dominant Seventh", "Augmented Sixth (German)", "Dominant Minor 9th", "Dominant Ninth", "Dominant Eleventh", "Dominant Thirteenth", "Augmented Eleventh", "Dom 7th Sharp 9", "Dom 11th (Resolve)*", "Major Seventh", "Major Ninth", "Major Sixth Ninth", "Major Eleventh", "Major 9th Sharp 11th", "Major Thirteenth", "Lydian Chord", "Add 9", "Major Sixth", "Seven Six Chord", "Augmented Triad", "Augmented Seventh", "Dom 7th Sharp 5th", "Major 7th Sharp 5th", "Major 7th Sharp 11th", "So What Chord", "Dream Chord", "Suspended Fourth", "Dominant Sus 4th", "Augmented Sixth (Italy)", "Five (Power Chord)", "Elektra Chord", "Farben Chord", "Neopolitan Chord"})
        Me.cbQuick.Location = New System.Drawing.Point(55, 21)
        Me.cbQuick.Name = "cbQuick"
        Me.cbQuick.Size = New System.Drawing.Size(191, 22)
        Me.cbQuick.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(249, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 14)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "SYMBOL:"
        '
        'cbSymbol
        '
        Me.cbSymbol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbSymbol.FormattingEnabled = True
        Me.cbSymbol.Items.AddRange(New Object() {"mag", "mu", "sus2", "dim", "°7/m7b5", "°M7", "dim7", "min", "m7", "m7b9(add11)", "m11", "m13", "min/maj7", "m9", "m6", "m7#5", "b5", "7b5", "Fr+6", "9b5", "M7b5", "Δ/maj", "dom7/7th", "Ger+6", "7b9", "9", "11", "13", "aug11", "7#9", "7#9#11", "M7", "M9", "6add9", "M11", "maj9#11", "M13", "#11", "add9", "M6", "7/6", "aug", "aug7", "7#5", "M7#5", "M7#11", "sw", "drm", "sus4", "7sus4", "It+6", "5", "ekt", "frb", "neo"})
        Me.cbSymbol.Location = New System.Drawing.Point(252, 21)
        Me.cbSymbol.Name = "cbSymbol"
        Me.cbSymbol.Size = New System.Drawing.Size(110, 22)
        Me.cbSymbol.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(365, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 14)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "INTERVALS:"
        '
        'cbIntervals
        '
        Me.cbIntervals.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbIntervals.FormattingEnabled = True
        Me.cbIntervals.Items.AddRange(New Object() {"0,1,5,6,10,12,15,17", "0,2,4,7", "0,2,7", "0,3,6", "0,3,6,10", "0,3,6,11", "0,3,6,9", "0,3,7", "0,3,7,10", "0,3,7,10,13,17", "0,3,7,10,14,17", "0,3,7,10,14,17,21", "0,3,7,11", "0,3,7,11,14", "0,3,7,9", "0,3,8,10", "0,4,5", "0,4,6,10", "0,4,6,10", "0,4,6,10,14", "0,4,6,11", "0,4,7", "0,4,7,10", "0,4,7,10", "0,4,7,10,13", "0,4,7,10,14", "0,4,7,10,14,17", "0,4,7,10,14,17,21", "0,4,7,10,14,18", "0,4,7,10,15", "0,4,7,10,15,18", "0,4,7,11", "0,4,7,11,14", "0,4,7,11,14", "0,4,7,11,14,17", "0,4,7,11,14,18", "0,4,7,11,14,18,21", "0,4,7,11,18", "0,4,7,14", "0,4,7,9", "0,4,7,9,10", "0,4,8", "0,4,8,10", "0,4,8,10", "0,4,8,11", "0,4,8,11,18", "0,5,10,15,19", "0,5,6,7", "0,5,7", "0,5,7,10", "0,6,10", "0,7", "0,7,9,13,16", "0,8,11,16,21", "1,5,8"})
        Me.cbIntervals.Location = New System.Drawing.Point(368, 21)
        Me.cbIntervals.Name = "cbIntervals"
        Me.cbIntervals.Size = New System.Drawing.Size(118, 22)
        Me.cbIntervals.TabIndex = 8
        '
        'txtNotes
        '
        Me.txtNotes.Enabled = False
        Me.txtNotes.Location = New System.Drawing.Point(117, 65)
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.Size = New System.Drawing.Size(129, 20)
        Me.txtNotes.TabIndex = 28
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(114, 48)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 14)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "NOTES:"
        '
        'txtName
        '
        Me.txtName.Enabled = False
        Me.txtName.Location = New System.Drawing.Point(6, 65)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(105, 20)
        Me.txtName.TabIndex = 26
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 48)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 14)
        Me.Label5.TabIndex = 25
        Me.Label5.Text = "CHORD NAME:"
        '
        'cmdShow
        '
        Me.cmdShow.Location = New System.Drawing.Point(255, 65)
        Me.cmdShow.Name = "cmdShow"
        Me.cmdShow.Size = New System.Drawing.Size(50, 20)
        Me.cmdShow.TabIndex = 29
        Me.cmdShow.Text = "Show"
        Me.cmdShow.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdShow.UseVisualStyleBackColor = True
        '
        'chkAutoDisplay
        '
        Me.chkAutoDisplay.AutoSize = True
        Me.chkAutoDisplay.Checked = True
        Me.chkAutoDisplay.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAutoDisplay.Location = New System.Drawing.Point(311, 65)
        Me.chkAutoDisplay.Name = "chkAutoDisplay"
        Me.chkAutoDisplay.Size = New System.Drawing.Size(89, 18)
        Me.chkAutoDisplay.TabIndex = 30
        Me.chkAutoDisplay.Text = "Auto Show"
        Me.chkAutoDisplay.UseVisualStyleBackColor = True
        '
        'chkOnTop
        '
        Me.chkOnTop.AutoSize = True
        Me.chkOnTop.Location = New System.Drawing.Point(439, 500)
        Me.chkOnTop.Name = "chkOnTop"
        Me.chkOnTop.Size = New System.Drawing.Size(47, 18)
        Me.chkOnTop.TabIndex = 42
        Me.chkOnTop.Text = "Top"
        Me.chkOnTop.UseVisualStyleBackColor = True
        '
        'cmdSize
        '
        Me.cmdSize.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdSize.Location = New System.Drawing.Point(426, 65)
        Me.cmdSize.Name = "cmdSize"
        Me.cmdSize.Size = New System.Drawing.Size(60, 20)
        Me.cmdSize.TabIndex = 43
        Me.cmdSize.Text = "More"
        Me.cmdSize.UseVisualStyleBackColor = True
        '
        'cb1
        '
        Me.cb1.AutoSize = True
        Me.cb1.Location = New System.Drawing.Point(215, 133)
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(40, 18)
        Me.cb1.TabIndex = 44
        Me.cb1.Text = "01"
        Me.cb1.UseVisualStyleBackColor = True
        '
        'cb2
        '
        Me.cb2.AutoSize = True
        Me.cb2.Location = New System.Drawing.Point(215, 148)
        Me.cb2.Name = "cb2"
        Me.cb2.Size = New System.Drawing.Size(40, 18)
        Me.cb2.TabIndex = 45
        Me.cb2.Text = "02"
        Me.cb2.UseVisualStyleBackColor = True
        '
        'cb4
        '
        Me.cb4.AutoSize = True
        Me.cb4.Location = New System.Drawing.Point(215, 178)
        Me.cb4.Name = "cb4"
        Me.cb4.Size = New System.Drawing.Size(40, 18)
        Me.cb4.TabIndex = 47
        Me.cb4.Text = "04"
        Me.cb4.UseVisualStyleBackColor = True
        '
        'cb3
        '
        Me.cb3.AutoSize = True
        Me.cb3.Location = New System.Drawing.Point(215, 163)
        Me.cb3.Name = "cb3"
        Me.cb3.Size = New System.Drawing.Size(40, 18)
        Me.cb3.TabIndex = 46
        Me.cb3.Text = "03"
        Me.cb3.UseVisualStyleBackColor = True
        '
        'cb8
        '
        Me.cb8.AutoSize = True
        Me.cb8.Location = New System.Drawing.Point(215, 238)
        Me.cb8.Name = "cb8"
        Me.cb8.Size = New System.Drawing.Size(40, 18)
        Me.cb8.TabIndex = 51
        Me.cb8.Text = "08"
        Me.cb8.UseVisualStyleBackColor = True
        '
        'cb7
        '
        Me.cb7.AutoSize = True
        Me.cb7.Location = New System.Drawing.Point(215, 223)
        Me.cb7.Name = "cb7"
        Me.cb7.Size = New System.Drawing.Size(40, 18)
        Me.cb7.TabIndex = 50
        Me.cb7.Text = "07"
        Me.cb7.UseVisualStyleBackColor = True
        '
        'cb6
        '
        Me.cb6.AutoSize = True
        Me.cb6.Location = New System.Drawing.Point(215, 208)
        Me.cb6.Name = "cb6"
        Me.cb6.Size = New System.Drawing.Size(40, 18)
        Me.cb6.TabIndex = 49
        Me.cb6.Text = "06"
        Me.cb6.UseVisualStyleBackColor = True
        '
        'cb5
        '
        Me.cb5.AutoSize = True
        Me.cb5.Location = New System.Drawing.Point(215, 193)
        Me.cb5.Name = "cb5"
        Me.cb5.Size = New System.Drawing.Size(40, 18)
        Me.cb5.TabIndex = 48
        Me.cb5.Text = "05"
        Me.cb5.UseVisualStyleBackColor = True
        '
        'cb12
        '
        Me.cb12.AutoSize = True
        Me.cb12.Location = New System.Drawing.Point(215, 298)
        Me.cb12.Name = "cb12"
        Me.cb12.Size = New System.Drawing.Size(40, 18)
        Me.cb12.TabIndex = 55
        Me.cb12.Text = "12"
        Me.cb12.UseVisualStyleBackColor = True
        '
        'cb11
        '
        Me.cb11.AutoSize = True
        Me.cb11.Location = New System.Drawing.Point(215, 283)
        Me.cb11.Name = "cb11"
        Me.cb11.Size = New System.Drawing.Size(40, 18)
        Me.cb11.TabIndex = 54
        Me.cb11.Text = "11"
        Me.cb11.UseVisualStyleBackColor = True
        '
        'cb10
        '
        Me.cb10.AutoSize = True
        Me.cb10.Location = New System.Drawing.Point(215, 268)
        Me.cb10.Name = "cb10"
        Me.cb10.Size = New System.Drawing.Size(40, 18)
        Me.cb10.TabIndex = 53
        Me.cb10.Text = "10"
        Me.cb10.UseVisualStyleBackColor = True
        '
        'cb9
        '
        Me.cb9.AutoSize = True
        Me.cb9.Location = New System.Drawing.Point(215, 253)
        Me.cb9.Name = "cb9"
        Me.cb9.Size = New System.Drawing.Size(40, 18)
        Me.cb9.TabIndex = 52
        Me.cb9.Text = "09"
        Me.cb9.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Courier New", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(196, 99)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 16)
        Me.Label6.TabIndex = 56
        Me.Label6.Text = "Semitone"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Courier New", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(35, 99)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(151, 20)
        Me.Label7.TabIndex = 57
        Me.Label7.Text = "Perfect Interval"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Courier New", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(287, 99)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(176, 16)
        Me.Label8.TabIndex = 58
        Me.Label8.Text = "Diminished/Augmented"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label10
        '
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(20, 119)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(128, 17)
        Me.Label10.TabIndex = 59
        Me.Label10.Text = "Unison"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Teal
        Me.Label11.Location = New System.Drawing.Point(155, 119)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(21, 14)
        Me.Label11.TabIndex = 60
        Me.Label11.Text = "P1"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.Teal
        Me.Label12.Location = New System.Drawing.Point(155, 134)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(21, 14)
        Me.Label12.TabIndex = 62
        Me.Label12.Text = "m2"
        '
        'Label13
        '
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(20, 134)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(128, 17)
        Me.Label13.TabIndex = 61
        Me.Label13.Text = "Minor Second"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.Teal
        Me.Label14.Location = New System.Drawing.Point(155, 150)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(21, 14)
        Me.Label14.TabIndex = 64
        Me.Label14.Text = "M2"
        '
        'Label15
        '
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(20, 150)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(128, 17)
        Me.Label15.TabIndex = 63
        Me.Label15.Text = "Major Second"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Teal
        Me.Label16.Location = New System.Drawing.Point(155, 165)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(21, 14)
        Me.Label16.TabIndex = 66
        Me.Label16.Text = "m3"
        '
        'Label17
        '
        Me.Label17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label17.Location = New System.Drawing.Point(20, 165)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(128, 17)
        Me.Label17.TabIndex = 65
        Me.Label17.Text = "Minor Third"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.Color.Teal
        Me.Label18.Location = New System.Drawing.Point(155, 178)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(21, 14)
        Me.Label18.TabIndex = 68
        Me.Label18.Text = "M3"
        '
        'Label19
        '
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(20, 179)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(128, 17)
        Me.Label19.TabIndex = 67
        Me.Label19.Text = "Major Third"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.ForeColor = System.Drawing.Color.Teal
        Me.Label20.Location = New System.Drawing.Point(155, 194)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(21, 14)
        Me.Label20.TabIndex = 70
        Me.Label20.Text = "P4"
        '
        'Label21
        '
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(19, 195)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(128, 17)
        Me.Label21.TabIndex = 69
        Me.Label21.Text = "Perfect Fourth"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.Color.Teal
        Me.Label22.Location = New System.Drawing.Point(155, 209)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(21, 14)
        Me.Label22.TabIndex = 72
        Me.Label22.Text = "A4"
        '
        'Label23
        '
        Me.Label23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(20, 209)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(128, 17)
        Me.Label23.TabIndex = 71
        Me.Label23.Text = "Tritone"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.Teal
        Me.Label24.Location = New System.Drawing.Point(155, 239)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(21, 14)
        Me.Label24.TabIndex = 74
        Me.Label24.Text = "m6"
        '
        'Label25
        '
        Me.Label25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label25.Location = New System.Drawing.Point(20, 239)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(128, 17)
        Me.Label25.TabIndex = 73
        Me.Label25.Text = "Minor Sixth"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.Teal
        Me.Label26.Location = New System.Drawing.Point(155, 254)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(21, 14)
        Me.Label26.TabIndex = 76
        Me.Label26.Text = "M6"
        '
        'Label27
        '
        Me.Label27.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label27.Location = New System.Drawing.Point(20, 254)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(128, 17)
        Me.Label27.TabIndex = 75
        Me.Label27.Text = "Major Sixth"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.ForeColor = System.Drawing.Color.Teal
        Me.Label28.Location = New System.Drawing.Point(155, 269)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(21, 14)
        Me.Label28.TabIndex = 78
        Me.Label28.Text = "m7"
        '
        'Label29
        '
        Me.Label29.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label29.Location = New System.Drawing.Point(20, 269)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(128, 17)
        Me.Label29.TabIndex = 77
        Me.Label29.Text = "Minor Seventh"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.ForeColor = System.Drawing.Color.Teal
        Me.Label30.Location = New System.Drawing.Point(155, 284)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(21, 14)
        Me.Label30.TabIndex = 80
        Me.Label30.Text = "M7"
        '
        'Label31
        '
        Me.Label31.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label31.Location = New System.Drawing.Point(20, 284)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(128, 17)
        Me.Label31.TabIndex = 79
        Me.Label31.Text = "Major Seventh"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.Color.Teal
        Me.Label32.Location = New System.Drawing.Point(154, 299)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(21, 14)
        Me.Label32.TabIndex = 82
        Me.Label32.Text = "P8"
        '
        'Label33
        '
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(19, 299)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(128, 17)
        Me.Label33.TabIndex = 81
        Me.Label33.Text = "Perfect Octave"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.ForeColor = System.Drawing.Color.Olive
        Me.Label34.Location = New System.Drawing.Point(293, 284)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(21, 14)
        Me.Label34.TabIndex = 94
        Me.Label34.Text = "d8"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.ForeColor = System.Drawing.Color.Olive
        Me.Label35.Location = New System.Drawing.Point(293, 269)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(21, 14)
        Me.Label35.TabIndex = 93
        Me.Label35.Text = "A6"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ForeColor = System.Drawing.Color.Olive
        Me.Label36.Location = New System.Drawing.Point(293, 254)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(21, 14)
        Me.Label36.TabIndex = 92
        Me.Label36.Text = "d7"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.ForeColor = System.Drawing.Color.Olive
        Me.Label37.Location = New System.Drawing.Point(293, 239)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(21, 14)
        Me.Label37.TabIndex = 91
        Me.Label37.Text = "A5"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.ForeColor = System.Drawing.Color.Olive
        Me.Label38.Location = New System.Drawing.Point(293, 224)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(21, 14)
        Me.Label38.TabIndex = 90
        Me.Label38.Text = "d6"
        '
        'lblShort
        '
        Me.lblShort.AutoSize = True
        Me.lblShort.ForeColor = System.Drawing.Color.Olive
        Me.lblShort.Location = New System.Drawing.Point(293, 209)
        Me.lblShort.Name = "lblShort"
        Me.lblShort.Size = New System.Drawing.Size(21, 14)
        Me.lblShort.TabIndex = 89
        Me.lblShort.Text = "d5"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.ForeColor = System.Drawing.Color.Olive
        Me.Label40.Location = New System.Drawing.Point(293, 194)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(21, 14)
        Me.Label40.TabIndex = 88
        Me.Label40.Text = "A3"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.ForeColor = System.Drawing.Color.Olive
        Me.Label41.Location = New System.Drawing.Point(293, 179)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(21, 14)
        Me.Label41.TabIndex = 87
        Me.Label41.Text = "d4"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.ForeColor = System.Drawing.Color.Olive
        Me.Label42.Location = New System.Drawing.Point(293, 165)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(21, 14)
        Me.Label42.TabIndex = 86
        Me.Label42.Text = "A2"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.ForeColor = System.Drawing.Color.Olive
        Me.Label43.Location = New System.Drawing.Point(293, 150)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(21, 14)
        Me.Label43.TabIndex = 85
        Me.Label43.Text = "d3"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.ForeColor = System.Drawing.Color.Olive
        Me.Label44.Location = New System.Drawing.Point(293, 134)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(21, 14)
        Me.Label44.TabIndex = 84
        Me.Label44.Text = "A1"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.ForeColor = System.Drawing.Color.Olive
        Me.Label45.Location = New System.Drawing.Point(293, 119)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(21, 14)
        Me.Label45.TabIndex = 83
        Me.Label45.Text = "d2"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label46.Location = New System.Drawing.Point(325, 284)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(126, 14)
        Me.Label46.TabIndex = 106
        Me.Label46.Text = "Diminished Octave"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label47.Location = New System.Drawing.Point(325, 269)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(112, 14)
        Me.Label47.TabIndex = 105
        Me.Label47.Text = "Augmented Sixth"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label48.Location = New System.Drawing.Point(325, 254)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(133, 14)
        Me.Label48.TabIndex = 104
        Me.Label48.Text = "Diminished Seventh"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label49.Location = New System.Drawing.Point(325, 239)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(112, 14)
        Me.Label49.TabIndex = 103
        Me.Label49.Text = "Augmented Fifth"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label50.Location = New System.Drawing.Point(325, 224)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(119, 14)
        Me.Label50.TabIndex = 102
        Me.Label50.Text = "Diminished Sixth"
        '
        'lblSpec
        '
        Me.lblSpec.AutoSize = True
        Me.lblSpec.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblSpec.Location = New System.Drawing.Point(325, 209)
        Me.lblSpec.Name = "lblSpec"
        Me.lblSpec.Size = New System.Drawing.Size(119, 14)
        Me.lblSpec.TabIndex = 101
        Me.lblSpec.Text = "Diminished Fifth"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label52.Location = New System.Drawing.Point(325, 194)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(112, 14)
        Me.Label52.TabIndex = 100
        Me.Label52.Text = "Augmented Third"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label53.Location = New System.Drawing.Point(325, 179)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(126, 14)
        Me.Label53.TabIndex = 99
        Me.Label53.Text = "Diminished Fourth"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label54.Location = New System.Drawing.Point(325, 165)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(119, 14)
        Me.Label54.TabIndex = 98
        Me.Label54.Text = "Augmented Second"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label55.Location = New System.Drawing.Point(325, 150)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(119, 14)
        Me.Label55.TabIndex = 97
        Me.Label55.Text = "Diminished Third"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label56.Location = New System.Drawing.Point(325, 134)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(119, 14)
        Me.Label56.TabIndex = 96
        Me.Label56.Text = "Augmented Unison"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label57.Location = New System.Drawing.Point(325, 119)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(126, 14)
        Me.Label57.TabIndex = 95
        Me.Label57.Text = "Diminished Second"
        '
        'cb0
        '
        Me.cb0.AutoSize = True
        Me.cb0.Location = New System.Drawing.Point(215, 118)
        Me.cb0.Name = "cb0"
        Me.cb0.Size = New System.Drawing.Size(40, 18)
        Me.cb0.TabIndex = 107
        Me.cb0.Text = "00"
        Me.cb0.UseVisualStyleBackColor = True
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.ForeColor = System.Drawing.Color.Teal
        Me.Label58.Location = New System.Drawing.Point(155, 224)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(21, 14)
        Me.Label58.TabIndex = 109
        Me.Label58.Text = "P5"
        '
        'Label59
        '
        Me.Label59.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label59.Location = New System.Drawing.Point(20, 224)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(128, 17)
        Me.Label59.TabIndex = 108
        Me.Label59.Text = "Perfect Fifth"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label60.Location = New System.Drawing.Point(325, 299)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(126, 14)
        Me.Label60.TabIndex = 111
        Me.Label60.Text = "Augmented Seventh"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.ForeColor = System.Drawing.Color.Olive
        Me.Label61.Location = New System.Drawing.Point(293, 299)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(21, 14)
        Me.Label61.TabIndex = 110
        Me.Label61.Text = "A7"
        '
        'Timer
        '
        Me.Timer.Enabled = True
        Me.Timer.Interval = 5000
        '
        'cmdShowChord
        '
        Me.cmdShowChord.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdShowChord.Location = New System.Drawing.Point(178, 497)
        Me.cmdShowChord.Name = "cmdShowChord"
        Me.cmdShowChord.Size = New System.Drawing.Size(116, 21)
        Me.cmdShowChord.TabIndex = 112
        Me.cmdShowChord.Text = "Show Chord"
        Me.cmdShowChord.UseVisualStyleBackColor = True
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label39.Location = New System.Drawing.Point(325, 314)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(119, 14)
        Me.Label39.TabIndex = 117
        Me.Label39.Text = "Augmented Octave"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.ForeColor = System.Drawing.Color.Olive
        Me.Label51.Location = New System.Drawing.Point(293, 314)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(21, 14)
        Me.Label51.TabIndex = 116
        Me.Label51.Text = "A8"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.ForeColor = System.Drawing.Color.Teal
        Me.Label62.Location = New System.Drawing.Point(154, 314)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(21, 14)
        Me.Label62.TabIndex = 115
        Me.Label62.Text = "m9"
        '
        'Label63
        '
        Me.Label63.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label63.Location = New System.Drawing.Point(19, 314)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(128, 17)
        Me.Label63.TabIndex = 114
        Me.Label63.Text = "Minor Ninth"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cb13
        '
        Me.cb13.AutoSize = True
        Me.cb13.Location = New System.Drawing.Point(215, 313)
        Me.cb13.Name = "cb13"
        Me.cb13.Size = New System.Drawing.Size(40, 18)
        Me.cb13.TabIndex = 113
        Me.cb13.Text = "13"
        Me.cb13.UseVisualStyleBackColor = True
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label64.Location = New System.Drawing.Point(325, 329)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(119, 14)
        Me.Label64.TabIndex = 122
        Me.Label64.Text = "Diminished Tenth"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.ForeColor = System.Drawing.Color.Olive
        Me.Label65.Location = New System.Drawing.Point(293, 329)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(28, 14)
        Me.Label65.TabIndex = 121
        Me.Label65.Text = "d10"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.ForeColor = System.Drawing.Color.Teal
        Me.Label66.Location = New System.Drawing.Point(154, 329)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(21, 14)
        Me.Label66.TabIndex = 120
        Me.Label66.Text = "M9"
        '
        'Label67
        '
        Me.Label67.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label67.Location = New System.Drawing.Point(19, 329)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(128, 17)
        Me.Label67.TabIndex = 119
        Me.Label67.Text = "Major Ninth"
        Me.Label67.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cb14
        '
        Me.cb14.AutoSize = True
        Me.cb14.Location = New System.Drawing.Point(215, 328)
        Me.cb14.Name = "cb14"
        Me.cb14.Size = New System.Drawing.Size(40, 18)
        Me.cb14.TabIndex = 118
        Me.cb14.Text = "14"
        Me.cb14.UseVisualStyleBackColor = True
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.ForeColor = System.Drawing.Color.Teal
        Me.Label68.Location = New System.Drawing.Point(154, 449)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(28, 14)
        Me.Label68.TabIndex = 177
        Me.Label68.Text = "m14"
        '
        'Label69
        '
        Me.Label69.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label69.Location = New System.Drawing.Point(18, 449)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(128, 17)
        Me.Label69.TabIndex = 176
        Me.Label69.Text = "Minor Fourteenth"
        Me.Label69.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cb15
        '
        Me.cb15.AutoSize = True
        Me.cb15.Location = New System.Drawing.Point(215, 343)
        Me.cb15.Name = "cb15"
        Me.cb15.Size = New System.Drawing.Size(40, 18)
        Me.cb15.TabIndex = 175
        Me.cb15.Text = "15"
        Me.cb15.UseVisualStyleBackColor = True
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label71.Location = New System.Drawing.Point(325, 479)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(147, 14)
        Me.Label71.TabIndex = 173
        Me.Label71.Text = "Augmented Fourteenth"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label72.Location = New System.Drawing.Point(325, 464)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(147, 14)
        Me.Label72.TabIndex = 172
        Me.Label72.Text = "Diminished Fifteenth"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label73.Location = New System.Drawing.Point(325, 449)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(147, 14)
        Me.Label73.TabIndex = 171
        Me.Label73.Text = "Augmented Thirteenth"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label74.Location = New System.Drawing.Point(325, 434)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(154, 14)
        Me.Label74.TabIndex = 170
        Me.Label74.Text = "Diminished Fourteenth"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label75.Location = New System.Drawing.Point(325, 419)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(126, 14)
        Me.Label75.TabIndex = 169
        Me.Label75.Text = "Augmented Twelfth"
        '
        'lbld13
        '
        Me.lbld13.AutoSize = True
        Me.lbld13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lbld13.Location = New System.Drawing.Point(325, 404)
        Me.lbld13.Name = "lbld13"
        Me.lbld13.Size = New System.Drawing.Size(154, 14)
        Me.lbld13.TabIndex = 168
        Me.lbld13.Text = "Diminished Thirteenth"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label77.Location = New System.Drawing.Point(325, 390)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(133, 14)
        Me.Label77.TabIndex = 167
        Me.Label77.Text = "Diminished Twelfth"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label78.Location = New System.Drawing.Point(325, 375)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(112, 14)
        Me.Label78.TabIndex = 166
        Me.Label78.Text = "Augmented Tenth"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label79.Location = New System.Drawing.Point(325, 359)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(140, 14)
        Me.Label79.TabIndex = 165
        Me.Label79.Text = "Diminished Eleventh"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label80.Location = New System.Drawing.Point(325, 344)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(112, 14)
        Me.Label80.TabIndex = 164
        Me.Label80.Text = "Augmented Ninth"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.ForeColor = System.Drawing.Color.Olive
        Me.Label82.Location = New System.Drawing.Point(293, 479)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(28, 14)
        Me.Label82.TabIndex = 162
        Me.Label82.Text = "A14"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.ForeColor = System.Drawing.Color.Olive
        Me.Label83.Location = New System.Drawing.Point(293, 464)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(28, 14)
        Me.Label83.TabIndex = 161
        Me.Label83.Text = "d15"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.ForeColor = System.Drawing.Color.Olive
        Me.Label84.Location = New System.Drawing.Point(293, 449)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(28, 14)
        Me.Label84.TabIndex = 160
        Me.Label84.Text = "A13"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.ForeColor = System.Drawing.Color.Olive
        Me.Label85.Location = New System.Drawing.Point(293, 434)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(28, 14)
        Me.Label85.TabIndex = 159
        Me.Label85.Text = "d14"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.ForeColor = System.Drawing.Color.Olive
        Me.Label86.Location = New System.Drawing.Point(293, 419)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(28, 14)
        Me.Label86.TabIndex = 158
        Me.Label86.Text = "A12"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.ForeColor = System.Drawing.Color.Olive
        Me.Label87.Location = New System.Drawing.Point(293, 404)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(28, 14)
        Me.Label87.TabIndex = 157
        Me.Label87.Text = "d13"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.ForeColor = System.Drawing.Color.Olive
        Me.Label88.Location = New System.Drawing.Point(293, 390)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(28, 14)
        Me.Label88.TabIndex = 156
        Me.Label88.Text = "d12"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.ForeColor = System.Drawing.Color.Olive
        Me.Label89.Location = New System.Drawing.Point(293, 375)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(28, 14)
        Me.Label89.TabIndex = 155
        Me.Label89.Text = "A10"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.ForeColor = System.Drawing.Color.Olive
        Me.Label90.Location = New System.Drawing.Point(293, 359)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(28, 14)
        Me.Label90.TabIndex = 154
        Me.Label90.Text = "d11"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.ForeColor = System.Drawing.Color.Olive
        Me.Label91.Location = New System.Drawing.Point(293, 344)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(21, 14)
        Me.Label91.TabIndex = 153
        Me.Label91.Text = "A9"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.ForeColor = System.Drawing.Color.Teal
        Me.Label94.Location = New System.Drawing.Point(154, 479)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(28, 14)
        Me.Label94.TabIndex = 150
        Me.Label94.Text = "P16"
        '
        'Label95
        '
        Me.Label95.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label95.Location = New System.Drawing.Point(19, 479)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(128, 17)
        Me.Label95.TabIndex = 149
        Me.Label95.Text = "Double Octave"
        Me.Label95.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.ForeColor = System.Drawing.Color.Teal
        Me.Label96.Location = New System.Drawing.Point(154, 464)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(28, 14)
        Me.Label96.TabIndex = 148
        Me.Label96.Text = "M14"
        '
        'Label97
        '
        Me.Label97.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label97.Location = New System.Drawing.Point(19, 464)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(128, 17)
        Me.Label97.TabIndex = 147
        Me.Label97.Text = "Major Fourteenth"
        Me.Label97.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.ForeColor = System.Drawing.Color.Teal
        Me.Label98.Location = New System.Drawing.Point(154, 434)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(28, 14)
        Me.Label98.TabIndex = 146
        Me.Label98.Text = "M13"
        '
        'Label99
        '
        Me.Label99.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label99.Location = New System.Drawing.Point(19, 434)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(128, 17)
        Me.Label99.TabIndex = 145
        Me.Label99.Text = "Major Thirteenth"
        Me.Label99.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.ForeColor = System.Drawing.Color.Teal
        Me.Label100.Location = New System.Drawing.Point(154, 420)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(28, 14)
        Me.Label100.TabIndex = 144
        Me.Label100.Text = "m13"
        '
        'Label101
        '
        Me.Label101.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label101.Location = New System.Drawing.Point(19, 420)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(128, 17)
        Me.Label101.TabIndex = 143
        Me.Label101.Text = "Minor Thirteenth"
        Me.Label101.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.ForeColor = System.Drawing.Color.Teal
        Me.Label102.Location = New System.Drawing.Point(154, 403)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(28, 14)
        Me.Label102.TabIndex = 142
        Me.Label102.Text = "P12"
        '
        'Label103
        '
        Me.Label103.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label103.Location = New System.Drawing.Point(18, 404)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(128, 17)
        Me.Label103.TabIndex = 141
        Me.Label103.Text = "Perfect Twelfth"
        Me.Label103.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.ForeColor = System.Drawing.Color.Teal
        Me.Label104.Location = New System.Drawing.Point(154, 390)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(28, 14)
        Me.Label104.TabIndex = 140
        Me.Label104.Text = "A11"
        '
        'Label105
        '
        Me.Label105.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label105.Location = New System.Drawing.Point(18, 390)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(128, 17)
        Me.Label105.TabIndex = 139
        Me.Label105.Text = "Augmented Eleventh"
        Me.Label105.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.ForeColor = System.Drawing.Color.Teal
        Me.Label106.Location = New System.Drawing.Point(154, 375)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(28, 14)
        Me.Label106.TabIndex = 138
        Me.Label106.Text = "P11"
        '
        'Label107
        '
        Me.Label107.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label107.Location = New System.Drawing.Point(18, 375)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(128, 17)
        Me.Label107.TabIndex = 137
        Me.Label107.Text = "Perfect Eleventh"
        Me.Label107.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.ForeColor = System.Drawing.Color.Teal
        Me.Label108.Location = New System.Drawing.Point(154, 359)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(28, 14)
        Me.Label108.TabIndex = 136
        Me.Label108.Text = "M10"
        '
        'Label109
        '
        Me.Label109.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label109.Location = New System.Drawing.Point(19, 359)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(128, 17)
        Me.Label109.TabIndex = 135
        Me.Label109.Text = "Major Tenth"
        Me.Label109.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.ForeColor = System.Drawing.Color.Teal
        Me.Label110.Location = New System.Drawing.Point(154, 344)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(28, 14)
        Me.Label110.TabIndex = 134
        Me.Label110.Text = "m10"
        '
        'Label111
        '
        Me.Label111.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label111.Location = New System.Drawing.Point(19, 344)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(128, 17)
        Me.Label111.TabIndex = 133
        Me.Label111.Text = "Minor Tenth"
        Me.Label111.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cb24
        '
        Me.cb24.AutoSize = True
        Me.cb24.Location = New System.Drawing.Point(215, 478)
        Me.cb24.Name = "cb24"
        Me.cb24.Size = New System.Drawing.Size(40, 18)
        Me.cb24.TabIndex = 131
        Me.cb24.Text = "24"
        Me.cb24.UseVisualStyleBackColor = True
        '
        'cb23
        '
        Me.cb23.AutoSize = True
        Me.cb23.Location = New System.Drawing.Point(215, 463)
        Me.cb23.Name = "cb23"
        Me.cb23.Size = New System.Drawing.Size(40, 18)
        Me.cb23.TabIndex = 130
        Me.cb23.Text = "23"
        Me.cb23.UseVisualStyleBackColor = True
        '
        'cb22
        '
        Me.cb22.AutoSize = True
        Me.cb22.Location = New System.Drawing.Point(215, 448)
        Me.cb22.Name = "cb22"
        Me.cb22.Size = New System.Drawing.Size(40, 18)
        Me.cb22.TabIndex = 129
        Me.cb22.Text = "22"
        Me.cb22.UseVisualStyleBackColor = True
        '
        'cb21
        '
        Me.cb21.AutoSize = True
        Me.cb21.Location = New System.Drawing.Point(215, 433)
        Me.cb21.Name = "cb21"
        Me.cb21.Size = New System.Drawing.Size(40, 18)
        Me.cb21.TabIndex = 128
        Me.cb21.Text = "21"
        Me.cb21.UseVisualStyleBackColor = True
        '
        'cb20
        '
        Me.cb20.AutoSize = True
        Me.cb20.Location = New System.Drawing.Point(215, 418)
        Me.cb20.Name = "cb20"
        Me.cb20.Size = New System.Drawing.Size(40, 18)
        Me.cb20.TabIndex = 127
        Me.cb20.Text = "20"
        Me.cb20.UseVisualStyleBackColor = True
        '
        'cb19
        '
        Me.cb19.AutoSize = True
        Me.cb19.Location = New System.Drawing.Point(215, 403)
        Me.cb19.Name = "cb19"
        Me.cb19.Size = New System.Drawing.Size(40, 18)
        Me.cb19.TabIndex = 126
        Me.cb19.Text = "19"
        Me.cb19.UseVisualStyleBackColor = True
        '
        'cb18
        '
        Me.cb18.AutoSize = True
        Me.cb18.Location = New System.Drawing.Point(215, 388)
        Me.cb18.Name = "cb18"
        Me.cb18.Size = New System.Drawing.Size(40, 18)
        Me.cb18.TabIndex = 125
        Me.cb18.Text = "18"
        Me.cb18.UseVisualStyleBackColor = True
        '
        'cb17
        '
        Me.cb17.AutoSize = True
        Me.cb17.Location = New System.Drawing.Point(215, 373)
        Me.cb17.Name = "cb17"
        Me.cb17.Size = New System.Drawing.Size(40, 18)
        Me.cb17.TabIndex = 124
        Me.cb17.Text = "17"
        Me.cb17.UseVisualStyleBackColor = True
        '
        'cb16
        '
        Me.cb16.AutoSize = True
        Me.cb16.Location = New System.Drawing.Point(215, 358)
        Me.cb16.Name = "cb16"
        Me.cb16.Size = New System.Drawing.Size(40, 18)
        Me.cb16.TabIndex = 123
        Me.cb16.Text = "16"
        Me.cb16.UseVisualStyleBackColor = True
        '
        'frmChordBuilder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(492, 524)
        Me.Controls.Add(Me.Label68)
        Me.Controls.Add(Me.Label69)
        Me.Controls.Add(Me.cb15)
        Me.Controls.Add(Me.Label71)
        Me.Controls.Add(Me.Label72)
        Me.Controls.Add(Me.Label73)
        Me.Controls.Add(Me.Label74)
        Me.Controls.Add(Me.Label75)
        Me.Controls.Add(Me.lbld13)
        Me.Controls.Add(Me.Label77)
        Me.Controls.Add(Me.Label78)
        Me.Controls.Add(Me.Label79)
        Me.Controls.Add(Me.Label80)
        Me.Controls.Add(Me.Label82)
        Me.Controls.Add(Me.Label83)
        Me.Controls.Add(Me.Label84)
        Me.Controls.Add(Me.Label85)
        Me.Controls.Add(Me.Label86)
        Me.Controls.Add(Me.Label87)
        Me.Controls.Add(Me.Label88)
        Me.Controls.Add(Me.Label89)
        Me.Controls.Add(Me.Label90)
        Me.Controls.Add(Me.Label91)
        Me.Controls.Add(Me.Label94)
        Me.Controls.Add(Me.Label95)
        Me.Controls.Add(Me.Label96)
        Me.Controls.Add(Me.Label97)
        Me.Controls.Add(Me.Label98)
        Me.Controls.Add(Me.Label99)
        Me.Controls.Add(Me.Label100)
        Me.Controls.Add(Me.Label101)
        Me.Controls.Add(Me.Label102)
        Me.Controls.Add(Me.Label103)
        Me.Controls.Add(Me.Label104)
        Me.Controls.Add(Me.Label105)
        Me.Controls.Add(Me.Label106)
        Me.Controls.Add(Me.Label107)
        Me.Controls.Add(Me.Label108)
        Me.Controls.Add(Me.Label109)
        Me.Controls.Add(Me.Label110)
        Me.Controls.Add(Me.Label111)
        Me.Controls.Add(Me.cb24)
        Me.Controls.Add(Me.cb23)
        Me.Controls.Add(Me.cb22)
        Me.Controls.Add(Me.cb21)
        Me.Controls.Add(Me.cb20)
        Me.Controls.Add(Me.cb19)
        Me.Controls.Add(Me.cb18)
        Me.Controls.Add(Me.cb17)
        Me.Controls.Add(Me.cb16)
        Me.Controls.Add(Me.Label64)
        Me.Controls.Add(Me.Label65)
        Me.Controls.Add(Me.Label66)
        Me.Controls.Add(Me.Label67)
        Me.Controls.Add(Me.cb14)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.Label51)
        Me.Controls.Add(Me.Label62)
        Me.Controls.Add(Me.Label63)
        Me.Controls.Add(Me.cb13)
        Me.Controls.Add(Me.cmdShowChord)
        Me.Controls.Add(Me.Label60)
        Me.Controls.Add(Me.Label61)
        Me.Controls.Add(Me.Label58)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.cb0)
        Me.Controls.Add(Me.Label46)
        Me.Controls.Add(Me.Label47)
        Me.Controls.Add(Me.Label48)
        Me.Controls.Add(Me.Label49)
        Me.Controls.Add(Me.Label50)
        Me.Controls.Add(Me.lblSpec)
        Me.Controls.Add(Me.Label52)
        Me.Controls.Add(Me.Label53)
        Me.Controls.Add(Me.Label54)
        Me.Controls.Add(Me.Label55)
        Me.Controls.Add(Me.Label56)
        Me.Controls.Add(Me.Label57)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.lblShort)
        Me.Controls.Add(Me.Label40)
        Me.Controls.Add(Me.Label41)
        Me.Controls.Add(Me.Label42)
        Me.Controls.Add(Me.Label43)
        Me.Controls.Add(Me.Label44)
        Me.Controls.Add(Me.Label45)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.cb12)
        Me.Controls.Add(Me.cb11)
        Me.Controls.Add(Me.cb10)
        Me.Controls.Add(Me.cb9)
        Me.Controls.Add(Me.cb8)
        Me.Controls.Add(Me.cb7)
        Me.Controls.Add(Me.cb6)
        Me.Controls.Add(Me.cb5)
        Me.Controls.Add(Me.cb4)
        Me.Controls.Add(Me.cb3)
        Me.Controls.Add(Me.cb2)
        Me.Controls.Add(Me.cb1)
        Me.Controls.Add(Me.cmdSize)
        Me.Controls.Add(Me.chkOnTop)
        Me.Controls.Add(Me.chkAutoDisplay)
        Me.Controls.Add(Me.cmdShow)
        Me.Controls.Add(Me.txtNotes)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.cbIntervals)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.cbSymbol)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cbQuick)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbRoot)
        Me.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmChordBuilder"
        Me.Text = "Chorder - Chord Builder"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cbRoot As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents cbQuick As ComboBox
    Friend WithEvents Label3 As Label
    Friend WithEvents cbSymbol As ComboBox
    Friend WithEvents Label4 As Label
    Friend WithEvents cbIntervals As ComboBox
    Friend WithEvents txtNotes As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents cmdShow As Button
    Friend WithEvents chkAutoDisplay As CheckBox
    Friend WithEvents chkOnTop As CheckBox
    Friend WithEvents cmdSize As Button
    Friend WithEvents cb1 As CheckBox
    Friend WithEvents cb2 As CheckBox
    Friend WithEvents cb4 As CheckBox
    Friend WithEvents cb3 As CheckBox
    Friend WithEvents cb8 As CheckBox
    Friend WithEvents cb7 As CheckBox
    Friend WithEvents cb6 As CheckBox
    Friend WithEvents cb5 As CheckBox
    Friend WithEvents cb12 As CheckBox
    Friend WithEvents cb11 As CheckBox
    Friend WithEvents cb10 As CheckBox
    Friend WithEvents cb9 As CheckBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents lblShort As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents lblSpec As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Label57 As Label
    Friend WithEvents cb0 As CheckBox
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Label61 As Label
    Friend WithEvents Timer As Timer
    Friend WithEvents cmdShowChord As Button
    Friend WithEvents Label39 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents cb13 As CheckBox
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents cb14 As CheckBox
    Friend WithEvents Label68 As Label
    Friend WithEvents Label69 As Label
    Friend WithEvents cb15 As CheckBox
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents lbld13 As Label
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label87 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents Label89 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label91 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Label97 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Label105 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Label109 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents cb24 As CheckBox
    Friend WithEvents cb23 As CheckBox
    Friend WithEvents cb22 As CheckBox
    Friend WithEvents cb21 As CheckBox
    Friend WithEvents cb20 As CheckBox
    Friend WithEvents cb19 As CheckBox
    Friend WithEvents cb18 As CheckBox
    Friend WithEvents cb17 As CheckBox
    Friend WithEvents cb16 As CheckBox
End Class
