# Studioborne

Studioborne is a small application I developed primarily for personal use, though it's received
some warm feedback from others.

Studioborne was written in Visual Studio 2019 Community, using Visual Basic.

The code - though mostly neat in organization - is very sloppy, and relies heavily on the use
of manual CSV parsing, and converting numerical data types to strings and back.  But hey, it works.

## Instructions

A plain text read me with general instructions and version history can be found [here.](README.txt)

## The Source Code

Though I use coding and scripting for work on occasion, I am by no means a professional.  As such,
you might be aghast by some of the techniques I've employed in the code.  Further, I'm not GitHub
savvy at all... so... yea no clue what I'm doing here.

The entire Visual Studio project directories have been zipped and can be found in the sourcecode
directory.

## License

See the [LICENSE](LICENSE.md) file for license rights and limitations (gpl-3.0).