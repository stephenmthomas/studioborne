﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmKeyTriad
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmKeyTriad))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.pb7 = New System.Windows.Forms.PictureBox()
        Me.pb6 = New System.Windows.Forms.PictureBox()
        Me.pb4 = New System.Windows.Forms.PictureBox()
        Me.pb5 = New System.Windows.Forms.PictureBox()
        Me.pb3 = New System.Windows.Forms.PictureBox()
        Me.pb2 = New System.Windows.Forms.PictureBox()
        Me.pb1 = New System.Windows.Forms.PictureBox()
        Me.chkOnTop = New System.Windows.Forms.CheckBox()
        Me.cb1 = New System.Windows.Forms.CheckBox()
        Me.cb2 = New System.Windows.Forms.CheckBox()
        Me.cb3 = New System.Windows.Forms.CheckBox()
        Me.cb4 = New System.Windows.Forms.CheckBox()
        Me.cb5 = New System.Windows.Forms.CheckBox()
        Me.cb6 = New System.Windows.Forms.CheckBox()
        Me.cb7 = New System.Windows.Forms.CheckBox()
        CType(Me.pb7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pb7
        '
        Me.pb7.Image = CType(resources.GetObject("pb7.Image"), System.Drawing.Image)
        Me.pb7.Location = New System.Drawing.Point(0, 601)
        Me.pb7.Name = "pb7"
        Me.pb7.Size = New System.Drawing.Size(320, 100)
        Me.pb7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb7.TabIndex = 7
        Me.pb7.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb7, "Chord Degree 7")
        '
        'pb6
        '
        Me.pb6.Image = CType(resources.GetObject("pb6.Image"), System.Drawing.Image)
        Me.pb6.Location = New System.Drawing.Point(0, 501)
        Me.pb6.Name = "pb6"
        Me.pb6.Size = New System.Drawing.Size(320, 100)
        Me.pb6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb6.TabIndex = 6
        Me.pb6.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb6, "Chord Degree 6")
        '
        'pb4
        '
        Me.pb4.Image = CType(resources.GetObject("pb4.Image"), System.Drawing.Image)
        Me.pb4.Location = New System.Drawing.Point(0, 301)
        Me.pb4.Name = "pb4"
        Me.pb4.Size = New System.Drawing.Size(320, 100)
        Me.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb4.TabIndex = 5
        Me.pb4.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb4, "Chord Degree 4")
        '
        'pb5
        '
        Me.pb5.Image = CType(resources.GetObject("pb5.Image"), System.Drawing.Image)
        Me.pb5.Location = New System.Drawing.Point(0, 401)
        Me.pb5.Name = "pb5"
        Me.pb5.Size = New System.Drawing.Size(320, 100)
        Me.pb5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb5.TabIndex = 4
        Me.pb5.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb5, "Chord Degree 5")
        '
        'pb3
        '
        Me.pb3.Image = CType(resources.GetObject("pb3.Image"), System.Drawing.Image)
        Me.pb3.Location = New System.Drawing.Point(0, 201)
        Me.pb3.Name = "pb3"
        Me.pb3.Size = New System.Drawing.Size(320, 100)
        Me.pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb3.TabIndex = 3
        Me.pb3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb3, "Chord Degree 3")
        '
        'pb2
        '
        Me.pb2.Image = CType(resources.GetObject("pb2.Image"), System.Drawing.Image)
        Me.pb2.Location = New System.Drawing.Point(0, 101)
        Me.pb2.Name = "pb2"
        Me.pb2.Size = New System.Drawing.Size(320, 100)
        Me.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb2.TabIndex = 2
        Me.pb2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb2, "Chord Degree 2")
        '
        'pb1
        '
        Me.pb1.Image = CType(resources.GetObject("pb1.Image"), System.Drawing.Image)
        Me.pb1.Location = New System.Drawing.Point(0, 1)
        Me.pb1.Name = "pb1"
        Me.pb1.Size = New System.Drawing.Size(320, 100)
        Me.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pb1.TabIndex = 1
        Me.pb1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.pb1, "Chord Degree 1")
        '
        'chkOnTop
        '
        Me.chkOnTop.AutoSize = True
        Me.chkOnTop.Location = New System.Drawing.Point(272, 702)
        Me.chkOnTop.Name = "chkOnTop"
        Me.chkOnTop.Size = New System.Drawing.Size(47, 18)
        Me.chkOnTop.TabIndex = 42
        Me.chkOnTop.Text = "Top"
        Me.chkOnTop.UseVisualStyleBackColor = True
        '
        'cb1
        '
        Me.cb1.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb1.Location = New System.Drawing.Point(321, 82)
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(130, 19)
        Me.cb1.TabIndex = 43
        Me.cb1.Text = "I"
        Me.cb1.UseVisualStyleBackColor = True
        '
        'cb2
        '
        Me.cb2.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb2.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb2.Location = New System.Drawing.Point(321, 182)
        Me.cb2.Name = "cb2"
        Me.cb2.Size = New System.Drawing.Size(130, 19)
        Me.cb2.TabIndex = 44
        Me.cb2.Text = "I"
        Me.cb2.UseVisualStyleBackColor = True
        '
        'cb3
        '
        Me.cb3.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb3.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb3.Location = New System.Drawing.Point(321, 282)
        Me.cb3.Name = "cb3"
        Me.cb3.Size = New System.Drawing.Size(130, 19)
        Me.cb3.TabIndex = 45
        Me.cb3.Text = "I"
        Me.cb3.UseVisualStyleBackColor = True
        '
        'cb4
        '
        Me.cb4.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb4.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb4.Location = New System.Drawing.Point(321, 382)
        Me.cb4.Name = "cb4"
        Me.cb4.Size = New System.Drawing.Size(130, 19)
        Me.cb4.TabIndex = 46
        Me.cb4.Text = "I"
        Me.cb4.UseVisualStyleBackColor = True
        '
        'cb5
        '
        Me.cb5.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb5.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb5.Location = New System.Drawing.Point(321, 482)
        Me.cb5.Name = "cb5"
        Me.cb5.Size = New System.Drawing.Size(130, 19)
        Me.cb5.TabIndex = 47
        Me.cb5.Text = "I"
        Me.cb5.UseVisualStyleBackColor = True
        '
        'cb6
        '
        Me.cb6.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb6.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb6.Location = New System.Drawing.Point(321, 582)
        Me.cb6.Name = "cb6"
        Me.cb6.Size = New System.Drawing.Size(130, 19)
        Me.cb6.TabIndex = 48
        Me.cb6.Text = "I"
        Me.cb6.UseVisualStyleBackColor = True
        '
        'cb7
        '
        Me.cb7.CheckAlign = System.Drawing.ContentAlignment.BottomRight
        Me.cb7.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cb7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.cb7.Location = New System.Drawing.Point(321, 682)
        Me.cb7.Name = "cb7"
        Me.cb7.Size = New System.Drawing.Size(130, 19)
        Me.cb7.TabIndex = 49
        Me.cb7.Text = "I"
        Me.cb7.UseVisualStyleBackColor = True
        '
        'frmKeyTriad
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(355, 720)
        Me.Controls.Add(Me.cb7)
        Me.Controls.Add(Me.cb6)
        Me.Controls.Add(Me.cb5)
        Me.Controls.Add(Me.cb4)
        Me.Controls.Add(Me.cb3)
        Me.Controls.Add(Me.cb2)
        Me.Controls.Add(Me.cb1)
        Me.Controls.Add(Me.chkOnTop)
        Me.Controls.Add(Me.pb7)
        Me.Controls.Add(Me.pb6)
        Me.Controls.Add(Me.pb4)
        Me.Controls.Add(Me.pb5)
        Me.Controls.Add(Me.pb3)
        Me.Controls.Add(Me.pb2)
        Me.Controls.Add(Me.pb1)
        Me.Font = New System.Drawing.Font("Courier New", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(1)
        Me.MaximizeBox = False
        Me.Name = "frmKeyTriad"
        Me.Text = "Triads"
        CType(Me.pb7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pb1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pb1 As PictureBox
    Friend WithEvents pb2 As PictureBox
    Friend WithEvents pb3 As PictureBox
    Friend WithEvents pb5 As PictureBox
    Friend WithEvents pb4 As PictureBox
    Friend WithEvents pb6 As PictureBox
    Friend WithEvents pb7 As PictureBox
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents chkOnTop As CheckBox
    Friend WithEvents cb1 As CheckBox
    Friend WithEvents cb2 As CheckBox
    Friend WithEvents cb3 As CheckBox
    Friend WithEvents cb4 As CheckBox
    Friend WithEvents cb5 As CheckBox
    Friend WithEvents cb6 As CheckBox
    Friend WithEvents cb7 As CheckBox
End Class
