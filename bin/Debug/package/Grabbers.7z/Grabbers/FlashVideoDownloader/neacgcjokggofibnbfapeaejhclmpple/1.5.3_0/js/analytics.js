(function() {
  function guidGenerator() {
    var S4 = function() {
       return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
    };
    return (S4()+S4()+"-"+S4()+"-"+S4()+"-"+S4()+"-"+S4()+S4()+S4());
  }
  if(!localStorage.booking_analytics_cid) {
    localStorage.booking_analytics_cid = guidGenerator();
  }
  var Analytics = {
    url: "https://www.google-analytics.com/collect",
    tid: "UA-67774717-21",
    send: function(data) {
      data.v = 1;
      data.tid = this.tid;
      data.cid = localStorage.booking_analytics_cid;
      data.t = data.t || "pageview";
      var xhr = new XMLHttpRequest();
      xhr.open("POST", this.url);
      var dataStr = [];
      for(var k in data) {
        dataStr.push(k + "=" + encodeURIComponent(data[k]));
      }
      xhr.send(dataStr.join("&"));
    }
  };
  window.Analytics = Analytics;
})();