var SEND_REPORT_EVERY = 24*3600*1000; // 24 hours

window.addEventListener( "load", function(){
	
	fvdSingleDownloader.Media.init();
	fvdSingleDownloader.FileSystem.init();
	fvdSingleDownloader.MainButton.refreshMainButtonStatus();
	
	if( fvdSingleDownloader.Utils.isVersionChanged() && !fvdSingleDownloader.noWelcome )	{
		var url = null;

		if( fvdSingleDownloader.noYoutube ) 	{
			
			if (fvdSingleDownloader.Prefs.get("install_time") == 0)  {
				url = "http://operadownloaders.com/";
			}
			else {
			}			
			
		}	
		else {
			
			if (fvdSingleDownloader.Prefs.get("install_time") == 0) 	{
				url = "http://operadownloaders.com/";
			}
			else	{
			}			
		}	
		
		if( url )	{
			chrome.tabs.create({
						url: url,
						active: true
					});			
		}

	}
	
	if( fvdSingleDownloader.Prefs.get( "install_time" ) == 0 )	{
		fvdSingleDownloader.Prefs.set( "install_time", new Date().getTime() )
	}
	
	// устанавливаем страницу при удаление
	//chrome.runtime.setUninstallURL("http://fvdmedia.com/to/s/dwunstl");

	// --------------------------------------------------------------------------------
	chrome.runtime.onMessage.addListener( function(request, sender, sendResponse) {
		
			if (request.akse == 'Page_Options') {
				
				var params = {};
				for (var i = 0; i != request.list.length; i++) 	{
					var v = fvdSingleDownloader.Prefs.get( request.list[i] );
					if (v == 'true')  v = true;
					else if (v == 'false')  v = false;
					params[ request.list[i] ] = v;
				}
				
				var message = {};
				for (var i = 0; i != request.msg.length; i++) 	{
					message[request.msg[i]] =  chrome.i18n.getMessage(request.msg[i]);
				}
				
				var addon = {};
				addon.id = chrome.i18n.getMessage("@@extension_id");
				addon.title = chrome.i18n.getMessage("extension_title");
				addon.description = chrome.i18n.getMessage("extension_description");
				
				sendResponse({paramsOptions: params,  paramsMessage: message,  paramsAddon: addon});
				
			}
			else if (request.akse == 'Save_Options') {
				
				for ( var k in request.params ) {
					fvdSingleDownloader.Prefs.set( k, request.params[k].toString() );
				}
				
				sendResponse({});
			}	
			else if (request.akse == 'Close_Options') {
				
				chrome.tabs.query( {
						active: true,
						currentWindow: true
					}, function( tabs ){
								if( tabs.length > 0 )	{
									chrome.tabs.remove(tabs[0].id);
								}
				} );
			}	
			else if (request.action == 'SettingOptions') {
				
				display_settings(  );
			}	
			else if (request.action == 'open_edit_video') {
  				chrome.tabs.create({url: "test.html"}, function (tab) {	});	  
			}	
			
	});
	
	chrome.tabs.query( {
			active: true,
			currentWindow: true
		}, function( tabs ){
					if( tabs.length > 0 )	{
						fvdSingleDownloader.MainButton.setPopup(tabs[0].id);
					}
	} );
	
 	ShopSuggestions.init({
	  tag: "yN1mb4sX",
	  whiteListUrl: "https://api.ciuvo.com/api/whitelist?tag=yN1mb4sX",
	  addonName: "FVD Suggestions",
	  enabled: function() {
	  	return _b(fvdSingleDownloader.Prefs.get("fvd.enable_ad_on_markets"));
	  }
	});

    setInterval(function() {
		var lastSendTime = getLastAnalyticsTime();
        var now = new Date().getTime();
		
		if(now - lastSendTime > SEND_REPORT_EVERY) {
			Analytics.send({dl: "/"});	
			setLastAnalyticsTime();
		}
	}, 600000);

	
}, false );

function getLastAnalyticsTime() {
    var v = localStorage["_analytics_last_time"];
    v = parseInt(v);
    if(isNaN(v)) {
      v = 0;
    }
    return v;
}  

function setLastAnalyticsTime() {
    localStorage["_analytics_last_time"] = new Date().getTime();
}

// ------------------------------------
chrome.management.getAll(function(extensions){

        for (var i in extensions) {
//            if (extensions[i].enabled) 	{
				if ( extensions[i].name.indexOf("FVD Suggestions") != -1) {
//console.log(extensions[i]);
					if ('MainButton' in fvdSingleDownloader) {
						fvdSingleDownloader.MainButton.isGtaSuggestion = true;
					}	
				}	
				if ( extensions[i].name.indexOf("Smart Pause for YouTube") != -1) {
					if ('MainButton' in fvdSingleDownloader) {
						fvdSingleDownloader.MainButton.isSmartPause = true;
					}	
				}	
//            }
        }
		
});


// ---------------------------------------- ОПЦИИ  --------------------------
function display_settings(  )  {

	chrome.tabs.query( 	{  }, function( tabs ){
		
					var myid = chrome.i18n.getMessage("@@extension_id");
		
					if( tabs.length > 0 )	{
						
						for (var i=0; i<tabs.length; i++) {
						
							if ( tabs[i].url.indexOf( "addon="+myid ) != -1 ) {	
								chrome.tabs.update( tabs[i].id, { active: true } );
								return;
							}
						}
						
						chrome.tabs.create( {	active: true,
												url: chrome.extension.getURL("/opt_page.html")
											}, function( tab ){ }
										);
					}
	} );
}

// ----------------------------------------------
navigateMessageDisabled = function(type){
	
	var host = 'http://fvdmedia.com';
	var url = '/message-disabled/';
	if (type == 3) {
		url = '/message-disabled-1/';
	}
	else if (type == 1) {
		url = '/message-disabled-0/';
	}
	else if (type == 16) {
		url = '/message-stream-error/';
	}
	
	chrome.tabs.query( 	{  }, function( tabs ){
		
					if( tabs.length > 0 )	{
						for (var i=0; i<tabs.length; i++) {
							if ( tabs[i].url.indexOf( url ) != -1 ) {	
								chrome.tabs.update( tabs[i].id, { active: true, url: host+url } );
								return;
							}
						}
						
						chrome.tabs.create( {	active: true,
												url: host+url
											}, function( tab ){ });
					}
	} );
	
}
	
// ------------------------------------

	

