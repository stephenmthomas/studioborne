if (window == chrome.extension.getBackgroundPage()) {

	(function(){
		'use strict'
	
		var Media = function(){

			var self = this;
			
			var textFile = null;
			
			var _onMediaForTabUpdateListeners = [];
			
			const DETECT_MODULES = ["Youtube", "Vimeo", "BreakCom", "VKontakte", "FaceBook", "OdnoKlassniki", 
									"Twitch", "Twitter", "MediaManifest", "MediaStream", "MediaMaster", 
									"Sniffer" ];
									
			// ===============================================================
			this.init = function(){
			
				console.log("Media - init ");
				
				// ---------------------------   
				chrome.tabs.onRemoved.addListener( function( tabId ){
					//console.log('onRemoved', tabId)					
					if( fvdSingleDownloader.Media.Storage.hasDataForTab( tabId ) )	{
						fvdSingleDownloader.Media.Storage.removeTabData( tabId );
						fvdSingleDownloader.MainButton.MediaForTabUpdate( tabId );
					}
				});
				
				// --------------------------- 
				chrome.tabs.onUpdated.addListener( function( tabId, changeInfo ){
					//console.log('onUpdated', tabId, changeInfo)					
					if( changeInfo.url ) {
						if( fvdSingleDownloader.Media.Storage.hasDataForTab( tabId ) ) {
							fvdSingleDownloader.Media.Storage.removeTabData( tabId );
						}
					}
					fvdSingleDownloader.MainButton.MediaForTabUpdate( tabId );
				});
				
				// --------------------------- 
				chrome.tabs.onActivated.addListener(function(info){
					//console.log('onActivated', info)					
					fvdSingleDownloader.MainButton.MediaForTabUpdate( info.tabId );
				});
				
				
				// ---------------------------  SendRequest
				chrome.extension.onRequest.addListener ( function(request, sender, sendResponse) {        
					if(request.command=="getVideoData")	{
						fvdSingleDownloader.Utils.getActiveTab( function( tab ) {
									if( tab )	{
										var media = self.getMedia( tab.id );
										media = fvdSingleDownloader.MainButton.filter_Media( media );
										media = fvdSingleDownloader.MainButton.parsed_Media( media );
										sendResponse(media);
									}
								});	
					}
					if(request.command=="getVideoHash")	{
						var media = fvdSingleDownloader.Media.Storage.getDataForHash( request.hash );
						sendResponse({media: media, fileName: fvdSingleDownloader.FileSystem.Unique( )});
					}
					else if(request.command=="clickDownload")	{
						self.clickDownload( request.mediaId );	
					}
				});
			}

			// ===============================================================
			this.mediaForTabUpdate = function( tabId ){

				chrome.extension.sendMessage( {
											subject: "mediaForTabUpdate",
											data: tabId
										} );
										
				fvdSingleDownloader.MainButton.MediaForTabUpdate( tabId );							
										
			
			}	

			// ===============================================================
			this.checkMedia = function( data ){
				for (var ii=0; ii<DETECT_MODULES.length; ii++) {
					var module = DETECT_MODULES[ii];
					if( self[module] )		{
						var x = self[module].checkMedia(data);	
						if (x != 0)  {
							//if (x == 1) console.log('====', module, '====', data.url);
							return x;	
						}	
					}
				}	
				return 0;
			}	
			// -------------------------------------------------------------------
			this.detectMedia = function( data ){
				
				// ---------------------------  Sniffer, Youtube, .....
				for (var ii=0; ii<DETECT_MODULES.length; ii++) {
					
					var module = DETECT_MODULES[ii];
					if( self[module] )		{
						var x = self[module].detectMedia(data);	
						if (x == 1)  return x;
					}
				}	
				return 0;
				
			}	
			
			// ===============================================================
			this.getMedia = function( tabId ){
				
				var media = fvdSingleDownloader.Media.Storage.getMedia( tabId );
				
				if ( !media || media.length == 0 )  return null;

				DETECT_MODULES.forEach( function( module ){
					if( self[module] )		{
						media = self[module].getMedia(media);	
					}
				} );
				
				media.sort( function( item1, item2 )  {   
					if (item1.priority < item2.priority)  return 1;
					if (item1.priority > item2.priority)  return -1;

					if (item1.groupId > item2.groupId)  return 1;
					if (item1.groupId < item2.groupId)  return -1;
					if (item1.groupId == item2.groupId) {
						if (item1.orderField < item2.orderField)  return 1;
						if (item1.orderField > item2.orderField)  return -1;
					}	

					return (item1.id < item2.id ? 1 : -1);  
				});
				

				return media;
			}
			// ----------------------------------------------------------------------------------------------------
			this.filterNotAllowedMedia = function( media ){

				if (!media) return [];

				var rezult = [];

				media.forEach(function( item ){

											if ( item.metod == 'not' )	{
												rezult.push( item );
											}
										});
										
				return rezult;						
			}
			
			// ===============================================================
			this.clickDownload = function( id ){

				var m = fvdSingleDownloader.Media.Storage.getDataForId( id );
				if (!m) return;
				console.log('clickDownload', m);
				
				if (m.status == 'error') {
					if (m.metod == 'stream') navigateMessageDisabled(16);
					return;
				}
				
				if (m.metod == 'download') {
						if (m.status == 'stop') {
							startDownloadMedia( m );
						}
						else if (m.status == 'start')  {
							stopDownloadMedia( m );
						}   
				}
				else if (m.metod == 'stream') {
						if (m.status == 'stop') {
							startStreamMedia( m );
						}
						else if (m.status == 'start') {
							stopStreamMedia( m );
						}   
				}
				else if (m.metod == 'record') {
						if (m.status == 'stop') {
							startRecordMedia( m );
						}
						else if (m.status == 'start') {
							stopRecordMedia( m );
						}   
				}
				else if (m.metod == 'convert') {
						if (m.status == 'stop') {
							startConvertMedia(m);
						}
						else if (m.status == 'start') {
							stopConvertMedia(m);
						}   
				}
			}	
			
			// =====================================================================================
			function startDownloadMedia(media) {

				console.log('MEDIA.startDownloadMedia', media);
				
				// metod download
				var flag_download = ('dwnl' in media && media.dwnl) ?  media.dwnl : 0;
				if( flag_download == 1 && !chrome.downloads ) flag_download = 5; // 
				var met = _b(fvdSingleDownloader.Prefs.get( "fvd.original_filename" ));
				var file_name;
				if (met) {	//  original file name
					file_name = media.filename;	
				}
				else {
					file_name = media.downloadName;	
				}
				file_name = fvdSingleDownloader.FileSystem.removeChars( file_name );
				file_name = file_name + '.' + media.ext; 

				fvdSingleDownloader.Utils.Async.chain( [
				
					function( chainCallback ){		// 
					
									if( fvdSingleDownloader.noYoutube == false )	{
										fvdSingleDownloader.FvdMobile.downloadMedia( media, function( result ){
															if( !result )	{
																chainCallback();
															}
														} );						
									}
									else	{
										chainCallback();	
									}
								},
								
					function( chainCallback ){			// 
					
									if( flag_download == 3 )	{
										console.log('DOWNLOAD - open');
										chrome.tabs.create({
														url: media.url,
														active: false
													});		 
										return;
									}	
									else {
										chainCallback();
									}
									
								}, 
								
					function( chainCallback ){			//  API
										
									if( flag_download == 1 ) 	{
										console.log('DOWNLOAD - api', file_name);	
										
										fvdSingleDownloader.Downloader.start( media.id, media.url, file_name,
												function(error, downloadId)	{ 
												
													if(error) {
														console.log(fvdSingleDownloader.Downloader.getError());
													}
													else  {
														
													}
												}
										);
										return;					
									}
									else	{
										chainCallback();
									}						
								},
			
					function( chainCallback ){			// 
										
										fvdSingleDownloader.Utils.getActiveTab(function( tab ){
													fvdSingleDownloader.ContentScriptController.processMessage( tab.id, {
																action: "startDownload",
																media: media
															} );
												});
										return;		
								}
				] );
			}
			// --------------------------------------------------
			function stopDownloadMedia(media) {

				console.log('stopDownloadMedia', media);
				
				if ( !media ) return;
				
				if (media.downloadId) {
					fvdSingleDownloader.Downloader.stop( media.downloadId, function(error)	{ 
																				if(error) {
																					console.log(fvdSingleDownloader.Downloader.getError());
																				}
																				else  {
																				}
					});
				}
				else {
					fvdSingleDownloader.Media.Storage.setData_Attribute(media.tabId, media.id, "status", 'stop');		
				}	
			}	
			
			// ===============================================================
			function startStreamMedia(media) {
				
				chrome.extension.sendMessage( {	subject: "mediaStreamerState", state: true, id: media.id   } );

				fvdSingleDownloader.Streamer.start( media.hash,
							function(rez)	{ 
									if ( rez.msg === 'start' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { status:'start' } );
										chrome.extension.sendMessage( {	subject: 		"mediaDownloadState", 
																		id: 			media.id, 	
																		metod:			media.metod,
																		streamHash: 	rez.hash, 
																		status:			'start'
																	} );
									}	
									else if ( rez.msg === 'cancel' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { status: 'stop' } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		metod:		media.metod,
																		streamHash: rez.hash, 
																		status:		'stop'
																	  } );
									}
									else if ( rez.msg === 'finish' ) {
										var st = rez.error ? 'error' : 'stop';
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { status: st } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		metod:		media.metod,
																		streamHash: rez.hash, 
																		status:     st
																	} );
									}
									else if ( rez.msg === 'playlist' ) {
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		count: 		rez.count, 
																		streamHash: rez.hash, 
																		status:		'playlist',
																	  } );
									}	
									else if ( rez.msg === 'progress' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { progressByte: rez.size, progress: rez.progress } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		count: 		rez.count, 
																		streamHash: rez.hash, 
																		byte: 		rez.size, 
																		progress: 	rez.progress	
																	} );
									}	
									else if ( rez.msg === 'saving' ) {
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		streamHash: rez.hash, 
																		status:		'saving',
																	 } );
									}	
									else if ( rez.msg === 'concat' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { progress: rez.progress } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		streamHash: rez.hash, 
																		progress: 	rez.progress,
																		status:		'saving',
																	  } );
									}	
							},									
							function(rez)	{ 
									console.log('FINISH', rez);
									if ( !rez.error) {
										for (var j=0; j<rez.filename.length; j++) {
											(function( fn, ext ) {
												fvdSingleDownloader.FileSystem.saveVideo({	fileName: fn.filename, 
																							dirPath: fn.dirPath, 
																							downloadName: fn.downloadName, 
																							ext: ext}, function(){
													fvdSingleDownloader.FileSystem.removeFile(fn.filename);
												});
											})(rez.filename[j], media.ext)	
										}	
									}
									chrome.extension.sendMessage( {	subject: "mediaStreamerState", state: false, id: media.id   } );
							}
				);									   
			}	
			
			// --------------------------------------------------
			function stopStreamMedia(media) {
				
				fvdSingleDownloader.Streamer.stop( media.hash );
			}

			// ===============================================================
			function startRecordMedia(media) {

				console.log('startRecordMedia', media);
				
				fvdSingleDownloader.Media.Storage.setTwitch( media.hash, 'start', null );
				chrome.extension.sendMessage( {	subject: 		"mediaDownloadState", 
												id: 			media.id, 	
												metod:			media.metod,
												streamHash: 	media.hash, 
												status:			'start'
											} );
				
				
				fvdSingleDownloader.Recorder.start( media.hash, 
													function( rez ) {    // message
														if(rez.error) {
															//console.log(fvdSingleDownloader.Recorder.getError());
														}
														else  {
															fvdSingleDownloader.Media.Storage.setTwitch( media.hash, rez.state, rez.size );
															chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																							id: 		media.id, 
																							streamHash: media.hash, 
																							byte: 		rez.size, 
																						} );
														}
													},									
													function(rez)	{ 
														console.log('FINISH', rez);
														if ( !rez.error) {
															fvdSingleDownloader.FileSystem.saveVideo({	fileName: rez.filename, 
																										downloadName: media.downloadName, 
																										ext: media.ext}, function(){
																fvdSingleDownloader.FileSystem.removeFile(rez.filename);
															});
														}
													}
				);
				
			}	
			// --------------------------------------------------
			function stopRecordMedia(media) {
				
				fvdSingleDownloader.Media.Storage.setTwitch( media.hash, 'stop', null );
				chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
												id: 		media.id, 
												metod:		media.metod,
												streamHash: media.hash, 
												status:     'stop'
											} );

				fvdSingleDownloader.Recorder.stop( media.hash, function(rez)	{ 
								console.log('FINISH', rez);
								if(rez.error) {
									// If true, get error info
									console.log(fvdSingleDownloader.Recorder.getError());
								}
								else {
									fvdSingleDownloader.Media.Storage.setTwitch( media.hash, rez.state, null  );
									
									var link_href = saveTSFile(rez.file);
									media.url = link_href;
									startDownloadMedia( media );
								}	
						});
			
			}	
			
			
			
			// ===============================================================
			function startConvertMedia(media) {

				console.log('startConvertMedia', media);
			
				fvdSingleDownloader.Converter.start( media.hash,
							function(rez)	{ 
									if ( rez.msg === 'start' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { status:'start' } );
										chrome.extension.sendMessage( {	subject: 		"mediaDownloadState", 
																		id: 			media.id, 	
																		metod:			media.metod,
																		streamHash: 	rez.hash, 
																		status:			'start'
																	} );
									}	
									else if ( rez.msg === 'finish' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { status: 'stop' } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		metod:		media.metod,
																		streamHash: rez.hash, 
																		status:     'stop'
																	} );
									}
									else if ( rez.msg === 'progress' ) {
										fvdSingleDownloader.Media.Storage.setStream( rez.hash, { progressByte: rez.size, progress: rez.progress } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		count: 		rez.count, 
																		streamHash: rez.hash, 
																		byte: 		rez.size, 
																		progress: 	rez.progress	
																	} );
									}	
									else if ( rez.msg === 'saving' ) {
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		streamHash: rez.hash, 
																		status:		'saving',
																	 } );
									}	
							},									
							function(rez)	{ 
								if ( !rez.error) {
									for (var j=0; j<rez.filename.length; j++) {
										(function( fn, ext ) {
											fvdSingleDownloader.FileSystem.saveVideo({	fileName: fn.filename, 
																						dirPath: fn.dirPath, 
																						downloadName: fn.downloadName, 
																						ext: ext}, function(){
												fvdSingleDownloader.FileSystem.removeFile(fn.filename);
											});
										})(rez.filename[j], media.ext)	
									}	
								}
							}
				);									   
				
			
			}
			
			// --------------------------------------------------
			function stopConvertMedia(media) {

				console.log('stopConvertMedia', media);

				fvdSingleDownloader.Converter.stop( media.hash );
				
				fvdSingleDownloader.Media.Storage.setStream( rez.hash, { status: 'stop' } );
				chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
												id: 		media.id, 
												metod:		media.metod,
												streamHash: rez.hash, 
												status:		'stop'
											  } );
			}	
			
			// ===============================================================
			function saveTSFile(data)	{ 	
				// If we are replacing a previously generated file we need to
				// manually revoke the object URL to avoid memory leaks.
				if (textFile !== null) 	{
					window.URL.revokeObjectURL(textFile);
				}
			
				textFile = window.URL.createObjectURL(data);		
				return textFile;
			}
			
			// ===============================================================
			this.isStream = function(  ){

				if ( fvdSingleDownloader.Media.Storage.getActiveConvertStream() ) return false;				
				
				return true;
			}	
			
		}
		
		this.Media = new Media();
		
	}).apply(fvdSingleDownloader);
	
}
else
{
	fvdSingleDownloader.Media = chrome.extension.getBackgroundPage().fvdSingleDownloader.Media;
}
