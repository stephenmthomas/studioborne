(function(){

	var MediaCombine = function(){		
	
		var self = this;
		
		const DEBUG = false;
		
		const REGEXP_URL_SIGNS = [
			{ test:  new RegExp("^https:\\/\\/(.+?)\\.mycdn.me\\/\\?(.+?)\\&bytes=([0-9]+)-([0-9]+)","i"),
			  id: new RegExp("&id=(.+?)&","i"),
			  frag: new RegExp("&bytes=([0-9]+)-","i"),
			  exm: "https://vd33(31).mycdn.me/?expires=1489915874209&srcIp=78.138.176.12&srcAg=CHROME&type=3&sig=6b32cf88b8e56fa5e3823b75df55478f533164ef&ct=4&urls=5.61.21.106&clientType=0&id=144939616920&bytes=14948166-17145878",
			},
/*			{ test:  new RegExp("^https:\\/\\/videocontent\\.osi\\.office\\.net/(.+?)\\/Fragments(.+?)","i"),
			  id: new RegExp("https:\\/\\/videocontent\\.osi\\.office\\.net\\/(.+?)\\/","i"),
			  frag: new RegExp("https://videocontent.osi.office.net/0aa17215-1d21-4e28-9cc8-b2647a16a6f6/video.ism/QualityLevels(3393650)/Fragments(video=340000000,format=mpd-time-csf)","i"),
			  exm: "https://videocontent.osi.office.net/0aa17215-1d21-4e28-9cc8-b2647a16a6f6/video.ism/QualityLevels(3393650)/Fragments(video=340000000,format=mpd-time-csf)",
			}  */
		];
		
		var detectVideo = {};
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url;
			var flag = 0;
            REGEXP_URL_SIGNS.forEach(function( regSign ){
				var sign = regSign.test;
                if (sign.test(url)) {
                    flag = 1;
                }    
            });
			
			return flag;
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var flag = 0;
            REGEXP_URL_SIGNS.forEach(function( regSign ){
				var sign = regSign.test;
                if (sign.test(data.url)) {
					data.regex = regSign;
                    detectSegmentVideo(data);
					flag = 1;
                }    
            });
			
			if ( flag <= 0 ) return flag;
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectSegmentVideo( media ){
			
			if (DEBUG) console.log(media);			

			var url = media.url;
			var videoId = null;
			
			var m = url.match( media.regex.id ); 
			if (m)   videoId = m[1];
			
			if (DEBUG) console.log('videoId: ', videoId);
			
			if (videoId) {

				var frag = null;
				m = url.match( media.regex.frag ); 
				if (!m)  return;
				try {
					frag = parseInt(m[1]);
				}
				catch(ex) {		}	
				if (DEBUG) console.log(frag);
			
				if ( detectVideo[videoId] ) {
					if (detectVideo[videoId].list.indexOf(url) == -1) {
						detectVideo[videoId].list.push({ url: url, frag: frag });
						detectVideo[videoId].list.sort( function( item1, item2 )  {   return (item1.frag > item2.frag ? 1 : -1);  });
					}	
				
					if ( detectVideo[videoId].list.length>5) {
						
						if (detectVideo[videoId].hash) {
							var l = [];	for (var ii=0; ii<detectVideo[videoId].list.length; ii++)  l.push( detectVideo[videoId].list[ii].url);
							fvdSingleDownloader.Media.Storage.setData_Attribute( media.tabId, detectVideo[videoId].id, 'playlist', l );
							
							clearTimeout(detectVideo[videoId].timer);
							detectVideo[videoId].timer = setTimeout( function() {
								fvdSingleDownloader.Media.Storage.setParams_Attribute( media.tabId, detectVideo[videoId].id, 'load_url', true );
								delete detectVideo[videoId];
							}, 3000);
						}
						else {	
							detectVideo[videoId].hash = videoId;

							detectVideo[videoId].id = addVideo( detectVideo[videoId] );
							
							detectVideo[videoId].timer = setTimeout( function() {
								fvdSingleDownloader.Media.Storage.setParams_Attribute( media.tabId, detectVideo[videoId].id, 'load_url', true );
								delete detectVideo[videoId];
							}, 3000);
						}
					}
				}
				else {	
					detectVideo[videoId] = { videoId:  	videoId,
											 tabId:    	media.tabId,
											 tabUrl:    media.tabUrl,
											 tabTitle:  media.tabTitle,
											 thumbnail: media.thumbnail,
											 url:		url,
											 list:      [{ url: url,  frag: frag }	] }
				}
			}	
			
		}
		
		// --------------------------------------------------------------------------------
		function addVideo( params ){
			
			if (DEBUG) console.log('addVideo', params);

			var displayName = params.tabTitle;
			var downloadName = displayName;
			
			var ext = 'mp4';
			var filename = params.videoId;
			
			var l = [];	for(var ii=0; ii<params.list.length; ii++)  l.push( params.list[ii].url);
			
			var id = fvdSingleDownloader.Media.Storage.add( {
					url: 		params.url,
					tabId: 		params.tabId,
					tabUrl: 	params.tabUrl,
					
					videoId: 	params.videoId,
					hash: 		params.hash,
					thumbnail: 	params.thumbnail,
					
					ext: 		ext,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	[],
					filename: 		filename,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"video",
					metod: 		'stream',
					source: 	"MediaCombine",
					quality:    null,
					
					dwnl:		1,
					
					playlist:   l,
					
					params: 	{load_url: false}
				},{
					findThumbnail: false,
					noReplace: true
				});

			return id;		
		}		

		// ====================================================================	
		this.getMedia = function( media ){

			return media;	
		}

	}
	
	fvdSingleDownloader.Media.MediaCombine = new MediaCombine();
	
})( );
