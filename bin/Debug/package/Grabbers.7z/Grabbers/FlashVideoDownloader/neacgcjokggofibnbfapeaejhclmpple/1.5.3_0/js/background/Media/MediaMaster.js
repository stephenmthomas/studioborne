(function(){
	
	var MediaMaster = function(){		
	
		const DEBUG = false;
		
		const TITLE_MAX_LENGTH  = 96;
	
		var self = this;
		
		const NAME_PATTERN = new RegExp("/([^/]+?)(?:\\.([a-z0-9]{1,5}))?(?:\\?|#|$)", "i");
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			if( /\/video\/(.*)\/master\.json\?/.test(data.url.toLowerCase()) )  {		// https://vimeo.com/122045086
				return 1;
			}
			else if( /\/segment\-[0-9]+\.m4s/.test(data.url.toLowerCase()) ) {
				return -1;
			} 
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			if( t == 1 )  {
				masterPlayList(data);
			}

			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function masterPlayList( data ){
				
			var url = data.url;
			var hh = hex_md5(url);
			var videoId = null;

			var audioStream = [];
			
			var domain = null, k, tt, host = "", prot = "";
			var x = fvdSingleDownloader.Utils.parse_URL(url);
			
			host = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '') + x.path+'/';
			domain = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '');
			search = x.search || "";
			if ( search.indexOf('?') != 0 ) search = '?'+search;

			getAJAX( url, null, function(content){
				
				var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     
				var fileName, fileExt, ext, hash, label, base_url, sample_rate, initSeg;
				var audio_id = null, video_id = null; 
				
				var x = JSON.parse(content);	
					
				if (x) {
						
					videoId = get_json( x, 'clip_id' );
					baseUrl = get_json( x, 'base_url' );
					baseUrl = get_base_url( url, baseUrl );

					video = get_json( x, 'video' );
					audio = get_json( x, 'audio' );
					
					for (var j=0; j<audio.length; j++) {
							
						var xx = get_json( audio[j], 'init_segment' );
						initSeg =  window.atob(xx);

						base_url = get_json( audio[j], 'base_url' )
						sample_rate = get_json( audio[j], 'sample_rate' );
						audio_id = get_json( audio[j], 'id' );
						ext = "mp4";
						hash = videoId+'_'+sample_rate;
						
						var segments = get_json( audio[j], 'segments' );
						var list = [];
						for (var jj=0; jj<segments.length; jj++) {
							var uu = segments[jj].url;
							if (uu.indexOf('http') != 0) {
								uu = baseUrl + '/' + base_url + uu;
							}   
							if (uu.indexOf('?') == -1 && uu.indexOf('#') == -1 && search) {
								uu = uu + search;
							}    
							list.push( uu );    
						}  

						audioStream.push({  audio_id: audio_id,
											hash: hash,
											url: baseUrl+'/'+base_url, 
											fileExt: ext, 
											sample_rate: sample_rate,
											playlist: list,
											init: initSeg });
					}

					for (var j=0; j<video.length; j++) {
							
						var xx = get_json( video[j], 'init_segment' );
						initSeg =  window.atob(xx);

						base_url = get_json( video[j], 'base_url' )
						label = get_json( video[j], 'width' )+'x'+get_json( video[j], 'height' );
						video_id = get_json( video[j], 'id' );
						ext = "mp4";
						hash = videoId+'_'+label;
						
						var segments = get_json( video[j], 'segments' );
						var list = [];
						for (var jj=0; jj<segments.length; jj++) {
							var uu = segments[jj].url;
							if (uu.indexOf('http') != 0) {
								uu = baseUrl + '/' + base_url + uu;
							}   
							if (uu.indexOf('?') == -1 && uu.indexOf('#') == -1 && search) {
								uu = uu + search;
							}    
							list.push( uu );    
						}  

						var aa = find_audio( video_id );

						var mm = {  hash: hash,
									url: baseUrl+'/'+base_url, 
									fileExt: ext, 
									thumbnail: data.thumbnail, 
									quality: label,
									group: groupMedia,
									playlist: list,
									data: data
								 };

						var pp = {  
									init: initSeg
								 };

						if (aa) {
							pp.audio_stream = { hash:  		aa.hash,
												ext:   		aa.fileExt,
												url:   		aa.url,
												playlist: 	aa.playlist,
												params:  	{ 	init: aa.init, 
														   		sample_rate: aa.sample_rate }
											  };
						}		 

						addMedia(mm, pp, 'stream');
						
					}
				}
			});


			// -----------------------------
			function find_audio( id ) {

				if ( audioStream.length > 0 ) {
					if ( id ) {
						for (var j=0; j<audioStream.length; j++) {
							if (audioStream[j].audio_id == id) {
								return audioStream[j];
							}
						}	
					}
					return audioStream[0];		
				}
				else {
					return null;
				}	
			}
				
		
		}
		
		// --------------------------------------------------------------------------------
		function addMedia( params, pp, metod ){

			if (DEBUG) console.log('addMedia', params, pp, metod);
			
			// если видео и звук разделены - то не будет ссылки
			if (pp.audio_stream)  return;
			
			var q = null;
			if (params.quality) {
				var m = params.quality.match( /([0-9]+)x([0-9]+)/im ); 
				q = m ? m[2] : params.quality; 
				try { q = parseInt(q);	} catch(ex) {}		
			}

			var ft = [{tag: 'span', content: '[' },
					  {tag: 'span', content: (params.quality ? params.quality+', ' : '') },
					  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(params.fileExt) }, 	
					  {tag: 'span', content: '] ' }	];
					  
			var displayName = params.data.tabTitle ? params.data.tabTitle : params.fileName;
			var downloadName = displayName;

			var fileName = null;	
			if (params.fileName) {
				fileName = params.fileName;
			}	
			else {
				fileName = params.quality;
				var ff = fvdSingleDownloader.Utils.extractPath( params.url );
				if (ff) {
					fileName = (params.quality ? params.quality+'_' : '')+ff.name;
				}					
				else {
					fileName = (params.quality ? '['+params.quality+'] ' : '')+params.data.tabTitle;	
				}	
			}
			
			fvdSingleDownloader.Media.Storage.add( {
					url: 		params.url,
					tabId: 		params.data.tabId,
					tabUrl: 	params.data.tabUrl,
					frameId: 	params.data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	params.data.thumbnail,
					
					ext: 		params.fileExt,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					playlist:       params.playlist ? params.playlist : null,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"video",
					metod: 		metod,
					source: 	"MediaMaster",
					quality:    q,
					
					groupId: 	params.group,
					orderField: q,
					dwnl:		1,
					
					params: 	pp
				},{
                    "findThumbnail": true,
					"noReplace":     params.group ? false : true
                }			
			);
		}	
		
		// --------------------------------------------------------------------------------
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		// --------------------------
		function get_json( data, type ){
			
			if (type == '/')  return data;
		
			var p = type.split('/');

			var h = data;
			for (var i=0; i<p.length; i++) {
				if ( h[p[i]] ) { 
					h = h[p[i]];
				}
			}	

			return h;
		}
			
		// --------------------------
		function get_base_url( url, data ){
			
			if (data == '/')  return url;
		
			var k = url.indexOf('?');
			if ( k != -1 ) url = url.substring(0,k);
			var u = url.split('/');
		
			var p = data.split('/');

			var h = url;
			for (var i=0; i<p.length; i++) {
				if ( p[i] == '' ) { 
					u.length--;
				}
				else if ( p[i] == '..' ) { 
					u.length--;
				}
				else {
					u.push(p[i]);	
				}	
			}	

			return u.join('/');
		}
		
		// ====================================================================	
		this.getMedia = function( media ){
			
			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "MediaMaster" ) {
											var iii = find( item ); 
											if (iii == -1) stream_media.push( item );
											else stream_media[iii] = item;
										}	
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
			
			function find( e ) {
				for (var ii=0; ii<stream_media.length; ii++) {
					if (stream_media[ii].quality == e.quality && stream_media[ii].groupId == e.groupId)  return ii;	
				}	
				return -1;
			}
		}

	};
	
	fvdSingleDownloader.Media.MediaMaster = new MediaMaster();
	
})( );
