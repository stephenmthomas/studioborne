(function(){
	
	var MediaStream = function(){		
	
		const DEBUG = false;
		
		const TITLE_MAX_LENGTH  = 96;
	
		var self = this;
		
		const IGNORE_URL_SIGNS = [
			"twitch.tv",
			"periscope.tv",
		];
		
		const CODECS = {'mp4a': 'mp4', 
						'avc1':	'mp4'
					   };
					   
		const EXT_PATTERN = new RegExp("\\.([a-z0-9]{1,5})(?:\\?|#|$)", "i");
		const NAME_PATTERN = new RegExp("/([^/]+?)(?:\\.([a-z0-9]{1,5}))?(?:\\?|#|$)", "i");
		
		// http://www.metacafe.com/watch/7675591/lindsay_lohan_to_pose_nude/
		// http://www.tvn-2.com/videos/entrevistas/Expertas-necesidad-legisle-matrimonio-igualitario_2_4727547220.html
		
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			if( /^https?:\/\/[^\?]*\.m3u8/.test(data.url) )  {		// http://www.metacafe.com/watch/11465107/sexy-contestant-ends-up-topless-on-brazilian-gameshow/
				return 1;
			}   
			else if(data.contentType && data.contentType.toLowerCase().indexOf("mpegurl")>=0) {
				return 1;
			}       
			else if( /^https?:\/\/(.*)\.ts/.test(data.url) )  {
				return -1;            
			}    
			else if (data.contentType == 'video/MP2T')  {
				return -1;
			} 
			else if( /media\.sndcdn\.com\/(.*)\.mp3/.test(data.url) )  {
				return -1;            
			}    
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			var ignore = false;
			IGNORE_URL_SIGNS.forEach(function( sign ){
				if( data.url.toLowerCase().indexOf( sign ) != -1 ){
					ignore = true;
					return false;
				}
				if( data.tab.url.toLowerCase().indexOf( sign ) != -1 ){
					ignore = true;
					return false;
				}
			});
			if( ignore )			return false;

			if( t == 1 )  {
				parse_m3u8PlayList(data);
			}	

			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function parse_m3u8PlayList( data ){
			
			var url = data.url;
			var hh = hex_md5(url);
			var videoTitle = data.tabTitle;
			if (DEBUG) console.log(url);

			var domain = null, k, tt, host = "", prot = "";
			var x = fvdSingleDownloader.Utils.parse_URL(url);
			
			host = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '') + x.path+'/';
			domain = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '');
			search = x.search || "";
			
			getAJAX( url, null, function(content){
				
				_parse(content);
				
			});
			
			// ----------------------------------
			function _parse(content) {

				var lines = content.split('\n');

				if ( lines.length<2 ) return;
				if ( lines[0].replace(/\r/, '') != '#EXTM3U' ) return;

				var version_m3u8 = 3;
				var master_m3u8 = true;

				var ll = [];

				for (var i=0; i<lines.length; i++) {

					var line = lines[i].trim().replace(/\r/g,'');
					if (line=="")    continue;
					ll.push(line)

					if (line[0]=="#") {

						if( line.indexOf("#EXT") != 0 )   continue;

						var m = line.match( /^#(EXT[^\s:]+)(?::(.*))/i ); 
						if(!m)    continue;

						if ( m[1]=="EXTINF" )  master_m3u8 = false;

					}
				}  

				if ( master_m3u8 ) {
					_parse_master( ll );
				}
				else {
					_parse_inf( ll );
				}
				

			}	
			
			// ---------------------------
			function _parse_master(lines) {

				if (DEBUG) console.log(lines)				

				var streams = [];
				var audio = {};

				for (var i=0; i<lines.length; i++) {

					var line = lines[i];
					if (DEBUG) console.log(line);     

					if (line=="")    continue;

					if (line[0]=="#") {

						if( line.indexOf("#EXT") != 0 )   continue;

						var m = line.match( /^#(EXT[^\s:]+)(?::(.*))/i ); 
						if(!m)    continue;

						var name = m[1];
						var value = m[2];

						if ( name === 'EXT-X-MEDIA' ) {
							var x = fvdSingleDownloader.Utils.get_X_INF( value );

							if ( x['TYPE'] == 'AUDIO' ) {
								var grp = x['GROUP-ID'];
								var uri = x['URI'];

								audio[grp] = { url: uri };
							}    
						}
						else if ( name === 'EXT-X-STREAM-INF' ) {
							var x = fvdSingleDownloader.Utils.get_X_INF( value );
							var u = lines[i+1];
							i++;

							var pp = { url: u };
							if ( x['RESOLUTION'] )  pp.resolution = x['RESOLUTION'];
							if ( x['BANDWIDTH'] )  pp.bandwidth = x['BANDWIDTH'];
							if ( x['CODECS'] )  pp.codecs = x['CODECS'];
							if ( x['FRAME-RATE'] )  pp.rate = x['FRAME-RATE'];
							if ( !pp.resolution && x['NAME'] )  pp.resolution = x['NAME'];

							if ( x['AUDIO'] )  pp.audio = x['AUDIO'];

							streams.push( pp );
						}
					}
				} 
				

				var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId(); 

				for (var i=0; i<streams.length; i++) {

					if (DEBUG) console.log(streams[i]);

					var url = streams[i].url;
					if (url.indexOf('http') != 0) {
						if (url.indexOf('/') == 0)  url = domain + url;
						else    url = host + url;
					}   
					var hash = hex_md5(url);

					if (url.indexOf('?') == -1 && url.indexOf('#') == -1 && search) {
						url = url + search;
					}
		 
					var audio_stream = null;
					ext = 'mp4'; 
					var fileName = hash;
					var w = NAME_PATTERN.exec(url);
					if (w)  fileName = w[1];

					if (streams[i].audio) {
						var x = streams[i].audio in audio ? audio[ streams[i].audio ] : null;
						var uri = x ? x.url : null;
						if (uri) {
							if (uri.indexOf('http') != 0) {
								if (uri.indexOf('/') == 0)  uri = domain + uri;
								else    uri = host + uri;
							}   
							if (uri.indexOf('?') == -1 && uri.indexOf('#') == -1 && search) {
								uri = uri + search;
							}
							audio_stream = { hash:     streams[i].audio,
											 ext:      'mp4', 
											 url:      uri,          };
						}					 
					}   

					var quality = streams[i].resolution ? streams[i].resolution : (streams[i].bandwidth ? streams[i].bandwidth : null);	

					addMedia({  hash: hash,
								url: url, 
								fileName: fileName, 
								fileExt:   ext, 
								thumbnail:  data.thumbnail, 
								quality:   quality, 
								group: groupMedia,
								audio_stream: audio_stream,
								data: data });

				}    

			}    

			// ---------------------------
			function _parse_inf(lines) {

				if ( lines[1] == '#EXT-X-VERSION:4' ) return;

				var url = data.url;    

				if (DEBUG) console.log('_parse_inf: ', url);
				var hash = hex_md5(url);
				ext = 'mp4'; 
				var fileName = 'media';

				for (var i=0; i<lines.length; i++) {

					var line = lines[i];
					if (DEBUG) console.log(line);     
					if (line=="")    continue;

					if (line.indexOf('#') != 0) { 

						var u = line.replace(/\r/g,'');
						var x = fvdSingleDownloader.Utils.extractPath( u );
						if (x) ext = x.ext;

						if (ext === 'm3u8')  return; 

						break;
					}    
				}         

				var fileName = hash;
				var w = NAME_PATTERN.exec(url);
				if (w)  fileName = w[1];

				addMedia({  hash: hash,
							url: url, 
							fileName: fileName, 
							fileExt: ext, 
							thumbnail: data.thumbnail, 
							quality: null, 
							group: null,
							duration: null,
							data: data	});

			}            
			
		}	
		
		// --------------------------------------------------------------------------------
		function addMedia( params ){

			if (DEBUG) console.log('addMedia', params);
			
			// если видео и звук разделены - то не будет ссылки
			if (params.audio_stream)  return;
			
			var q = null;
			if (params.quality) {
				var m = params.quality.match( /([0-9]+)x([0-9]+)/im ); 
				q = m ? m[2] : params.quality; 
				try { q = parseInt(q);	} catch(ex) {}		
			} 

			var ft = [{tag: 'span', content: '[' },
					  {tag: 'span', content: (params.quality ? params.quality+', ' : '') },
					  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(params.fileExt) }, 	
					  {tag: 'span', content: '] ' }	];
					
			var displayName = params.data.tabTitle ? params.data.tabTitle : params.fileName;
			var downloadName = displayName;

			var fileName = null;	
			if (params.fileName) {
				fileName = params.fileName;
			}	
			else {
				fileName = params.quality;
				var ff = fvdSingleDownloader.Utils.extractPath( params.url );
				if (ff) {
					fileName = (params.quality ? params.quality+'_' : '')+ff.name;
				}					
				else {
					fileName = (params.quality ? '['+params.quality+'] ' : '')+params.data.tabTitle;	
				}	
			}
			
			var pp = null;
			if (params.audio_stream) {
				pp ={"audio_stream":     params.audio_stream };
			}
			
			fvdSingleDownloader.Media.Storage.add( {
					url: 		params.url,
					tabId: 		params.data.tabId,
					tabUrl: 	params.data.tabUrl,
					frameId: 	params.data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	params.data.thumbnail,
					
					ext: 		params.fileExt,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					playlist:       params.playlist ? params.playlist : null,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"video",
					metod: 		'stream',
					source: 	"MediaStream",
					quality:    q,
					
					groupId: 	params.group,
					orderField: q,
					dwnl:		1,
					
					params: 	pp
				},{
                    "findThumbnail": true,
					"noReplace":     params.group ? false : true
                }			
			);
		}	
		
		// --------------------------------------------------------------------------------
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		// --------------------------
		function get_base_url( url, data ){
			
			if (data == '/')  return url;
		
			var k = url.indexOf('?');
			if ( k != -1 ) url = url.substring(0,k);
			var u = url.split('/');
		
			var p = data.split('/');

			var h = url;
			for (var i=0; i<p.length; i++) {
				if ( p[i] == '' ) { 
					u.length--;
				}
				else if ( p[i] == '..' ) { 
					u.length--;
				}
				else {
					u.push(p[i]);	
				}	
			}	

			return u.join('/');
		}
		
		// ====================================================================	
		this.getMedia = function( media ){
			
			return media;
			
			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "MediaStream" ) {
											var iii = find( item ); 
											if (iii == -1) stream_media.push( item );
											else stream_media[iii] = item;
										}	
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
			
			function find( e ) {
				if ( !e.quality ) return -1;
				for (var ii=0; ii<stream_media.length; ii++) {
					if (stream_media[ii].quality == e.quality && stream_media[ii].groupId == e.groupId)  return ii;	
				}	
				return -1;
			}
		}

	};
	
	fvdSingleDownloader.Media.MediaStream = new MediaStream();
	
})( );
