(function(){
	
	var Twitch = function(){		
	
		const TITLE_MAX_LENGTH  = 96;
		
		const DEBUG = false;
	
		var mediaDetectCallbacks = [];

		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url.toLowerCase();
			
			if( /\/api\/channel\/(.+?)\.m3u8/.test(url) ) {
				return 1;
			}        
			else if( /periscope\.tv(.*)\/playlist.m3u8/.test(url) ) {
				return 2;
			}        
			else if( /https:\/\/replay\.periscope\.tv\/(.*).m3u8/.test(url) ) {
				return 2;
			}        
			else if( /\/periscope-replay-direct-live\/playlist_(.+?).m3u8/.test(url) ) {
				return 2;
			}        
			else if( /\.pscp\.tv\/(.*).m3u8/.test(url) ) {
				return 2;
			}        
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			if( t == 1 )  {
				detectTwitch(data);
			}	
			else if( t == 2 )  {
				detectPeriscope(data);
			}
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectTwitch( media ){
		
			tabInfo = media.tab;
			if (DEBUG) console.log("TWITCHTEST FOUND STREAM: ", media );
			
			var url = media.url;
			var videoId = null;

			try {		
				var root_url = media.tab.url;
				var k = root_url.indexOf('?');
				if (k != -1) 	root_url = root_url.substring(0, k);
				videoId =/([^\/]+)$/.exec(root_url)[1];
			}
			catch( ex )	{
				//dump( "Exception videoId: " + ex +'\n' );
			}
			if (!videoId) {
				var k = url.indexOf('.m3u8');
				if (k != -1) {
					var t = url.substring(0, k);
					var videoId=/([^\/]+)$/.exec(t)[1];
				}	
			}
			if (DEBUG) console.log('videoId = ',videoId);
			
			var videoTitle  = media.tab.title;
			
			getStream( videoId, url );
		

			// ---------------------
			function getStream( videoId, url ){
				
				if (DEBUG) console.log(url);

				getPlayListTwitch( videoId, url, function( content ) {  
				
						var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     

						var line = content.split('\n');
						var kk = line.length;
						for (var i=0; i<kk; i++) 	{
							if (line[i] == '') continue;
							
							var m = line[i].match( /^#(EXT[^\s:]+)(?::(.*))/i ); 
							if (m) {
								var name = m[1];
								var value = m[2];
								var resolution = '';
								if (name == 'EXT-X-STREAM-INF') {
									var x = fvdSingleDownloader.Utils.get_X_INF( value );
									if (x) {
										if ( x['RESOLUTION'] )  resolution = x['RESOLUTION'];
										
										var url_PL = line[i+1];
										
										if (url_PL) {

											var ext="ts";
											var hash = videoId+'_'+resolution;
											
											addMedia({  hash: hash,
														videoId: videoId,
														url: url_PL, 
														label: resolution,
														fileName: hash,
														fileExt: ext, 
														group: groupMedia,
														data: media
													 });
										}
									}
								}    
							}
						}
				});
			}	
		}
		
		// --------------------------------------------------------------------------------
		function detectPeriscope( media ){
		
			tabInfo = media.tab;
			if (DEBUG) console.log("PERISCOPETEST FOUND MEDIA: ", media );
			
			var url = media.url;
			var videoId = null;

			try {		
				var root_url = media.tabUrl;
				var k = root_url.indexOf('?');
				if (k != -1) 	root_url = root_url.substring(0, k);
				videoId =/([^\/]+)$/.exec(root_url)[1];
			}
			catch( ex )	{
				//dump( "Exception videoId: " + ex +'\n' );
			}
			
			if (!videoId) {
				var k = url.indexOf('.m3u8');
				if (k != -1) {
					var t = url.substring(0, k);
					var videoId=/([^\/]+)$/.exec(t)[1];
				}	
			}
			if (DEBUG) console.log('videoId = ',videoId);
			
			var hh = hex_md5(url);			

			addMedia({  hash: hh,
						videoId: videoId,
						url: url, 
						fileName: hh,
						fileExt: "mp4", 
						data: media
					 });

		}
		
		// --------------------------------------------------------------------------------
		function getPlayListTwitch( id, url, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}

		// --------------------------------------------------------------------------------
		function addMedia( params ){

			if (DEBUG) console.log('addMedia', params);
			
			var q = null;
			if (params.label) {
				var m = params.label.match( /([0-9]+)x([0-9]+)/im ); 
				q = m ? m[2] : params.label;
				try { q = parseInt(q);	} catch(ex) {}		
			} 

			var ft = [{tag: 'span', content: '[' },
					  {tag: 'span', content: (params.label ? params.label+', ' : '') },
					  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(params.fileExt) }, 	
					  {tag: 'span', content: '] ' }	];
			
			var displayName = params.data.tabTitle ? params.data.tabTitle : params.fileName;
			var downloadName = displayName;

			var fileName = null;	
			if (params.fileName) {
				fileName = params.fileName;
			}	
			else {
				fileName = params.label;
				var ff = fvdSingleDownloader.Utils.extractPath( params.url );
				if (ff) {
					fileName = (params.label ? params.label+'_' : '')+ff.name;
				}					
				else {
					fileName = (params.label ? '['+params.label+'] ' : '')+params.data.tabTitle;	
				}	
			}
			
			fvdSingleDownloader.Media.Storage.add( {
					url: 		params.url,
					tabId: 		params.data.tabId,
					tabUrl: 	params.data.tabUrl,
					frameId: 	params.data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	params.data.thumbnail,
					
					ext: 		params.fileExt,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"video",
					metod: 		'record',
					source: 	"Twitch",
					quality:    q,
					
					groupId: 	params.group,
					orderField: q,

					dwnl:		1,
				},{
                    "findThumbnail": false,
					"noReplace":     false
                }			
			);
		}	
		
		
		// -----------------------------------------------------------
		this.onMediaDetect = {
			addListener: function( callback ){
				if( mediaDetectCallbacks.indexOf( callback ) == -1 )
				{
					mediaDetectCallbacks.push( callback );
				}
			}
		};
		
		// ====================================================================	
		this.getMedia = function( media ){

			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "Twitch" )   stream_media.push( item );
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
		}

				
	};
	
	fvdSingleDownloader.Media.Twitch = new Twitch();
	
})( );
