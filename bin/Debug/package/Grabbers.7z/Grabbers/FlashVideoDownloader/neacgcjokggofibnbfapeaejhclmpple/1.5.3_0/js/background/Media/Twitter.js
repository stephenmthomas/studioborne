(function(){
	
	var Twitter = function(){		
	
		const DEBUG = false;
		const TITLE_MAX_LENGTH  = 96;
		const EXT_PATTERN = new RegExp("\\.([a-z0-9]{1,5})(?:\\?|#|$)", "i");
		const NAME_PATTERN = new RegExp("/([^/]+?)(?:\\.([a-z0-9]{1,5}))?(?:\\?|#|$)", "i");
	
		var tw_video_thumb = {};

		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url.toLowerCase();
			
			if( /^https?:\/\/video\.twimg\.com\/[^\?]*\.m3u8/.test(url) )  {
				return 1;
			}   
			else if( /^https?:\/\/pbs\.twimg\.com\/ext_tw_video_thumb\/(.+?)\.jpg/.test(url) )  {
				var m = url.match(/ext_tw_video_thumb\/([^\/]*)/i);
				if (m) {
					tw_video_thumb[m[1]] = data.url;	
				}	
				return -1;            
			}    
			else if( /https?:\/\/video\.twimg\.com\/(.*)\.ts/.test(url) )  {
				return -1;            
			}    
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			if( t == 1 )  {
				detectTwitter(data);
			}	
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectTwitter( data ){
		
			var url = data.url;
			var hh = hex_md5(url);
			var videoTitle = data.tabTitle;
			if (DEBUG) console.log(url);

			var domain = null, k, tt, host = "", prot = "";
			var x = fvdSingleDownloader.Utils.parse_URL(url);
			
			host = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '') + x.path+'/';
			domain = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '');
			search = x.search || "";
			var groupMedia;
			
			getAJAX( url, null, function(content){
				
				_parse(content);
				
			});
		

			// ---------------------
			function _parse( content ){
				
				var lines = content.split('\n');

				if ( lines.length<2 ) return;
				if ( lines[0].replace(/\r/, '') != '#EXTM3U' ) return;

				var flag = 0;
				var file_name = null, ext = null;
				groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId(); 

				for (var i=0; i<lines.length; i++) {

					var line = lines[i].trim().replace(/\r/g,'');
					if (line.indexOf('#') == 0)  continue;
					
					if (!flag) {
						var k = line.indexOf('.m3u8');
						if ( k != -1 )  flag = 1;           // playlist
						else            flag = 2;           // fragment
					}
					
					if (flag == 1)  {

						var w = NAME_PATTERN.exec(line);
						if (w)  file_name = w[1];
						var l = EXT_PATTERN.exec(line);
						if (l) ext = l[1];

						if (line.indexOf('http') != 0) {
							if (line.indexOf('/') == 0)  line = domain + line;
							else    line = host + line;
						}   
						if (line.indexOf('?') == -1 && search) {
							line = line + search;
						}    

						_add(line, file_name);    
					}
					else if (flag == 2)  {
						var w = NAME_PATTERN.exec(url);
						if (w)  file_name = w[1];
						var l = EXT_PATTERN.exec(url);
						if (l) ext = l[1];
						//_add(url, file_name);
						break;
					}

				}  

			}	
			
			// ---------------------
			function _add( url, file_name ){

				if (DEBUG) console.log('addMedia', url, file_name);
				
				var n = url.match(/\/([0-9]+)\//i);
				var videoId = n ? n[1] : file_name;
				n = url.match(/\/([0-9]+)x([0-9]+)\//i);
				var quality = n ? { width: parseInt(n[1]), height: parseInt(n[2]) } : null;
				var hash = videoId + '_' + (quality ? quality.height : file_name);
				var ext = 'mp4';
				
				if (!quality) return;

				var thumbnail = tw_video_thumb[videoId] ? tw_video_thumb[videoId] : data.thumbnail;
		
				var ft = [{tag: 'span', content: '[' },
						  {tag: 'span', content: (quality ? quality.width+'x'+quality.height+', ' : '') },
						  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(ext) }, 	
						  {tag: 'span', content: '] ' }	];
						  
				var displayName = data.tabTitle ? data.tabTitle : file_name;
				var downloadName = displayName;

				var fileName = file_name;	
				var q = quality ? quality.width : null;
				
				fvdSingleDownloader.Media.Storage.add( {
						url: 		url,
						tabId: 		data.tabId,
						tabUrl: 	data.tabUrl,
						frameId: 	data.frameId,
						
						hash: 		hash,
						thumbnail: 	thumbnail,
						
						ext: 		ext,
						title: 		displayName,
						format: 	"",
						
						downloadName: 	downloadName,
						displayName: 	displayName,
						displayLabel: 	ft,
						filename: 		fileName,
						
						priority: 	10,
						vubor:  	0,
						size: 		0,
						type: 		"video",
						metod: 		'stream',
						source: 	"Twitter",
						quality:    q,
						
						groupId: 	groupMedia,
						orderField: q,

						dwnl:		1,
					},{
						"findThumbnail": false,
						"noReplace":     false
					}			
				);
				
		
			}	
		}

		// --------------------------------------------------------------------------------
		function addMedia( params ){

			if (DEBUG) console.log('addMedia', params);
			
			var q = null;
			if (params.label) {
				var m = params.label.match( /([0-9]+)x([0-9]+)/im ); 
				q = m ? m[2] : params.label;
				try { q = parseInt(q);	} catch(ex) {}		
			} 
			
			var ft = [{tag: 'span', content: '[' },
					  {tag: 'span', content: (params.label ? params.label+', ' : '') },
					  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(params.fileExt) }, 	
					  {tag: 'span', content: '] ' }	];
			
			var displayName = params.data.tabTitle ? params.data.tabTitle : params.fileName;
			var downloadName = displayName;

			var fileName = null;	
			if (params.fileName) {
				fileName = params.fileName;
			}	
			else {
				fileName = params.label;
				var ff = fvdSingleDownloader.Utils.extractPath( params.url );
				if (ff) {
					fileName = (params.label ? params.label+'_' : '')+ff.name;
				}					
				else {
					fileName = (params.label ? '['+params.label+'] ' : '')+params.data.tabTitle;	
				}	
			}
			
			fvdSingleDownloader.Media.Storage.add( {
					url: 		params.url,
					tabId: 		params.data.tabId,
					tabUrl: 	params.data.tabUrl,
					frameId: 	params.data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	params.data.thumbnail,
					
					ext: 		params.fileExt,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"video",
					metod: 		'record',
					source: 	"Twitch",
					quality:    q,
					
					groupId: 	params.group,
					orderField: q,

					dwnl:		1,
				},{
                    "findThumbnail": false,
					"noReplace":     false
                }			
			);
		}	
		
		
		// -----------------------------------------------------------
		this.onMediaDetect = {
			addListener: function( callback ){
				if( mediaDetectCallbacks.indexOf( callback ) == -1 )
				{
					mediaDetectCallbacks.push( callback );
				}
			}
		};
		
		// ====================================================================	
		this.getMedia = function( media ){

			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "Twitch" )   stream_media.push( item );
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
		}

		// --------------------------------------------------------------------------------
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
				
	};
	
	fvdSingleDownloader.Media.Twitter = new Twitter();
	
})( );
