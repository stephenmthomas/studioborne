(function(){
	
	var VKontakte = function(){		
	
		const TITLE_MAX_LENGTH  = 96;
	
		var mediaDetectCallbacks = [];
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url.toLowerCase();
			
			if(/^https?:\/\/vk\.com\/al_video\.php/i.test(data.url)) {
				return 1;
			}        
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			if( t == 1 && data.method == "POST" )  {
				detectVideo(data);
			}	
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectVideo( data ){
			
			var groupMedia = null;
			var formData = data.requestBody.formData;
			if ( 'video' in formData ) {	
			
				postAJAX( data.url, formData, function(content){
					
					groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     
					
					var m = content.match( /<!json>{(.+?)}<!>/i ); 
					if (m) {
						var x = JSON.parse( '{' + m[1] + '}' ); 
					
						var info = x['mvData'];

						var videoId = info["videoRaw"];
						var title = info["title"].replace(/&(.+?);/gm,'').trim();

						var player = x['player'];
						info = player.params[0];
						var thumb = info['thumb'] || info['jpg'];
						
						if (info["url240"])  _create(info["url240"],  videoId, title,  '240',  thumb);
						if (info["url360"])  _create(info["url360"],  videoId, title,  '360',  thumb);
						if (info["url480"])  _create(info["url480"],  videoId, title,  '480',  thumb);
						if (info["url720"])  _create(info["url720"],  videoId, title,  '720',  thumb);
						if (info["url1080"]) _create(info["url1080"], videoId, title, '1080', thumb);
						
					}	

				});				
			}	
			
			// -----------------
			function _create(url, videoId, ft, q, thumb) {
				
				var ff = fvdSingleDownloader.Utils.extractPath( url );
				if (ff) {
					
					var fl = [{tag: 'span', content: '[' },
							  {tag: 'span', content: q },
							  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(ff.ext) }, 	
							  {tag: 'span', content: '] ' }	];
					
					fvdSingleDownloader.Media.Storage.add( {
							url: 		url,
							tabId: 		data.tabId,
							tabUrl: 	data.tab.url,
							frameId: 	data.frameId,
							
							thumbnail: 	thumb || data.thumbnail,
							
							ext: 		ff.ext,
							title: 		ft,
							format: 	"",
							quality: 	q,
							
							downloadName: 	ft,
							displayName: 	ft,
							displayLabel: 	fl,
							filename: 		ff.name,
							
							priority: 	10,
							vubor:  	0,
							size: 		null,
							type: 		"video",
							metod: 		"download",
							source: 	"VKontakte",
							groupId: 	groupMedia,
							dwnl:		1,
							orderField:     q
						},{
							"findThumbnail": false
						});			
				}    
			}
		
		}
		
		this.onMediaDetect = {
			addListener: function( callback ){
				if( mediaDetectCallbacks.indexOf( callback ) == -1 )
				{
					mediaDetectCallbacks.push( callback );
				}
			}
		};
		
		// --------------------------------------------------------------------------------
		function postAJAX( url, data, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('POST', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			ajax.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			var l = [];
			for (var k in data) l.push(k + '=' + data[k]);
			
			ajax.send( l.join('&') );
		
		}

		// ====================================================================	
		this.getMedia = function( media ){

			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "VKontakte" )   stream_media.push( item );
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
		}

	};
	
	fvdSingleDownloader.Media.VKontakte = new VKontakte();
	
})( );

