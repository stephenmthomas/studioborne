(function(){
	
	var Vimeo = function(){		
	
		const TITLE_MAX_LENGTH  = 96;
		
		const ENABLE_STREAM_LINK = false;
	
		var mediaDetectCallbacks = [];
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}

		function check_media(data) {
			
			var url = data.url.toLowerCase();

	        if ( /player\.vimeo\.com\/video\/(.*)\/config/i.test(data.url) )   {
				return 1;
			}  
			else if ( /\.vimeocdn\.com\/(.+?)\/master\.json/i.test(data.url) )  {
				return 2;
			}
			else if ( /\.vimeocdn\.com\//i.test(data.url) )  {
				return 0;
			}
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			if( t == 1 )  {
				detectVimeoVideo(data);
			}	
			else if( t == 2 )  {
				detectVimeoJson(data);
			}	
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectVimeoJson( data ){

		    var url = data.url,
		        tabUrl = data.tabUrl,
		        tabTitle = data.tabTitle,
		        videoId = null,
		        thumb = null;

			getAJAX( url, null, function(content){

				if (content) {

                    try {
                        var info = JSON.parse(content);
                    }                     
                    catch(ex) {
                        console.log(ex);
                        return;
                    }

                    videoId = fvdSingleDownloader.Utils.getJSON( info, 'clip_id' );
					
					var uu = 'https://player.vimeo.com/video/'+videoId+'/config?byline=0&collections=1&context=Vimeo%5CController%5CClipController.main&default_to_hd=1';

					getAJAX( uu, null, function(content){
					
						try {
							var infoJson = JSON.parse(content);
						}                     
						catch(ex) {
							console.log(ex);
							return;
						}

						parsed( infoJson, data );
						
					});

                }    
			});	


		}	
		
		// --------------------------------------------------------------------------------
		function detectVimeoVideo( data ){

		    var url = data.url;

			getAJAX( url, null, function(content){

				if (content) {

                    try {
                        var infoJson = JSON.parse(content);
                    }                     
                    catch(ex) {
                        console.log(ex);
                        return;
                    }


                    parsed( infoJson, data );

                }    
			});	

		}
		
		// --------------------------------------------------------------------------------
		function parsed( infoJson, data ) {

			var videoId = fvdSingleDownloader.Utils.getJSON( infoJson, 'video/id' );
			var title = fvdSingleDownloader.Utils.getJSON( infoJson, 'video/title' );
			var thumb = fvdSingleDownloader.Utils.getJSON( infoJson, 'video/thumbs/640' );
			var info = fvdSingleDownloader.Utils.getJSON( infoJson, 'request/files/progressive' );
		
			var mediaFound = false;

			if ( typeof info == 'object' && info.length ) {

				groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();

				for (var i=0; i<info.length; i++) {

					var u = info[i]['url'];

					if (u) {
						var height = info[i]['height'];
						var width = info[i]['width'];
						var hash = videoId+'_'+height;
						var fileName = data.fileName;
						var extension = "mp4";
						var ff = fvdSingleDownloader.Utils.extractPath( u );
						if (ff) {
							extension = ff.ext;
							fileName = ff.name;
						}	

						var ft = [{tag: 'span', content: '[' },
								  {tag: 'span', content: width+'x'+height },
								  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(extension) }, 	
								  {tag: 'span', content: '] ' }	];
						
						var displayName = data.tabTitle;
						var downloadName = displayName;

						fvdSingleDownloader.Media.Storage.add( {
								url: 		u,
								tabId: 		data.tabId,
								tabUrl: 	data.tabUrl,
								frameId: 	data.frameId,
								
								hash: 		hash,
								thumbnail: 	thumb ? thumb : data.thumbnail,
								
								ext: 		extension,
								title: 		displayName,
								format: 	"",
								
								downloadName: 	downloadName,
								displayName: 	displayName,
								displayLabel: 	ft,
								filename: 		fileName,
								
								priority: 		10,
								vubor:  		0,
								size: 			0,
								type: 			"video",
								metod: 			"download",
								source: 		"Vimeo",
								quality:    	height,
								
								groupId: 		groupMedia,
								orderField: 	height,
								dwnl:			1,
								
							},{
								"findThumbnail": false,
								"noReplace":     true
							}			
						);    

						mediaFound = true;
					}
				}
				
			}
		}
		
		// --------------------------------------------------------------------------------
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		// ====================================================================	
		this.getMedia = function( media ){
			
			if (ENABLE_STREAM_LINK)	return media;
			
			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			var vimeo_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "Vimeo" ) {
											var iii = find( item ); 
											if (iii == -1) vimeo_media.push( item );
										}	
										else if ( item.source == "MediaStream" || item.source == "MediaMaster" )  stream_media.push( item );
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});

			if (vimeo_media.length > 0) {
				stream_media.length == 0;	
			}	
			else {
				vimeo_media = stream_media;
			}
			
			if (vimeo_media.length > 0) {
				other_media.forEach(function( item ){	 vimeo_media.push( item )  });
				return vimeo_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
			
			function find( e ) {
				for (var ii=0; ii<vimeo_media.length; ii++) {
					if (vimeo_media[ii].quality == e.quality && vimeo_media[ii].groupId == e.groupId)  return ii;	
				}	
				return -1;
			}

		}

	};
	
	fvdSingleDownloader.Media.Vimeo = new Vimeo();
	
})( );

