(function(){
	
	var Youtube = function(){		
	
		const TITLE_MAX_LENGTH  = 96;
	
		var mediaDetectCallbacks = [];
		
		var parse_videoId = {};
		
	    var storage_code = {};
		
		var insertScript = {};
		
		// ================================================================================================================   
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url;
			
			// -- watch
			if ( /https?:\/\/(?:www\.)?youtube\.com\/watch.*[\?|&]v=([^\?&]+)/i.test(url)) {
				return 1;
			}	
			
			// -- user			
			if ( /https?:\/\/(?:www\.)?youtube\.com\/user\/.+?[\?&]v=([^&]+)/i.test(url)) {
				return 2;
			}	
			if ( /https?:\/\/(?:www\.)?youtube\.com\/user\/([^\/\?&]+)/i.test(url)) {
				return 2;
			}	
				
			// -- embeds
			if ( /:\/\/(?:www\.)?(?:youtube|youtube-nocookie)(?:\.googleapis)?\.com\/v\/([^\?&]+)/i.test(url)) {
				return 3;
			}	
			if ( /:\/\/(?:www\.)?(?:youtube|youtube-nocookie)\.com\/embed\/([^\?&]+)/i.test(url)) {
				return 3;
			}	

			// -- gaming
			if( /watch_fragments_ajax/i.test(url) ) {
				return -1;
			}	
			if(/^https?:\/\/(?:www\.)?youtube\.com\/get_video_info/i.test(url)) {
				return -1;
				//return 4;	
			}	
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return t;
			
			if( t == 1 )  {
				checkYoutubeWatch(data);
			}	
			else if( t == 2 )  {
				checkYoutubeChannel(data);
			}	
			else if( t == 3 )  {
				checkYoutubeEmbeds(data);
			}	
			else if( t == 4 )  {
				checkYoutubeGaming(data);
			}	
			
			return 1;
		}

		// ================================================================================================================   
		const ytf = {            
					5: 	 { title: "Low, 320x240", 	    frm: "flv", 	size: "240",   type: "download"	 },
					6: 	 { title: "Low, 360x270", 	    frm: "flv", 	size: "270",   type: "download"	 },
					13:  { title: "Mobile, 192x144",    frm: "3gp", 	size: "144",   type: "download"	 },
					17:  { title: "Mobile, 192x144",    frm: "3gp", 	size: "144",   type: "download"	 },
					18:  { title: "Low, 480x360", 	    frm: "mp4", 	size: "360",   type: "download"	 },
					22:  { title: "HD, 1280x720", 	    frm: "mp4", 	size: "720",   type: "download"	 },
					34:  { title: "Low, 480x360", 	    frm: "flv", 	size: "360",   type: "download"	 },
					35:  { title: "SD, 854x480", 	    frm: "flv", 	size: "480",   type: "download"	 },
					36:  { title: "Mobile, 320x240",    frm: "3gp", 	size: "240",   type: "download"	 },
					37:  { title: "Full HD, 1920x1080", frm: "mp4", 	size: "1080",  type: "download"	 },
					38:  { title: "4K, 4096x3072", 	    frm: "mp4", 	size: "3072",  type: "download"	 },
					43:  { title: "Low, 480x360", 	    frm: "webm", 	size: "360",   type: "download"	 },
					44:  { title: "SD, 854x480", 	    frm: "webm", 	size: "480",   type: "download"	 },
					45:  { title: "HD, 1280x720", 	    frm: "webm", 	size: "720",   type: "download"	 },
					46:  { title: "Full HD, 1920x1080", frm: "webm", 	size: "1080",  type: "download"	 },
					82:  { title: "3D Low, 640x360",    frm: "mp4", 	size: "360",   type: "download"	 },
					83:  { title: "3D Low, 320x240",    frm: "mp4", 	size: "240",   type: "download"	 },
					84:  { title: "3D HD, 1280x720",    frm: "mp4", 	size: "720",   type: "download"	 },
					85:  { title: "3D SD, 960x540",     frm: "mp4", 	size: "540",   type: "download"	 },
					100: { title: "3D Low, 640x360",    frm: 'webm',	size: "360",   type: "download"  },
					101: { title: "3D Low, 640x360",    frm: 'webm',	size: "360",   type: "download"  },
					102: { title: "3D HD, 1280x720",    frm: 'webm',	size: "720",   type: "download"  },
					
					// Apple HTTP Live Streaming
					91:  { title: "Mobile, 192x144, Stream",    frm: 'mp4',     size: "144",   type: "record" },
					92:  { title: "Low, 320x240, Stream",       frm: 'mp4',     size: "240",   type: "record" },
					93:  { title: "Low, 640x360, Stream",       frm: 'mp4',     size: "360",   type: "record" },
					94:  { title: "SD, 854x480, Stream",        frm: 'mp4',     size: "480",   type: "record" },
					95:  { title: "HD, 1280x720, Stream",       frm: 'mp4',     size: "720",   type: "record" },
					96:  { title: "Full HD, 1920x1080, Stream", frm: 'mp4',     size: "1080",  type: "record" },
					132: { title: "Low, 320x240, Stream",       frm: 'mp4',     size: "240",   type: "record" },
					151: { title: "Low, 96x72, Stream",         frm: 'mp4',     size: "72",    type: "record" },
					
					/*134: { title: "Low, 640x360",       frm: 'mp4',     size: "360",   type: 'convert',  note: 'video', adp: [139,140,141], },
					133: { title: "3D Low, 320x240",    frm: 'mp4',     size: "240",   type: 'convert',  note: 'video', adp: [139,140,141], },
					135: { title: "SD, 854x480",        frm: 'mp4',     size: "480",   type: 'convert',  note: 'video', adp: [139,140,141], },
					136: { title: "HD, 1280x720",       frm: 'mp4',     size: "720",   type: 'convert',  note: 'video', adp: [139,140,141], },
					160: { title: "Mobile, 192x144",    frm: 'mp4',     size: "144",   type: 'convert',  note: 'video', adp: [139,140,141], },
					298: { title: "HD, 1280x720",       frm: 'mp4',     size: "720",   type: 'convert',  note: 'video', adp: [139,140,141], },
					137: { title: "Full HD,1920x1080",  frm: 'mp4',     size: "1080",  type: 'convert',  note: 'video', adp: [139,140,141], },

					264: { title: "Full HD,2560x1440",  frm: 'mp4',     size: "1440",  type: 'convert',  note: 'video', adp: [139,140,141], },
					299: { title: "Full HD,1920x1080",  frm: 'mp4',     size: "1080",  type: 'convert',  note: 'video', adp: [139,140,141], },
					266: { title: "4K, 3840x2160",      frm: 'mp4',     size: "2160",  type: 'convert',  note: 'video', adp: [139,140,141], },
					
					167: { title: "Low, 640x360",       frm: 'webm',    size: "360",   type: 'convert',  note: 'video', adp: [171,172], },
					168: { title: "SD, 854x480",        frm: 'webm',    size: "480",   type: 'convert',  note: 'video', adp: [171,172], },
					169: { title: "HD, 1280x720",       frm: 'webm',    size: "720",   type: 'convert',  note: 'video', adp: [171,172], },
					170: { title: "HD, 1920x1080",      frm: 'webm',    size: "1080",  type: 'convert',  note: 'video', adp: [171,172], },
					218: { title: "SD, 854x480",        frm: 'webm',    size: "480",   type: 'convert',  note: 'video', adp: [171,172], },
					219: { title: "SD, 854x480",        frm: 'webm',    size: "480",   type: 'convert',  note: 'video', adp: [171,172], },
					278: { title: "Mobile, 256x144",    frm: 'webm',    size: "144",   type: 'convert',  note: 'video', adp: [171,172], },
					242: { title: "3D Low, 320x240",    frm: 'webm',    size: "240",   type: 'convert',  note: 'video', adp: [171,172], },
					243: { title: "Low, 320x240",       frm: 'webm',    size: "240",   type: 'convert',  note: 'video', adp: [171,172], },
					244: { title: "SD, 854x480",        frm: 'webm',    size: "480",   type: 'convert',  note: 'video', adp: [171,172], },
					245: { title: "SD, 854x480",        frm: 'webm',    size: "480",   type: 'convert',  note: 'video', adp: [171,172], },
					246: { title: "SD, 854x480",        frm: 'webm',    size: "480",   type: 'convert',  note: 'video', adp: [171,172], },
					247: { title: "HD, 1280x720",       frm: 'webm',    size: "720",   type: 'convert',  note: 'video', adp: [171,172], },
					271: { title: "HD, 2560x1440",      frm: 'webm',    size: "1440",  type: 'convert',  note: 'video', adp: [171,172], },
					302: { title: "HD, 1280x720",       frm: 'webm',    size: "720",   type: 'convert',  note: 'video', adp: [171,172], },
					303: { title: "HD, 1920x1080",      frm: 'webm',    size: "1080",  type: 'convert',  note: 'video', adp: [171,172], },
					248: { title: "Full HD,1920x1080",  frm: 'webm',    size: "1080",  type: 'convert',  note: 'video', adp: [171,172], },
					308: { title: "Full HD,2560x1440",  frm: 'webm',    size: "1440",  type: 'convert',  note: 'video', adp: [171,172], },
					272: { title: "4K, 3840x2160",      frm: 'webm',    size: "2160",  type: 'convert',  note: 'video', adp: [171,172], },
					313: { title: "4K, 3840x2160",      frm: 'webm',    size: "2160",  type: 'convert',  note: 'video', adp: [171,172], },
					315: { title: "4K, 3840x2160",      frm: 'webm',    size: "2160",  type: 'convert',  note: 'video', adp: [171,172], },
					
					139: { title: "[139]",         frm: 'mp3',      size: "n/a",    type: 'audio',   acodec: 'aac',      },
					140: { title: "[140]",         frm: 'mp3',      size: "n/a",    type: 'audio',   acodec: 'aac',      },
					141: { title: "[141]",         frm: 'mp3',      size: "n/a",    type: 'audio',   acodec: 'aac',      },
					171: { title: "[171]",         frm: 'webm',     size: "n/a",    type: 'audio',   acodec: 'vorbis',   },
					172: { title: "[172]",         frm: 'webm',     size: "n/a",    type: 'audio',   acodec: 'vorbis',   }, 
					249: { title: "[249]",         frm: 'webm',     size: "n/a",    type: 'audio',   acodec: 'opus',     }, 
					250: { title: "[250]",         frm: 'webm',     size: "n/a",    type: 'audio',   acodec: 'opus',     }, 
					251: { title: "[251]",         frm: 'webm',     size: "n/a",    type: 'audio',   acodec: 'opus',     }, 
					256: { title: "[256]",         frm: 'mp3',      size: "n/a",    type: 'audio',   acodec: 'aac',      }, 
					258: { title: "[258]",         frm: 'mp3',      size: "n/a",    type: 'audio',   acodec: 'aac',      },*/ 
					
				}

		
		// ================================================================================================================   
		var SignatureDecryptor = function(tabId, ytVideoId) {

			var scheme = "http";
		
			var playerContents = "";
			var playerUrl = "";
		  
			var funcName = "";
			var player_type, player_id;
			
			
			this.decrypt = function(page, s, cb) {
			  
				var req_url = 'https://www.youtube.com/watch?v='+ytVideoId+'&gl=US&hl=en&has_verified=1&bpctr=9999999999'
				
				fvdSingleDownloader.Utils.Async.chain([
					function(next) {
						var timer = setTimeout( function(){
							next();
						}, 500);	
						
						var port = chrome.tabs.connect( tabId );
						port.postMessage({action: 'get', sig: s})	
						port.onMessage.addListener(function( message ){
								clearTimeout(timer); timer = null;
								cb(null, message.dsig);
						});
					},	
					function(next) {
					
						var m = page.match(/"assets":.+?"js":\s*("[^"]+")/);
						if (!m) {
							return cb(new Error("Fail get assets"));	
						}
						var u = m[1].replace(/\"/g,'').replace(/\\/g, "");
						if(u.indexOf('youtube.com') == -1)   u = scheme + '://www.youtube.com' + u;
						if(u[0] == "/")   u = 'https:' + u;

						if (playerUrl == u && playerContents != '') {
						  return next();
						}	
					
						var ajax = new XMLHttpRequest();
						ajax.open('GET', u, true);
						
						ajax.onload = function(){

								  playerUrl = u;
								  playerContents = this.responseText;
								  
								  playerContents = playerContents.trim();
								  playerContents = playerContents.replace(/^var\s*_yt_player=\{\s*\};\s*\(function\s*\([a-z]\)\{/, "var _yt_player={}; var g = _yt_player;");
								  playerContents = playerContents.replace('})(_yt_player);', "");
								  
								  //console.log(playerContents.substr(0, 100)+"\n");
								  //console.log("..."+playerContents.substr(playerContents.length-100, 100)+"\n");
								  
								  next();
							
								}
						
						ajax.onerror = function(err){
									cb( err );
								}
						
						ajax.send( null );
					},
					function(next) {
						var m = playerUrl.match(/.*?-([a-zA-Z0-9_-]+)\/(watch_as3|html5player(-new)?|base)?\.([a-z]+)$/);
						if ( m ) {
							player_type = m[4];
							player_id = m[1];
						}
						else  {
							m = playerUrl.match(/.*?-([a-zA-Z0-9_-]+)\/(.+?)\/(watch_as3|html5player(-new)?|base)?\.([a-z]+)$/);
							if ( m == null ) return;
							player_type = m[5];
							player_id = m[1];
						}
						
						if ( player_type == 'js' ) {

							funcName = findMatch(playerContents, /\.sig\|\|([a-zA-Z0-9$]+)\(/);
							if (!funcName) funcName = findMatch(playerContents, /signature\"\s*,\s*([a-zA-Z0-9$]+)\(/);
							if (!funcName) {
								return cb(new Error("Fail find function (get signature) "));   
							}
							funcName=funcName.replace('$','\\$');

							var regCode = new RegExp('('+funcName+'\\s*=\\s*function)\\s*\\(([^)]*)\\)\\s*\\{([^}]+)\\}');
							var m = playerContents.match(regCode);
							if (!m) {
								return cb(new Error("Fail get function: "+funcName));	
							}
							next();
						}	
					},
					function(next) {
						var key = funcName + '___' + player_id + '___' + s;
						if ( key in storage_code ) {
							cb(null, storage_code[key]);
							return;
						} 
						next();
					},
					function(next) {
					    var codeMain = 'chrome.extension.onConnect.addListener(function( port ){ function getSignature(s){ port.postMessage({action:"signature",sig:s,dsig:'+funcName+'(s) } ); } port.onMessage.addListener( function( message ){ if (message.action=="get"){ getSignature(message.sig) }}) })';
					    playerContents += codeMain;												 
						
						chrome.tabs.executeScript( 	tabId, {
													code: playerContents,
												}, function(){
														insertScript[ytVideoId] = true;
														next();
												});
												
					},
					function(next) {
						var port = chrome.tabs.connect( tabId );
						port.postMessage({action: 'get', sig: s})	
						port.onMessage.addListener(function( message ){
								cb(null, message.dsig);
						});
					}
				]);
			};
			function findMatch(text, regexp) {
				var matches=text.match(regexp);
				return (matches)?matches[1]:null;
			}
			function isString(s) {
				return (typeof s==='string' || s instanceof String);
			}
			function isInteger(n) {
				return (typeof n==='number' && n%1==0);
			}
			function swap(a,b) {
				var c = a[0];
				a[0] = a[b%a.length];
				a[b] = c;
				return a
			};
			function decode(sig, arr) { // encoded decryption
		  
/* 			if (!arr) return null;	
			if (!isString(sig)) return null;
			var sigA=sig.split('');
			for (var i=0;i<arr.length;i++) {
			  var act=arr[i];
			  if (!isInteger(act)) return null;
			  sigA=(act>0)?swap(sigA, act):((act==0)?sigA.reverse():sigA.slice(-act));
			}
			var result=sigA.join('');
			return result; */
			}
		};
		
		// ================================================================================================================   
		function parseYoutubeFormats( formats, title, videoId, callback ){			

			var parsedMediaList = [];

			for (var i in ytf) 	{
				if (!(i in formats))       continue;
                if(ytf[i].type === "audio")  continue;
				var u = formats[i];
				
				var ft = title;
				var ext = ((i in ytf) ? ytf[i].frm : 'flv');
				
				var media = {
						url: 			u,
						ext: 			ext,
						title: 			ft,
						displayName: 	ft,
						downloadName: 	ft,
						filename: 		ft,
						quality: 		parseInt(ytf[i].size),
						yt_format: 		i,
						yt_label: 		ytf[i].title,
						metod: 			ytf[i].type,
						type: 			'video',
						groupId: 		0,
						orderField:		0,
						dwnl:			1,
						priority: 		10,
						videoId:		videoId,
						hash:			videoId+'_'+i
				};

                if(ytf[i].type === "convert") {
                	var xx = get_ext_audio_url(i);
                	if ( !xx ) continue;
                    media.audio_tag = xx; 
                    media.audio_url = formats[xx];   
                    media.audio_ext = ytf[xx].frm; 
                }  
                else if(ytf[i].type === "record") {
                	media.playlist = u;

                }	
                else if(ytf[i].type === "download") {

                }

				parsedMediaList.push(media);
				
				mediaFound = true;
			}
			
			callback( parsedMediaList );


		    // ------------------------
		    function get_ext_audio_url(itag) {
		        var x = ytf[itag].adp;
		        for (var i=0; i<x.length; i++) {    
		            if (formats[x[i]])  return x[i];
		        }
		        return null;
		    }   


		}
		
		// -------------------------------------------------------------------
		function clean (str) {
			return str.replace(/\\u0026/g, "&").replace(/\\\//g, '/')
		}
	
		// -------------------------------------------------------------------
		function parseYoutubeEmbed(videoId, content, data, callback ){			

            var formats = {};
            var foundFormats = false;
			var title = null;
			var tabId = data.tabId;
			
			var sigDecrypt = new SignatureDecryptor(tabId, videoId);
			
			var m = content.match(/<span\s*itemprop\s*=\s*"author"\s*itemscope\s*itemtype\s*=\s*".+?"\s*>((?:.|\s)+?)<\/span>/im);
			if(m) {
			  var isVevo = /href="[^"]+?VEVO"/.test(m[1]);
			  if(isVevo) {
				console.log("ISVEVO? " + isVevo + "\n");
				// ignore vevo videos
				return;
			  }
			}
			else {
			}
			
			var flagGaming = data.tab.url.indexOf('gaming.youtube.com') == -1 ? false : true;
			
			fvdSingleDownloader.Utils.Async.chain([
				function(next) {
					tmp = content.match( /"adaptive_fmts"\s*:\s*"(.+?)"/i );
					if( tmp )  {
						tmp[1] = tmp[1].replace(/\\u0026/g, "&");
						var map = tmp[1].split(",");
				
						_parsed(map, function(){
							next();
						});	
					}
					else {
						next();
					}	
				},
				function(next) {
					tmp = content.match( /"url_encoded_fmt_stream_map"\s*:\s*"(.+?)"/i );
					if( tmp )  {
						tmp[1] = tmp[1].replace(/\\u0026/g, "&");
						var map = tmp[1].split(",");
				
						_parsed(map, function(){
							next();
						});	
					}
					else {
						next();
					}	
				},
				function(next) {
					if(!flagGaming) {
						return next();
					}
					
					var eUrl = encodeURIComponent("https://youtube.googleapis.com/v/" + videoId);
					var getVideoInfoUrl = "https://www.youtube.com/get_video_info?video_id=" + videoId + "&eurl=" + eUrl + "&el=info";

					var ajax = new XMLHttpRequest();
					ajax.open('GET', getVideoInfoUrl, true);
					ajax.youtube_id = videoId;
					ajax.setRequestHeader('X-FVD-Extra', 'yes');
					
					ajax.onload = function(){
					
								var content = this.responseText;

								var parsed_hlsvp = null;
								try {
									var parsed = fvdSingleDownloader.Utils.parseStr(content);
									parsed_hlsvp = parsed.hlsvp;
									title = parsed.title;
								}
								catch(ex) {
									console.log(ex);
									next();
								}
								
								console.log(parsed_hlsvp);
								getContentFromGaming(parsed_hlsvp, videoId, function(text) {
									
                                    try {
                                        var formatsUrls = text.split("\n").filter(function(str) {
                                            return /^https?:/.test(str);
                                        });
										
                                        formats = {};
                                        foundFormats = false;
                                        for(var url of formatsUrls) {
                                            var m = url.match(/\/itag\/([0-9]+)\//);
                                            if(m) {
                                                formats[m[1]] = url;
                                                foundFormats = true;
                                            }
                                        }
                                        next();
                                    }
                                    catch(ex) {
                                        next();
                                    }
								});
							}
					
					ajax.onerror = function(){
								callback( null );
							}
					
					ajax.send( null );
				},
				function() {
					if (foundFormats)		{
						var title = content.match(/<meta\sname=\"title\" content=\"([^\"]+)\">/i);
						if (title != null) 	{
							title = title[1];
							if (title.length > TITLE_MAX_LENGTH)   title = title.substr(0, TITLE_MAX_LENGTH) + '...';
						}
						
						parseYoutubeFormats( formats, title, videoId, callback );	
					}
					else {
						callback(null);
					}
				}
			]);

			function _parsed(map, cb) {

				fvdSingleDownloader.Utils.Async.arrayProcess(map, function(mapEl, apNext) {
					
						var m = mapEl.match(/itag=([0-9]+)/i);
						if (!m) {
							//console.log("##fail parse itag\n");
							return apNext();
						}
						var tag = m[1];
						
						m = mapEl.match(/url=([^&]+)/i);
						if (!m) {
							//console.log("##fail parse url\n");
							return apNext();
						}
						var url = m[1];
						url = decodeURIComponent(url);
						//console.log("##found ", tag);

						fvdSingleDownloader.Utils.Async.chain([
							function(next) {
								m = mapEl.match(/sig=([^&]+)/);
								if (m) {
									url += "&signature="+m[1];
									//console.log("Found simple sig ", m);
									next();
								}
								else {
									m = mapEl.match(/(?:^|&)s=([^&]+)/);
									if(m) {
										// we detect encrypted signature
										//console.log("###FOUND encrypted signature!!! "+m[1]);
										sigDecrypt.decrypt(content, m[1], function(err, sig) {
											if(err) {
												console.log("Fail decrypt signature: " + err);
												return apNext();
											}
											//console.log("#signature decrypted success: " + sig);
											url += "&signature="+sig;
								
											next();	
										});
								  
									}
									else {
										// maybe signature already in url
										next();
									}
								}
							},
							function() {
								formats[tag] = url;
								foundFormats = true;
								apNext();
							}
						]);
				}, function() {
					
					cb();
					
				});

			}	

		}
		
		// -------------------------------------------------------------------
		function getContentFromGaming( url, videoId, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.youtube_id = videoId;
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			ajax.onload = function(){
			
						callback( this.responseText );

					}
			
			ajax.onerror = function(){
						callback( null );
					}
			
			ajax.send( null );
			
		}	
			
		// -------------------------------------------------------------------
		function getContentFromYoutubePage( data, videoId, callback ){
			
			var scheme = "http";
			var yt_url = data.url;
			if( yt_url.toLowerCase().indexOf("https") == 0 )	scheme = "https";
			
			// send request to youtube
			var url = scheme + "://www.youtube.com/watch?v="+videoId;
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.youtube_id = videoId;
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			//ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.root_url = yt_url;
			ajax.request_url = url;
			
			
			ajax.onload = function(){
			
						var content = this.responseText;

						parseYoutubeEmbed(videoId, content, data, function( media ){
						
										if( media )  {
											media.forEach(function( item ){
																item.groupId = videoId;
															});
										}
					
										callback( media );
									} );
					}
			
			ajax.onerror = function(){
						callback( null );
					}
			
			ajax.send( null );
		}
		
		// ================================================================================================================   
		function addVideo( params, data ){
			
			//console.log('addVideo', params, data);

            var ft = [{tag: 'span', content: '['+params.yt_label+', ' },
					  {tag: 'b',    content: fvdSingleDownloader.Utils.upperFirst(params.ext) }, 	
					  {tag: 'span', content: '] ' }	];

			var par = { yt_format:  params.yt_format };
			if (params.audio_url) {
				 par.audio_url = params.audio_url;
				 par.audio_ext = params.audio_ext;
			}		

			fvdSingleDownloader.Media.Storage.add( {
					url: 		params.url,
					tabId: 		data.tabId,
					tabUrl: 	data.tabUrl,
					
					videoId: 	params.videoId,
					hash: 		params.hash,
					thumbnail: 	params.thumbnail ? params.thumbnail : data.thumbnail,
					
					ext: 		params.ext,
					title: 		params.displayName,
					format: 	null,
					
					downloadName: 	params.downloadName,
					displayName: 	params.displayName,
					displayLabel: 	ft,
					filename: 		params.filename,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"video",
					metod: 		params.metod,
					source: 	"Youtube",
					quality:    params.quality,
					
					groupId: 	params.group,
					orderField: params.quality,
					dwnl:		1,
					
					params:		par
					
				},{
					findThumbnail: false,
					noReplace: true
				});

		}		
		
		// ================================================================================================================   
		function checkYoutubeWatch( data ){
			
			var url = data.url;
			
			var matches = url.match(/https?:\/\/(?:www\.)?youtube\.com\/watch.*[\?|&]v=([^\?&]+)/i);
			if( !matches )	return;
			
			var videoID = matches[1];
 			if ( parse_videoId[videoID] ) return;
 			
			parse_videoId[ videoID ] = url;

			getContentFromYoutubePage( data, videoID, function(media) { 
			
				delete parse_videoId[ videoID ];
				if (media) {
					var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     
					for (var i=0; i<media.length; i++) {
						media[i].group = groupMedia;
						addVideo( media[i], data );
					}
					
					insertYTButton( data.tabId );
				}
			
			});   			
			
		}
		// -------------------------------------------------------------------
		function checkYoutubeChannel( data ){
			
	        var url = data.url
					        
	       	matches = url.match(/https?:\/\/(?:www\.)?youtube\.com\/user\/.+?[\?&]v=([^&]+)/i);		
						
			if( matches ) {  						  
				getContentFromYoutubePage( data, matches[1], _cb );   				
				return;	
			}
			
			matches = url.match(/https?:\/\/(?:www\.)?youtube\.com\/user\/([^\/\?&]+)/i);	
						
			if( matches )	{
			
				fvdSingleDownloader.Utils.downloadFromUrl( "http://www.youtube.com/user/" + matches[1], function( contents ){

									if( !contents )		return;
									contents = contents.replace( "\\/", "/" );
								
									matches = contents.match( /data-swf-config\s*=\s*"(.+?)"/i );
									if( matches )
									{				 	
										var conf = matches[1];
										matches = conf.match( /\\\/vi\\\/(.+?)\\\//i ); 	
										
										if( matches )	getContentFromYoutubePage( data, matches[1], _cb );							
									}
								} );
			}

			// -----------------------
			function _cb( media ) {
			
				if (media) {
					var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     
					for (var i=0; i<media.length; i++) {
						media[i].group = groupMedia;
						addVideo( media[i], data );
					}
				}
			}
		}

		// -------------------------------------------------------------------
		function checkYoutubeEmbeds( data ){
			
			var url = data.url;
			
			if( url.toLowerCase().indexOf( "youtube" ) == -1 ) return;
				
			var matches = url.match(/:\/\/(?:www\.)?(?:youtube|youtube-nocookie)(?:\.googleapis)?\.com\/v\/([^\?&]+)/i);
			if( !matches ){				
				matches = url.match( /:\/\/(?:www\.)?(?:youtube|youtube-nocookie)\.com\/embed\/([^\?&]+)/ );				
			}	
			if( !matches )  return;

			getContentFromYoutubePage( data, matches[1], _cb );					
			
			// -----------------------
			function _cb( media ) {

				if (media) {
					var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     
					for (var i=0; i<media.length; i++) {
						media[i].group = groupMedia;
						addVideo( media[i], data );
					}
				}
			}
		}
		
		// -------------------------------------------------------------------
		function checkYoutubeGaming( data ){
			
			var url = data.url;

			if(/^https?:\/\/gaming\.youtube\.com/i.test(data.tabUrl)) {
				matches = url.match(/video_id=([^\?&]+)/i);
				if(matches) {
					getContentFromYoutubePage( data, matches[1], _cb );
				}
			}

			// -----------------------
			function _cb( media ) {

				if (media) {
					var groupMedia = fvdSingleDownloader.Media.Storage.nextGroupId();     
					for (var i=0; i<media.length; i++) {
						media[i].group = groupMedia;
						addVideo( media[i], data );
					}
				}
			}
			
		}
		
		// -------------------------------------------------------------------
		this.getContentFromYoutubePage = function( data, videoId, callback ){
			getContentFromYoutubePage( data, videoId, callback );
		}
		
		function insertYTButton( tabId ) {
			
			setTimeout( function() {
					fvdSingleDownloader.ContentScriptController.processMessage( tabId, {
									action: "insertYTButton",
									media: fvdSingleDownloader.Media.getMedia( tabId )
								} );				
			}, 1000);
		}
		
		// ====================================================================	
		this.getMedia = function( media ){

			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "Youtube" ) {
											var iii = find( item ); 
											if (iii == -1) stream_media.push( item );
											else stream_media[iii] = item;
										}	
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
			
			function find( e ) {
				for (var ii=0; ii<stream_media.length; ii++) {
					if (stream_media[ii].quality == e.quality && stream_media[ii].groupId == e.groupId)  return ii;	
				}	
				return -1;
			}
		
		}
		
		
	}
	
	fvdSingleDownloader.Media.Youtube = new Youtube();
	
})( );
