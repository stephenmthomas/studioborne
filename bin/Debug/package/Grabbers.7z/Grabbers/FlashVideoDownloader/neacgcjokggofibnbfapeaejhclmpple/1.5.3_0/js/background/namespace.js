var fvdSingleDownloader = {
	noYoutube: false,
	noLink:    true,
	noImage:   true,
	noFile:    true,
	noGame:    false,
	noWelcome: false,
	noFFMpeg:  false,
};