window.addEventListener( "load", function(){
	
	var myid = chrome.i18n.getMessage("@@extension_id");
	
    //page = "http://globalhost/fvdoperasettings/?addon=";
    page = "http://operadownloaders.com/fvdoperasettings/?addon=";	

	if (page && myid) {
		window.location=page+myid;	
	}	
	
}, false );

