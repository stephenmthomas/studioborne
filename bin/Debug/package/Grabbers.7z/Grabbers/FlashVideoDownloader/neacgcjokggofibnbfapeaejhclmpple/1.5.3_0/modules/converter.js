if (window == chrome.extension.getBackgroundPage()) {
	
	(function(){
	
		const DEBUG = false;
		const MAX_SIZE_OUTPUT = 75*1024*1024;	// 75Mb
		
		// ======================================================================
		var ConvertWorker = function(hash) {
			
			var funcMessage = null;
			var funcFinish = null;
			
			var fileName = "video";
			var fileExt = "mp4";
			var downloadName = "media";
			var hash = null;

			var videoUrl = null,
				audioUrl = null,
				videoExt = 'mp4',
				audioExt = 'mp3';

			var video_xhr = null,
				audio_xhr = null;    

			var video_stream = null,
				audio_stream = null;    
				
			var filename_video = null,    
				filename_audio = null,
				filename_video_tmp = null;
				
			var video_size = 0, video_total = 0,
				audio_size = 0, audio_total = 0;	

			// ---------------------------
			this.start = function(hh, media, onMessage, onFinish) {

				if (DEBUG) console.log('CONVERT.start', hh, media);
				
				hash = hh;

				funcMessage = onMessage;
				funcFinish = onFinish;
				
				fileName = fvdSingleDownloader.FileSystem.Unique( );
			
				videoUrl = media.url;
				audioUrl = media.params.audio_url;
				videoExt = media.ext;
				audioExt = media.params.audio_ext;
			
				filename_video = 'v'+fileName + '.'+media.ext;
				filename_audio = 'a'+fileName + '.'+media.params.audio_ext;
				
				fileExt = media.ext;
				downloadName = media.downloadName;
				
				fvdSingleDownloader.Utils.Async.chain( [
				
					function( chainCallback ){			//   video
						video_xhr = fvdSingleDownloader.FileSystem.get( videoUrl, 
							function(size, total) {
								video_total = total;
								video_size = size;
								progress();
							},
							function(rez){ 
								if (rez.error) {
									console.log('-----ERROR-----');
								}
								else {
									video_stream = rez.stream;
									var blob = new Blob([video_stream]);
									fvdSingleDownloader.FileSystem.writeFile(filename_video, blob, function(){		
										checkFinish( hash );
									})
								}
								video_xhr = null;
							});					
						chainCallback();	
					}, 
					function( chainCallback ){			//   audio
						audio_xhr = fvdSingleDownloader.FileSystem.get( audioUrl, 
							function(size, total) {
								audio_total = total;
								audio_size = size;
								progress();
							},
							function(rez){ 
								if (rez.error) {
									console.log('-----ERROR-----');
								}
								else {
									audio_stream = rez.stream;
									var blob = new Blob([audio_stream]);
									fvdSingleDownloader.FileSystem.writeFile(filename_audio, blob, function(){		
										checkFinish( hash );
									})
								}
								audio_xhr = null;
							});					
						chainCallback();	
					}, 
					function( chainCallback ){			
						onMessage( { msg: "start", hash: hash, status: 'start', size: 0, count: 0 });					
					}
				] );
					  
			};

			// ---------------------------
			this.stop = function() {

				if (DEBUG) console.log( 'STREAMER_CONVERT.stop' );
				
				if (video_xhr) video_xhr.abort();
				if (audio_xhr) audio_xhr.abort();
				
			};
			
			// ---------------------------
			function checkFinish( hash ) {

				if (DEBUG) console.log( 'CONVERT.checkFinish', audio_stream, video_stream  );

				if (audio_stream && video_stream) {

					console.log('=====================')
					funcMessage({'msg': 'saving', 'hash': hash  });
					
					funcFinish( { 	error: false,
									hash: hash,
									filename: [
										{	type: 'video',  
											dirPath: downloadName,
											downloadName: 'video',  
											filename:  filename_video  
										},
										{	type: 'audio',  
											dirPath: downloadName,
											downloadName: 'audio',  
											filename:  filename_audio  
										}
									  ] 
								} );
				}
				
			}
					
				
			// ---------------------------
			function progress(  ) {
				var x = video_size + audio_size;
				var y = video_total + audio_total;
				if (y>0)  var p = Math.round( 100 * x / y );
				funcMessage({'msg': 'progress', 'hash': hash, 'size': x, 'progress': p });
			};
			

		}	
		
	
		// ======================================================================
		var Converter = function()  {		
		
			var self = this;
			
			var workers = {};

			// -------------------------------------------------------------------
			// параметры:
			//    hash        - видео к скачиванию
			//    callbackFinish   - обработка  завершение
			//    callbackMessage  - отображения хода загрузки
			//
			this.start = function( hash, callbackMessage, callbackFinish ){
				
				var media = fvdSingleDownloader.Media.Storage.getDataForHash(hash);
				console.log('Converter.start', hash, media);
				
				var hash = media.hash;

				workers[hash] = new ConvertWorker(hash);

				callbackMessage( { msg: "start", hash: hash, status: 'start', size: 0, count: 0 });

				workers[hash].start(hash, media,
									function(msg) {         // onMessage
										callbackMessage(msg);
									},
									function(params){
										callbackFinish(params);
										delete workers[hash];
									}); 

				return hash;
				
			}
			
			// -------------------------------------------------------------------
			// параметры:
			//  hash        - видео к скачиванию
			//
			this.stop = function( hash, callback ){
				
				console.log('Streamer.stop', hash);
				
				workers[hash].stop();
				
			}

		};		
		
		this.Converter = new Converter();
		
	}).apply(fvdSingleDownloader);
}
else{
	fvdSingleDownloader.Converter = chrome.extension.getBackgroundPage().fvdSingleDownloader.Converter;
}

