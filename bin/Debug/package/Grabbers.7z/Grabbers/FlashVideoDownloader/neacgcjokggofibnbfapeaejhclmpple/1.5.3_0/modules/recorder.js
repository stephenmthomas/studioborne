if (window == chrome.extension.getBackgroundPage()) {
	
	(function(){

		// ======================================================================
		var RecordWorker = function(hash) {
			
			const DEBUG = false;
			
			const MAX_RECORD_DOWNLOAD = 15;
			const MIN_RECORD_DOWNLOAD = 3;
			const COUNT_RECORD_CHUNK = 3;
			const LOAD_RECORD_TIMEOUT = 300000;  // 5мин
			
			const RECORD_UNDEFINED = 0
			const RECORD_LOAD_PLAYLIST = 1
			const RECORD_WORKING = 3
			const RECORD_START_DOWNLOAD = 5;
			const RECORD_SAVING = 10;
			const RECORD_END_PLAYLIST = 11
			const RECORD_FINALIZING = 20;
			const RECORD_ABORT = 21;
			const RECORD_FINISHING = 99;

			const FILE_NULL = 0
			const FILE_GET = 1
			const FILE_LOAD = 2
			const FILE_ERROR = 3
			const FILE_SAVE = 4
			const FILE_REMOVE = 5

			var stateRecord = RECORD_UNDEFINED;
			var endLoadPlayList = 0;

			var funcMessage = null;
			var funcFinish = null;
			
			var hash, playlistUrl, playlist, host, domain, prot = "", search = null;
			var sourceLive = null, baseUrl = "", fileExt = 'ts';
			var initSector = null, init_fileName = null, paramsMetadata = null;

			var isRun = false;
			var isSave = false;
			var isEnd = false;

			var countLoad = 0;
			var countTSFiles = 0;
			var sizeOfVideo = 0;

			var blockStartReadTS = 0,
				queue=0,
				file = [];
			var listFN = null;

			// ---------------------------
			this.start = function(hash, media, onMessage, onFinish) {

				if (DEBUG) console.log('--start--', hash, media);

				funcMessage = onMessage;
				funcFinish = onFinish;
				
				isRun = true;
				
				hash = media.hash;
				playlistUrl = media.playlist || media.url;
				sourceLive = media.source;

				fileName = fvdSingleDownloader.FileSystem.Unique( );
				
				fileExt = media.ext;
				downloadName = media.downloadName;
				
				var x = fvdSingleDownloader.Utils.parse_URL(playlistUrl);
				
				host = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '') + x.path+'/';
				domain = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '');
				search = x.search || "";

				baseUrl = host;
				if (media.params) {	
					baseUrl = media.params.base_url ? media.params.base_url : host;
					templateFrag = media.params.frag_template ? media.params.frag_template : null;
					initSector = media.params.init ? media.params.init : null;
					paramsMetadata = media.params.metadata ? media.params.metadata : null;
				}

				listFN = [];

				funcMessage({'msg': 'playlist', 'hash': hash });

				sizeOfVideo = 0;
				
				isRun = true;
				stateRecord = RECORD_LOAD_PLAYLIST;

				if (initSector) {
					init_fileName = fileName + '_init.mp4';
					var b = new Blob([initSector], {type: 'video/mp4'});
					fvdSingleDownloader.FileSystem.writeFile(init_fileName, b, function(){  
						if (DEBUG) console.log('write '+init_fileName+' - success ');
					});
					listFN.push(init_fileName);						
				}	
				else if (paramsMetadata) {
					init_fileName = fileName + '_meta.mp4';
					var b = new Blob([paramsMetadata], {type: 'video/mp4'});
					fvdSingleDownloader.FileSystem.writeFile(init_fileName, b, function(){  
						if (DEBUG) console.log('write '+init_fileName+' - success ');
					});
					listFN.push(init_fileName);						
				}	
				
				load( );

			}  

			// ---------------------------
			this.stop = function() {

				if (DEBUG) console.log( 'RECORDER.stop' );
				
				isRun = false;
				
				for (var i = 0; i < file.length; i++)        {
					if ( file[i].state == FILE_GET ) {
						file[i].req.abort(); 
						file[i].state = FILE_ERROR;
					}
				} 
				
				workingEnd();
				
			};
			
			// -------------------------------------------------------------------
			function load( ){

				if (DEBUG) console.log( 'load ', isRun );

				if (!isRun)   return;

				if (stateRecord != RECORD_LOAD_PLAYLIST)  return;

				if ( sourceLive == 'Twitch' ) {
					load_m3u8();
				}
				else if ( sourceLive == 'OdnoKlassniki' ) {
					load_dash();
				}
				else if ( sourceLive == 'MediaManifest' ) {
					load_bootstrap();
				}


			}

			// -------------------------------------------------------------------
			function load_m3u8( ){

				loadPlayListFile( playlistUrl, function( results ){

						if (!isRun)   return;

						if (stateRecord == RECORD_FINISHING)      return;
						
						var kk = 0;
						for (var i=0; i<results.length; i++)    {
						
							if ( !find(results[i]) ) {
								
								var u = results[i];
								if (u.indexOf('http') != 0) {
									if (u.indexOf('/') == 0)  u = domain + u;
									else	u = host + u;
								}
								if (u.indexOf('?') == -1 && search) {
									u = u + search;
								}    
								
								var f = { fn: results[i], 
										  url: u, 
										  name: _nextRecordId()+"."+fileExt, 	
										  state: FILE_NULL,
								        };
								
								file.push( f );
								
								kk++;
							}    
						}	
						
						if ( kk > 0 ) {
							loadFile(f);
						}
						else {	
							setTimeout(function() {  
								load();
							}, 3000);    
						}
						countTSFiles = file.length;

				}); 

			}	

			// -------------------------------------------------------------
			function loadPlayListFile(url, callback)  {
				
				if (DEBUG) console.log( 'loadPlayListFile: ', hash, url );
				
				var results = [];
				
				getAJAX( url, function(content){
					if (!content) return;
					if (stateRecord != RECORD_LOAD_PLAYLIST || !isRun)  return;

					var line = content.split('\n');
					
					for (var i=0; i<line.length; i++)    {

						line[i] = line[i].trim();
						if ( !line[i] )   continue;   
						
						if ( line[i].substring(0,1) != '#' )   {
							var u = line[i];
							results.push(u);
						}
					}
					
					callback(results);
				});	

			}

			// -------------------------------------------------------------------
			function load_dash( ){

				var httpRequest = new XMLHttpRequest(); 
				httpRequest.open ("GET", playlistUrl, true);
				httpRequest.responseType = "arraybuffer"; 
				httpRequest.onreadystatechange = function() {
						if (httpRequest.readyState==4) {
							if (IsRequestSuccessful (httpRequest)) 	{

								var arr = new Uint8Array(httpRequest.response);
								var ind = fvdSingleDownloader.jspack.ReadInt32(arr, 0);

								var u = templateFrag.replace('%%id%%', ind).trim();

								if ( !find(u) ) {
									
									var f = { fn: u,
											  url: baseUrl + u, 
											  name: _nextRecordId()+"."+fileExt, 	
											  state: FILE_NULL,
									        };
									
									file.push( f );
									countTSFiles = file.length;
									
									loadFile(f);
								}    
								else {
									setTimeout(function() {  
										load();
									}, 3000);    
								}
								
							}
							else 	{
								console.log('====ERROR=====load_dash==== httpRequest =====');
							}
						}
				};

				httpRequest.send();
			}	
			
			// -------------------------------------------------------------------
			function load_bootstrap( ){
				
				console.log(playlistUrl);
				var paramsBootstrap = {	uri: baseUrl };

				var httpRequest = new XMLHttpRequest(); 
				httpRequest.open ("GET", playlistUrl, true);
				httpRequest.responseType = "arraybuffer"; 
				httpRequest.onreadystatechange = function() {
						if (httpRequest.readyState==4) {
							if (IsRequestSuccessful (httpRequest)) 	{

								var arr = new Uint8Array(httpRequest.response);

								var list = fvdSingleDownloader.Bootstrap.listSegment(arr, paramsBootstrap);

								var kk = 0;
								for (var i=0; i<list.length; i++)    {
								
									if ( !find(list[i]) ) {
										
										var u = list[i];
										if (u.indexOf('?') == -1 && search) {
											u = u + search;
										}    
										
										var f = { fn: list[i],
												  url: u, 
												  name: _nextRecordId()+"."+fileExt, 	
												  state: FILE_NULL,
												};
										
										file.push( f );
										
										kk++;
									}    
								}	
						
								if ( kk > 0 ) {
									loadFile(f);
								}
								else {	
									setTimeout(function() {  
										load();
									}, 3000);    
								}
								countTSFiles = file.length;

							}
							else 	{
								console.log('====ERROR=====load_dash==== httpRequest =====');
							}
						}
				};

				httpRequest.send();
			}	
			
			// -------------------------------------------------------------
			function loadFile( )  {

				if (DEBUG) console.log( 'loadFile: ', queue, file);
				
				if (!isRun)   return;
				
				if ( queue < MIN_RECORD_DOWNLOAD ) {
					
					var kk = 0;
					for(var i = 0; i < file.length; i++)     	{
						
						if (isRun && file[i].state==0)      	{
							
							kk++;
							loadRecordFile(file[i]);
																
							if (queue >= MAX_RECORD_DOWNLOAD)  {  // очеред заполнили
								return;
							}	
						}
					}
					
					if (kk==0) {		// playlist пуст - обращаемся за новым
						load();	
					}
				}
			}
			
			// -------------------------------------------------------------
			function IsRequestSuccessful (httpReq) {
				var success = (httpReq.status == 0 || (httpReq.status >= 200 && httpReq.status < 300) || httpReq.status == 304 || httpReq.status == 1223);
				return success;
			}
			function loadRecordFile( f )  {

				if (DEBUG) console.log( 'loadRecordFile: ', f);
				
				if (!isRun)   return;

				try	{
					var httpRequest = new XMLHttpRequest(); 
					f.req = httpRequest;					
					f.state = FILE_GET;
					
					httpRequest.open ("GET", f.url, true);
					httpRequest.responseType = "arraybuffer"; 
					httpRequest.onreadystatechange = function() {
							if (httpRequest.readyState==4) {
								if (IsRequestSuccessful (httpRequest)) 	{
									
									f.req = null;
									clearTimeout( f.timer );
									f.timer = null;
									
									f.state = FILE_LOAD;						
									
									var t = httpRequest.getResponseHeader("Content-Type");

									var b = new Uint8Array(httpRequest.response);
									sizeOfVideo += b.length;
									
									var blob = new Blob([b], {type: t});
									fvdSingleDownloader.FileSystem.writeFile(f.name, blob, function(){
										listFN.push(f.name);
										endLoadRecordFile(false);	
									})
									
								}
								else 	{
									console.log('===============ERROR===================== httpRequest ==========');
									endLoadRecordFile(true);
								}
								queue--;	// очередь скачки уменьшаем (на эту скачку)
							}
					};
					
					f.timer = setTimeout(function () { 
					
							httpRequest.onreadystatechange = null;
							httpRequest.abort();
							file[index].req = null;
							clearTimeout( f.timer );
							f.timer = null;
							f.state = FILE_ERROR;	

							endLoadRecordFile(true);		
							
						}, LOAD_RECORD_TIMEOUT);
					
					
					httpRequest.send();
					queue++;		// еще одна закачка
					
				}
				catch(err)	{
					console.log('===============CATCH===================== httpRequest ==========', err);
					endLoadRecordFile(true);
				}
			}
			
			// -------------------------------------------------------------
			function endLoadRecordFile(error)  {

				if (DEBUG) console.log( 'endLoadRecordFile:  error:',error, ', isSave:',isSave );
				
 				if (isSave) return;

				// подсчитаем состояние
				var flagEmpty = false;
				isEnd = true;
				
				for (var j=0; j<file.length; j++) {

					if (file[j].state > FILE_GET) countLoad++;			// скачано сегментов
					else isEnd = false;
					
					if (!file[j].stream && file[j].state == FILE_GET) {			// на очереди на чтение, но не прочитано (
						flagEmpty = true;
					}	
				}

				// сообщение	
				funcMessage({'msg': 'progress', 'hash': hash, 'size': sizeOfVideo, 'count': countLoad, 'progress': Math.round( 100 * countLoad / countTSFiles ) });
				
				if (isRun) {
					if (isEnd) {
						load();			// дальнейшие обращаемся за плейлистом
					}
					else {
						loadFile();		// остальные файлы
					}	
				}	
 				
			}
			
			
			// ----------------
			function find( fn ) {

				for (var j=0; j<file.length; j++)    {
					if (file[j].fn === fn) return true;
				}    
				return false;
			}
			

			// --------------------------------------------------------------------------------
			function getAJAX( url, callback ){
				var ajax = new XMLHttpRequest();
				ajax.open('GET', url, true);
				ajax.setRequestHeader('Cache-Control', 'no-cache');
				ajax.onload = function(){
							var content = this.responseText;
							callback( content );
				}
				ajax.onerror = function(){
					callback( null );
				}
				ajax.send( null );
			}

			// --------------------------------------------------------------------------------
			function workingEnd( ){
				
				if (DEBUG) console.log(' workingEnd', file, listFN );   
				
				funcMessage({'msg': 'saving', 'hash': hash  });

				isSave = true;

				runConcatFile();
				
				
			}

			// --------------------------------------------------------------------------------
			function runConcatFile( ){
				
				var file_name = fileName+"."+fileExt;
				var fileSave = [];
				var k = 0;  
				for(var j = 0; j < file.length; j++)       {
					if (file[j].state == FILE_LOAD) {
						fileSave.push(file[j].name);
						k++;
					}
					else {
						break;	
					}	
				}
				
				var list = [];
				if (init_fileName)  {
					list.push(init_fileName);
				}	
				for (var j=0; j<fileSave.length; j++) {
					list.push(fileSave[j]);
				}	
				
				fvdSingleDownloader.FileSystem.concat(list, file_name, function(f){
					console.log('finish', f);
					funcMessage({'msg': 'finish', 'hash': hash, size: sizeOfVideo, filename: fileName, error: !f });
					funcFinish({ error: !f, hash: hash, size: sizeOfVideo, filename: file_name});
					if (!DEBUG) fvdSingleDownloader.FileSystem.removeListFile(listFN);
				}); 
				
			}
			
		}	
	
		// ======================================================================
		var Recorder = function(){		
		
			var workers = {};
			var error = 0;
			
			// -------------------------------------------------------------------
			//  hash
			//
			this.start = function( hash, callbackMessage, callbackFinish  ){
				
				var media = fvdSingleDownloader.Media.Storage.getDataForHash(hash);
				console.log('Recorder.start', hash, media);
				
				var hash = media.hash;

				workers[hash] = new RecordWorker(hash);

				callbackMessage( { msg: "start", hash: hash, status: 'start', size: 0, count: 0 });

				workers[hash].start(hash, media,
									function(msg) {         // onMessage
										callbackMessage(msg);
									},
									function(params){
										callbackFinish(params);
										delete workers[hash];
									}); 

				return hash;
			}
			
			// -------------------------------------------------------------------
			this.stop = function( hash, callback ){
				
				console.log('Recorder.stop', hash);
				
				workers[hash].stop();
				
			}

			// -------------------------------------------------------------------
			this.getError = function( ){
			
				if(error !== "")
				{
					return error;
				}
				else
				{
					return "No Error!";	
				}
			}
			
		}
		
		this.Recorder = new Recorder();
		
		// ---------------------------
		var _lastRecordId = 0;
		function _nextRecordId(){
			_lastRecordId++;
			var str = '000000' + _lastRecordId.toString();
			return str.substring(str.length - 6, str.length);
		}
		
		
	}).apply(fvdSingleDownloader);
}
else{
	fvdSingleDownloader.Recorder = chrome.extension.getBackgroundPage().fvdSingleDownloader.Recorder;
}

