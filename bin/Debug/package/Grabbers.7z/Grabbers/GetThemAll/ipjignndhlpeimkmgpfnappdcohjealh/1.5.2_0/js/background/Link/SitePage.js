(function(){

	var SitePage = function(){		
	
		var self = this;
		
		const TITLE_MAX_LENGTH  = 96;
        const VIDEO_EXTENSIONS = ["flv", "ram", "mpg", "mpeg", "avi", "rm", "wmv", "mov", "asf", "rbs", "movie", "divx", "mp4", "ogg", "mpeg4", "m4v", "webm"];
		
		var detect = {};
	
		// --------------------------------------------------------------------------
		function prepareMedia( media ){
			
			//console.log(media);
			if ( !media.url || media.url.indexOf('blob:') != -1 )  return null;
			
			var u = GetThemAll.Utils.convertURL(media.url);
			
			if (u.type)			{
				media.type = u.type;
			}	
			
			if (u.type == 'video') {
				if (GetThemAll.LinkSniffer.ignoreDomain(media.url)) return null;
			}	
			
			if ( !GetThemAll.Utils.check_enable_type(media.type) )  return null;
			
			var downloadName = u.name;
			if (!downloadName)  downloadName = media.title;
			if (!downloadName) {
				var p = u.url.split('/');
				if (p.length>0)	downloadName = p[p.length-1];
			}	
			if (!downloadName)  downloadName = 'no name';

			var title = media.title;
			if (!title)  title = downloadName;
			
			var result = {				
				url: media.url,
				ext: u.ext,
				title: title,
				format: "",
				downloadName: downloadName,
				displayName: downloadName,
				filename: u.name,
				priority: 10,
				size: "",
				type: media.type,
				tabId: media.tabId,
				tabTitle: media.tabTitle,
				tabUrl: media.tabUrl,
				groupId: 0,
				dwnl:	1,
				orderField: 0
			};
			
			//console.log(result);
			return result;
		}
		
		// --------------------------------------------------------------------------------
		function storeMedia( item, tabUpdate ){

			if ( item == null ) return;
			//console.log(item);
			
			GetThemAll.Storage.add( {
					url: 		item.url,
					tabId: 		item.tabId,
					tabUrl: 	item.tabUrl,
					frameId: 	0,
					
					thumbnail: 	null,
					
					ext: 		item.ext,
					title: 		item.title,
					format: "",
					
					downloadName: 	item.downloadName,
					displayName: 	item.displayName,
					displayLabel: 	'',
					filename: 		item.filename,
					
					priority: 	1,
					vubor:  	0,
					size: 		0,
					type: 		item.type,
					metod: 		"download",
					source: 	"SitePage",
					groupId: 	0,
					dwnl:		1,
					orderField: null
				},{
					"findThumbnail": false,
					"getSize": false,
					"noRepeat": true,
					"noReplace": true,
					"tabUpdate": tabUpdate
				});			
					
		}
		
		// --------------------------------------------------------------------------------
		this.check_Links = function( tabId ) { 
		
			//console.log("check_Links:", tabId, detect[ tabId ].link);
			var link = detect[ tabId ].link;
			if (link == null || link.length == 0) return;
			
			parsedList = [];
		
			link.forEach(function( mm ){
				if ( !mm.url ) return;
				var hash = hex_md5(mm.url);
				var iii = find( hash );
				if ( iii == -1 ) {
					add( mm, hash )
				}
			});
			
			mediaList = [];
			if (parsedList.length > 0) {
				for (var j=0; j<parsedList.length; j++) {	
					var ll = prepareMedia( parsedList[j] );
					mediaList.push( ll );	
				}
			}	
			
			if (mediaList.length > 0) {
				var k = mediaList.length-1;
				for (var j=0; j<mediaList.length; j++) {	
					storeMedia( mediaList[j], j == k );
				}
			}
			
			// ---------------------
			function add( m, h ) {
				
				var p = {	hash: h,
							url: m.url,
							value: m.value,
							class: m.class,
							id: m.id,
							title: m.title,
							type: m.type,
							tabId:  detect[tabId].tabId,
							tabUrl:  detect[tabId].tabUrl,
							tabTitle:  detect[tabId].tabTitle,
						};

				detect[tabId].list.push(p);
				parsedList.push(p);
			}	
		
			// ---------------------
			function find( h ) {
				
				for (var i=0; i<detect[tabId].list.length; i++) {
					if ( detect[tabId].list[i].hash == h ) return i;
				}
				return -1;
			}	
		
		}
		
		// --------------------------------------------------------------------------------
		function convertEscapedCodesToCodes(str, prefix, base, num_bits) {
			var parts = str.split(prefix);
			parts.shift();  // Trim the first element.
			var codes = [];
			var max = Math.pow(2, num_bits);
			for (var i = 0; i < parts.length; ++i) 
			{
				var code = parseInt(parts[i], base);
				if (code >= 0 && code < max) 
				{
					codes.push(code);
				} 
				else 
				{
					// Malformed code ignored.
				}
			}
			return codes;
		}

		function convertEscapedUtf16CodesToUtf16Codes(str) {
			return convertEscapedCodesToCodes(str, "\\u", 16, 16);
		}

		function convertUtf16CodesToString(utf16_codes) {
			var unescaped = '';
			for (var i = 0; i < utf16_codes.length; ++i) 
			{
				unescaped += String.fromCharCode(utf16_codes[i]);
			}
			return unescaped;
		}
		
		function unescapeFromUtf16(str)  {
			var utf16_codes = convertEscapedUtf16CodesToUtf16Codes(str);
			return convertUtf16CodesToString(utf16_codes);
		}

		// --------------------------------------------------------------------------------
		chrome.extension.onRequest.addListener ( function(request, sender, sendResponse) {        
	
				if(request.akce=="Get_Links")	{
					
					var tabId = sender.tab.id;

					if ( request.oldUrl != request.url ) {		
						detect[tabId] = {	tabId:	tabId,
											tabUrl: request.tabUrl,
											tabTitle: request.tabTitle,
											link: request.link,
											list: []	};

						self.check_Links( tabId );
						return;
					}
					
					if (detect[tabId]) {
						if ( detect[tabId].tabUrl == request.tabUrl ) {
							detect[tabId].link = request.link;
							self.check_Links( tabId );
							return;
						}	
					}
					
					detect[tabId] = {	tabId:	tabId,
										tabUrl: request.tabUrl,
										tabTitle: request.tabTitle,
										link: request.link,
										list: []	};

					self.check_Links( tabId );
					
				}	
		});
	
	}
	
	
	this.SitePage = new SitePage();
	
}).apply( GetThemAll.Link );
