if (window == chrome.extension.getBackgroundPage()) {

	(function(){
	
		var Media = function(){

			var self = this;
			
			var textFile = null;
			
			var _onMediaForTabUpdateListeners = [];
			
			const DETECT_MODULES = ["Youtube", "Vimeo", "BreakCom", "VKontakte", "FaceBook", "OdnoKlassniki", 
								    "Twitch", "Twitter", "MediaManifest", "MediaStream", "MediaMaster", 
								    "Sniffer"	];
									
			// ===============================================================
			this.init = function(){
			
				console.log("Media - init ");
				
				// ---------------------------   
				chrome.tabs.onRemoved.addListener( function( tabId ){
					//console.log('onRemoved', tabId)					
					if( GetThemAll.Storage.hasDataForTab( tabId ) )	{
						GetThemAll.Storage.removeTabData( tabId );
						GetThemAll.MainButton.MediaForTabUpdate( tabId );
					}
				});
				
				// --------------------------- 
				chrome.tabs.onUpdated.addListener( function( tabId, changeInfo ){
					//console.log('onUpdated', tabId, changeInfo)					
					if( changeInfo.url ) {
						if( GetThemAll.Storage.hasDataForTab( tabId ) ) {
							GetThemAll.Storage.removeTabData( tabId );
						}
					}
					GetThemAll.MainButton.MediaForTabUpdate( tabId );
				});
				
				// --------------------------- 
				chrome.tabs.onActivated.addListener(function(info){
					//console.log('onActivated', info)					
					GetThemAll.MainButton.MediaForTabUpdate( info.tabId );
				});
				
				
				// ---------------------------  SendRequest
				chrome.extension.onRequest.addListener ( function(request, sender, sendResponse) {        
					if(request.command=="getVideoData")	{
						GetThemAll.Utils.getActiveTab( function( tab ) {
									if( tab )	{
										var media = self.getMedia( tab.id );
										media = GetThemAll.MainButton.filter_Media( media );
										media = GetThemAll.MainButton.parsed_Media( media );
										sendResponse(media);
									}
								});	
					}
					else if(request.command=="clickDownload")	{
						self.clickDownload( request.mediaId );	
					}
				});
			}

			// ===============================================================
			this.mediaForTabUpdate = function( tabId ){

				chrome.extension.sendMessage( {
											subject: "mediaForTabUpdate",
											data: tabId
										} );
										
				GetThemAll.MainButton.MediaForTabUpdate( tabId );							
										
			
			}	

			// ===============================================================
			this.checkMedia = function( data ){
				for (var ii=0; ii<DETECT_MODULES.length; ii++) {
					var module = DETECT_MODULES[ii];
					if( self[module] )		{
						var x = self[module].checkMedia(data);	
						if (x != 0)  {
							//if (x == 1) console.log('====', module, '====', data.url);
							return x;	
						}	
					}
				}	
				return 0;
			}	
			// -------------------------------------------------------------------
			this.detectMedia = function( data ){
				
				// ---------------------------  Sniffer, Youtube, .....
				for (var ii=0; ii<DETECT_MODULES.length; ii++) {
					
					var module = DETECT_MODULES[ii];
					if( self[module] )		{
						var x = self[module].detectMedia(data);	
						if (x == 1)  return x;
					}
				}	
				return 0;
				
			}	
			
			// ===============================================================
			this.getMedia = function( tabId ){
				
				var media = GetThemAll.Storage.getMedia( tabId );
				
				if ( !media || media.length == 0 )  return null;

				DETECT_MODULES.forEach( function( module ){
					if( self[module] )		{
						media = self[module].getMedia(media);	
					}
				} );

				media.sort( function( item1, item2 )  {   
					if (item1.priority < item2.priority)  return 1;
					if (item1.priority > item2.priority)  return -1;

					if (item1.groupId > item2.groupId)  return 1;
					if (item1.groupId < item2.groupId)  return -1;
					if (item1.groupId == item2.groupId) {
						if (item1.orderField < item2.orderField)  return 1;
						if (item1.orderField > item2.orderField)  return -1;
					}	

					return (item1.id < item2.id ? 1 : -1);  
				});
				

				return media;
			}
			// ----------------------------------------------------------------------------------------------------
			this.filterNotAllowedMedia = function( media ){

				if (!media) return [];

				var rezult = [];

				media.forEach(function( item ){

											if ( item.metod == 'not' )	{
												rezult.push( item );
											}
										});
										
				return rezult;						
			}
			
			// ===============================================================
			this.startListDownload = function( listMedia, title ){
				
				var removeChars = /[\\\/:*?"<>|"']/g;
				title = title.replace(removeChars, "");
				
				var m = _b(GetThemAll.Prefs.get( "gta.download_zip" ));
				var t = _b(GetThemAll.Prefs.get( "gta.original_filename" ));
				
 				if (listMedia.length==1) {
					start_media_download( listMedia[0], t );							
				}
				else if (!m) {
					listMedia.forEach( function( item ){
								start_media_download( item, t );							
							});
				}	
				else { 
					GetThemAll.Utils.getActiveTab(function( tab ){
						GetThemAll.DownloaderFS.start( 
												{	
													list: 	listMedia,	
													title:	title,
													tabId:	tab.id,
													metod:  t
												},
												function(msg)	{ 

												//saveDownloadZip(url, fileName+'.zip')	
													console.log(msg);
												
												},
												function(rez) {
													console.log(rez);
													GetThemAll.Ziper.start( {	
																list: 	rez,	
																title:	title
														 }, function(url)	{ 
																saveDownloadZip(url, title+'.zip')	
														 }
													);									   
													
												}	
						);									   
					});
					
				}	
					
			}	
			
			// ===============================================================
			this.stopListDownload = function( listMedia, count ){

				var m = _b(GetThemAll.Prefs.get( "gta.download_zip" ));
				if (m) {
					GetThemAll.DownloaderFS.stop( function()	{ 
					
					});
				}
			}	
			
			// ===============================================================
			function saveDownloadZip(url, filename)	{ 	
			
				try {
					chrome.downloads.download({
											url: url,
											filename:  filename,
											},
											function (downloadId) {
												console.log('DOWNLOAD ZIP', downloadId );
											}		
										);
					
				}
				catch(e) {
					console.log(e);	
				}	
				
			}	
			
			// ===============================================================
			this.clickOneDownload = function( media, tab ){

				console.log('clickOneDownload', media.status, media);			
				if ( media.status == 'stop' ) {
					start_media_download( media );							
				}
				else {	
					stop_media_download( media );							
				}	

			}	
			
			// ===============================================================
			this.clickDownload = function( id ){
				
				var m = GetThemAll.Storage.getDataForId( id );
				if (!m) return;
				console.log('clickDownload', m);
				
				if (m.status == 'error') {
					if (m.metod == 'stream') navigateMessageDisabled(16);
					return;
				}
				
				if (m.status == 'stop') {
					start_media_download( m );
				}
				else if (m.status == 'start')  {
					stop_media_download( m );
				}   
				
			}	
			
			// -------------------------------------------------------------------------------------
			function start_media_download( m ) {
				
				if (m.metod == 'download') {
					if ( m.type == 'media' ) {
						startDownloadMedia( m );
					}
					else {
						startDownloadLink( m );
					}	
				}
				else if (m.metod == 'stream') {
					startStreamMedia( m );
				}
				else if (m.metod == 'record') {
					startRecordMedia( m );
				}
				else if (m.metod == 'convert') {
					startConvertMedia(m);
				}
				
			}
			// -------------------------------------------------------------------------------------
			function stop_media_download( m ) {
				
				if (m.metod == 'download') {
					if ( m.type == 'media' ) {
						stopDownloadMedia( m );
					}
					else {
						stopDownloadLink( m, true );
					}	
				}
				else if (m.metod == 'stream') {
					stopStreamMedia( m );
				}
				else if (m.metod == 'record') {
					stopRecordMedia( m );
				}
				else if (m.metod == 'convert') {
					stopConvertMedia(m);
				}
				
			}
			
			// =====================================================================================
			function startDownloadLink(media, metod) {
			
				var flag_download = ('dwnl' in media && media.dwnl) ?  media.dwnl : 1;
				if( flag_download == 1 && !chrome.downloads ) flag_download = 3;

				var met = _b(GetThemAll.Prefs.get( "gta.original_filename" ));
				
				var filename = null;
				if (metod) {			
					if (media.filename) filename = media.filename;
					if (!filename && media.downloadName)  filename = media.downloadName;
					if (!filename && media.title) filename = media.title;
				}
				else if (media.downloadName) {
					filename = media.downloadName;
				}	
				if (!filename) filename='media';
				var ext = (media.ext ? media.ext : null); 
				
				filename = GetThemAll.FileSystem.removeChars( filename );
				
				console.log('MEDIA.startDownload: ', media, filename, flag_download);

				filename = filename + '.' + ext;

				if (flag_download == 1) {							//  с использованием API
					var info = { url: 		media.url,  
								 //saveAs: 	true,
								 filename:  filename,		
							   };	
							   
					GetThemAll.Downloader.start( media.id, media.url, filename,
							function(error, downloadId)	{ 
							
								if(error) {
									console.log(GetThemAll.Downloader.getError());
								}
								else  {
									
								}
							}
					);
				}				
				else if (flag_download == 2) {	// скачивание методом открытия в новой вкладке
					chrome.tabs.create({
									url: 	media.url,
									active: false
								});		
				}				
				else if (flag_download == 3) {	// по старинке - через закачку на странице
					var info = { url: 			media.url,  
								 downloadName: 	filename,
							   };	

					GetThemAll.Utils.getActiveTab(function( tab ){
								GetThemAll.ContentScriptController.processMessage( tab.id, {
											action: 	"startDownload",
											media: 		info,
										} );
							});
				}				

				
			}
			
			// --------------------------------------------------
			function stopDownloadLink(media) {

				console.log('stopDownloadMedia', media);
				
				if ( !media ) return;
				
				if (media.downloadId) {
			
					GetThemAll.Downloader.stop( media.downloadId,
							function(error)	{ 
								if(error) {
									console.log(GetThemAll.Downloader.getError());
								}
								else  {
								}
							}
					);
				}
				else {
					GetThemAll.Storage.setData_Attribute(media.tabId, media.id, "status", 'stop');		
				}	
				
			}	
			
			
			// =====================================================================================
			function startDownloadMedia(media) {

				console.log('MEDIA.startDownloadMedia', media);
				
				// metod download
				var flag_download = ('dwnl' in media && media.dwnl) ?  media.dwnl : 0;
				if( flag_download == 1 && !chrome.downloads ) flag_download = 5; // 
				var met = _b(GetThemAll.Prefs.get( "gta.original_filename" ));
				var file_name;
				if (met) {	//  original file name
					file_name = media.filename;	
				}
				else {
					file_name = media.downloadName;	
				}
				file_name = GetThemAll.FileSystem.removeChars( file_name );
				file_name = file_name + '.' + media.ext; 

				GetThemAll.Utils.Async.chain( [
				
					function( chainCallback ){			// 
					
									if( flag_download == 3 )	{
										console.log('DOWNLOAD - open');
										chrome.tabs.create({
														url: media.url,
														active: false
													});		 
										return;
									}	
									else {
										chainCallback();
									}
									
								}, 
								
					function( chainCallback ){			//  API
										
									if( flag_download == 1 ) 	{
										console.log('DOWNLOAD - api', file_name);	
										
										GetThemAll.Downloader.start( media.id, media.url, file_name,
												function(error, downloadId)	{ 
												
													if(error) {
														console.log(GetThemAll.Downloader.getError());
													}
													else  {
														
													}
												}
										);
										return;					
									}
									else	{
										chainCallback();
									}						
								},
			
					function( chainCallback ){			// 
										
										GetThemAll.Utils.getActiveTab(function( tab ){
													GetThemAll.ContentScriptController.processMessage( tab.id, {
																action: "startDownload",
																media: media
															} );
												});
										return;		
								}
				] );
			}
			// --------------------------------------------------
			function stopDownloadMedia(media) {

				console.log('stopDownloadMedia', media);
				
				if ( !media ) return;
				
				if (media.downloadId) {
					GetThemAll.Downloader.stop( media.downloadId, function(error)	{ 
																				if(error) {
																					console.log(GetThemAll.Downloader.getError());
																				}
																				else  {
																				}
					});
				}
				else {
					GetThemAll.Storage.setData_Attribute(media.tabId, media.id, "status", 'stop');		
				}	
			}	
			
			// ===============================================================
			function startStreamMedia(media) {
				
				chrome.extension.sendMessage( {	subject: "mediaStreamerState", state: true, id: media.id   } );

				GetThemAll.Streamer.start( media.hash,
							function(rez)	{ 
									if ( rez.msg === 'start' ) {
										GetThemAll.Storage.setStream( rez.hash, { status:'start' } );
										chrome.extension.sendMessage( {	subject: 		"mediaDownloadState", 
																		id: 			media.id, 	
																		metod:			media.metod,
																		streamHash: 	rez.hash, 
																		status:			'start'
																	} );
									}	
									else if ( rez.msg === 'cancel' ) {
										GetThemAll.Storage.setStream( rez.hash, { status: 'stop' } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		metod:		media.metod,
																		streamHash: rez.hash, 
																		status:		'stop'
																	  } );
									}
									else if ( rez.msg === 'finish' ) {
										var st = rez.error ? 'error' : 'stop';
										GetThemAll.Storage.setStream( rez.hash, { status: st } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		metod:		media.metod,
																		streamHash: rez.hash, 
																		status:     st
																	} );
									}
									else if ( rez.msg === 'playlist' ) {
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		count: 		rez.count, 
																		streamHash: rez.hash, 
																		status:		'playlist',
																	  } );
									}	
									else if ( rez.msg === 'progress' ) {
										GetThemAll.Storage.setStream( rez.hash, { progressByte: rez.size, progress: rez.progress } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		count: 		rez.count, 
																		streamHash: rez.hash, 
																		byte: 		rez.size, 
																		progress: 	rez.progress	
																	} );
									}	
									else if ( rez.msg === 'saving' ) {
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		streamHash: rez.hash, 
																		status:		'saving',
																	 } );
									}	
									else if ( rez.msg === 'concat' ) {
										GetThemAll.Storage.setStream( rez.hash, { progress: rez.progress } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		streamHash: rez.hash, 
																		progress: 	rez.progress,
																		status:		'saving',
																	  } );
									}	
							},			
							function(rez)	{ 
									console.log('FINISH', rez);
									if ( !rez.error) {
										for (var j=0; j<rez.filename.length; j++) {
											(function( fn, ext ) {
												GetThemAll.FileSystem.saveVideo({ fileName: fn.filename, 
																				  dirPath: fn.dirPath, 
																				  downloadName: fn.downloadName, 
																				  ext: ext}, function(){
													GetThemAll.FileSystem.removeFile(fn.filename);
												});
											})(rez.filename[j], media.ext)	
										}	
									}
									chrome.extension.sendMessage( {	subject: "mediaStreamerState", state: false, id: media.id   } );
							}
				);									   
			}	
			
			// --------------------------------------------------
			function stopStreamMedia(media) {
				
				chrome.extension.sendMessage( {	subject: "mediaStreamerState", state: false, id: media.id   } );

				GetThemAll.Streamer.stop( media.hash );
			}

			// ===============================================================
			function startRecordMedia(media) {

				console.log('startRecordMedia', media);
				
				GetThemAll.Storage.setTwitch( media.hash, 'start', null );
				chrome.extension.sendMessage( {	subject: 		"mediaDownloadState", 
												id: 			media.id, 	
												metod:			media.metod,
												streamHash: 	media.hash, 
												status:			'start'
											} );
				
				
				GetThemAll.Recorder.start( media.hash, 
													function( rez ) {    // message
														if(rez.error) {
															//console.log(GetThemAll.Recorder.getError());
														}
														else  {
															GetThemAll.Storage.setTwitch( media.hash, rez.state, rez.size );
															chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																							id: 		media.id, 
																							streamHash: media.hash, 
																							byte: 		rez.size, 
																						} );
														}
													},									
													function(rez)	{ 
														console.log('FINISH', rez);
														if ( !rez.error) {
															GetThemAll.FileSystem.saveVideo({	fileName: rez.filename, 
																								downloadName: media.downloadName, 
																								ext: media.ext}, function(){
																GetThemAll.FileSystem.removeFile(rez.filename);
															});
														}
													}
				);
				
			}	
			// --------------------------------------------------
			function stopRecordMedia(media) {
				
				GetThemAll.Storage.setTwitch( media.hash, 'stop', null );
				chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
												id: 		media.id, 
												metod:		media.metod,
												streamHash: media.hash, 
												status:     'stop'
											} );

				GetThemAll.Recorder.stop( media.hash, function(rez)	{ 
						
								if(rez.error) {
									// If true, get error info
									console.log(GetThemAll.Recorder.getError());
								}
								else {
									GetThemAll.Storage.setTwitch( media.hash, rez.state, null  );
									
									var link_href = saveTSFile(rez.file);
									media.url = link_href;
									startDownloadMedia( media );
								}	
						});
			
			}	
			
			
			
			// ===============================================================
			function startConvertMedia(media) {

				console.log('startConvertMedia', media);
			
				GetThemAll.Converter.start( media.hash,
							function(rez)	{ 
									if ( rez.msg === 'start' ) {
										GetThemAll.Storage.setStream( rez.hash, { status:'start' } );
										chrome.extension.sendMessage( {	subject: 		"mediaDownloadState", 
																		id: 			media.id, 	
																		metod:			media.metod,
																		streamHash: 	rez.hash, 
																		status:			'start'
																	} );
									}	
									else if ( rez.msg === 'finish' ) {
										GetThemAll.Storage.setStream( rez.hash, { status: 'stop' } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		metod:		media.metod,
																		streamHash: rez.hash, 
																		status:     'stop'
																	} );
									}
									else if ( rez.msg === 'progress' ) {
										GetThemAll.Storage.setStream( rez.hash, { progressByte: rez.size, progress: rez.progress } );
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		count: 		rez.count, 
																		streamHash: rez.hash, 
																		byte: 		rez.size, 
																		progress: 	rez.progress	
																	} );
									}	
									else if ( rez.msg === 'saving' ) {
										chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
																		id: 		media.id, 
																		streamHash: rez.hash, 
																		status:		'saving',
																	 } );
									}	
							},									
							function(rez)	{
								if ( !rez.error) {
									if (rez.filename.length > 1 ) {
										for (var j=0; j<rez.filename.length; j++) {
											(function( fn, ext ) {
												GetThemAll.FileSystem.saveVideo({ fileName: fn.filename, 
																				  dirPath: fn.dirPath, 
																				  downloadName: fn.downloadName, 
																				  ext: ext}, function(){
													GetThemAll.FileSystem.removeFile(fn.filename);
												});
											})(rez.filename[j], media.ext)	
										}	
									}
									else {
										var fn = rez.filename[0];
										GetThemAll.FileSystem.saveVideo(fn, media.downloadName, media.ext, function(){
											GetThemAll.FileSystem.removeFile(fn);
										});
									}	
								}
							}
				);									   
				
			
			}
			
			// --------------------------------------------------
			function stopConvertMedia(media) {

				console.log('stopConvertMedia', media);

				GetThemAll.Converter.stop( media.hash );
				
				GetThemAll.Storage.setStream( rez.hash, { status: 'stop' } );
				chrome.extension.sendMessage( {	subject: 	"mediaDownloadState", 
												id: 		media.id, 
												metod:		media.metod,
												streamHash: rez.hash, 
												status:		'stop'
											  } );
				
				
			}	
			
			
			// ===============================================================
			function saveTSFile(data)	{ 	
				// If we are replacing a previously generated file we need to
				// manually revoke the object URL to avoid memory leaks.
				if (textFile !== null) 	{
					window.URL.revokeObjectURL(textFile);
				}
			
				textFile = window.URL.createObjectURL(data);		
				return textFile;
			}
			
			// ===============================================================
			this.isStream = function(  ){

				if ( GetThemAll.noFFMpeg ) return false;   
				
				if ( GetThemAll.Storage.getActiveConvertStream() ) return false;				
				
				return true;
			}	
			
		}
		
		this.Media = new Media();
		
	}).apply(GetThemAll);
	
}
else
{
	GetThemAll = chrome.extension.getBackgroundPage().GetThemAll;
}
