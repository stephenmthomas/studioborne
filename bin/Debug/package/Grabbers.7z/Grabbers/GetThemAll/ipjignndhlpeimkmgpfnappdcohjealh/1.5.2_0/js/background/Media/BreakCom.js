(function(){
	
	var BreakCom = function(){		
	
		const TITLE_MAX_LENGTH  = 96;
	
//Seg   	http://www.break.com/video/chubby-korean-baby-dance-2614601   		
// 			http://www.break.com/video/high-school-football-player-hurdles-defender-181429	

		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url.toLowerCase();
			if ( /break.com\/video\/([^.]*)/i.test(url) )		{
				return 1;
			}
			else if ( /^https?\:\/\/(.+?)\.break.com\/([^.]*)/i.test(url) )		{
				return -1;
			}
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){

			var t = check_media(data);
			
			if ( t <= 0 ) return t;
			
			if( t == 1 )  {
				checkBreakCom(data);
			}	
			
			return 1;
		}

		// --------------------------------------------------------------------------------
		function getEmbedFromBreackCom( id, callback ){
			
			var url = 'http://www.break.com/embed/'+id+'/';
			
			// send request to Break.Com
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			
			ajax.onload = function(){
						var content = this.responseText;

						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		
		// --------------------------------------------------------------------------------
		function checkBreakCom( media ){
		
			tabInfo = media.tab;
			var url = media.url;
		
			var k = media.url.lastIndexOf('-');
			var k = url.lastIndexOf('-');
			if ( k != -1) {
				var id = url.substr(k+1);

				getEmbedFromBreackCom( id, function( content ) {  
			
					var AuthToken = content.match( /"AuthToken"\s*:\s*"(.+?)"/i );
					var videoUri = content.match( /"videoUri"\s*:\s*"(.+?)"/i );

					if ( AuthToken && videoUri ) {
						
						var uri = videoUri[1] + "?" + AuthToken[1];
						var contentName = content.match( /"contentName"\s*:\s*"(.+?)"/i );
						var title = contentName ? contentName[1] : media.title;
					
						var thumb = content.match( /"thumbUri"\s*:\s*"(.+?)"/i );
						var thumbnail = thumb ? thumb[1] : media.thumbnail;
					
						var fileName = null, ext = "mp4";
						var ff = GetThemAll.Utils.extractPath( videoUri[1] );
						if (ff) {
							ext = ff.ext;
							fileName = ff.name;
						}	
						else {
							ext = GetThemAll.Utils.extractExtension( videoUri[1] );
							fileName = name;
						}	

						var frmt = "no name";
						if (title) 	{
							frmt = title;
							if ( frmt.length > 10) frmt = frmt.substr(0,10)+"...";
						}
						
						var ft = '<span>[</span>' 
								+'<b>'+GetThemAll.Utils.upperFirst(ext )+'</b>'
								+'<span>] </span>';
						
						
						GetThemAll.Storage.add( {
								url: 		uri,
								tabId: 		media.tabId,
								tabUrl: 	media.tabUrl,
								frameId: 	media.frameId,
								
								thumbnail: 	thumbnail,
								
								ext: 		ext,
								title: 		title,
								format: "",
								
								downloadName: 	title,
								displayName: 	title,
								displayLabel: 	ft,
								filename: 		fileName ? fileName : media.url,
								
								priority: 	20,
								vubor:  	0,
								size: 		null,
								type: 		"media",
								metod: 		"download",
								source: 	"BreakCom",
								groupId: 	0,
								dwnl:		1,
								orderField: 0
							},{
								"findThumbnail": false
							}			
						);
						
					}	
			
				});
			}
		}
		
		// ====================================================================	
		this.getMedia = function( media ){

			return media;	
		}
				
	};
	
	GetThemAll.Media.BreakCom = new BreakCom();
	
})( );
