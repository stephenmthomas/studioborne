(function(){

	var FaceBook = function(){		
	
		var self = this;
		
		const DEBUG = false;
		
		const TITLE_MAX_LENGTH  = 96;

		var videoFacebook = [];

		var detectMediaList = [];
		
		
		var videoGraph = [];
		var graph = {};
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url.toLowerCase();
			
			if ( /\.fbcdn\.net\//i.test(url)) {
				var k1 = url.indexOf('&bytestart');
				var k2 = url.indexOf('&bytestart=0');
				if ( k1 == -1 || k2 != -1 ) {  
					return 1;
				}
				else {
					return -1;	
				}	
			}
/*			if ( /https:\/\/www\.facebook\.com\/(.+?)\/videos\//i.test(url)) {
				return 2;
			}	
			if ( /https:\/\/www\.facebook\.com\/ajax\/pagelet/i.test(url)) {
				return 2;
			}	*/
			
			if ( /^https?:\/\/www\.facebook\.com\/(.*)/i.test(data.tabUrl.toLowerCase()) )		{
				return 3;
			}
			
			if ( /^https:\/\/www\.facebook\.com\/?$/i.test(url)) {
				return -9;
			}	
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return t;
			
			if( t == 1 )  {
				detectVideo_convert(data);
			}	
			else if( t == 2 )  {
				detectVideo_page(data, 3000);
			}	
			else if( t == 3 )  {
				parse_VideoData(data);
			}	
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectVideo_graph( media ){

			var url = media.url;
			var ext = media.ext;
			var filename = media.fileName;

			if (ext != 'mp4') return false;
			
			getInfo( filename, ext, url, function(info){ 
		
				if (graph[info.title]) {
					
				}
				else {
					graph[info.title] = { videoId: info.title,		 info: null   }; 

					graphVideo(info.title, function(rez){

						if (rez) {
							graph[info.title].info = rez;
						
							addVideo({  tabId: 		media.tabId,
										tabUrl: 	media.tabUrl,
										url:    	rez.source,
										thumbnail: 	rez.picture,
										title:		rez.name || rez.from.name,
										videoId:	info.title
									});
						}
					});
				}	
			});
		}
		
		// --------------------------------------------------------------------------------
		function getInfo( filename, ext, url, callback ){
			
			if (DEBUG) console.log('getInfo', filename, ext, url);
		
			// такое уже было
			for (var i=0; i<videoFacebook.length; i++) {
				if (videoFacebook[i].filename === filename) {
					if (videoFacebook[i].info ) {
						callback(videoFacebook[i].info);
					}    
					else {
						videoFacebook[i].run.push( callback );	
					}	
					return;
				}    
			}

			// не было добавляем	
			videoFacebook.push({ filename: filename,
								 ext: ext,
								 url: url,
								 info: null,
								 run: [ callback ]
							   });
							   
			GetThemAll.Moov.getInfoHeaderFile(url, function(info){
				
				if (DEBUG) console.log('getInfo = ', info);

				for (var i=0; i<videoFacebook.length; i++) {
					if (videoFacebook[i].filename === filename) {
						info.url = videoFacebook[i].url;
						videoFacebook[i].info = info;
						
						for (var j=0; j<videoFacebook[i].run.length; j++) {
							var func = videoFacebook[i].run[j];
							func(info);
						}
						return;
					}    
				}
			
			});
		
		}
		
		// --------------------------------------------------------------------------------
		function detectVideo_convert( media ){

			var url = media.url;
			var ext = media.ext;
			var filename = media.fileName;

			if (ext != 'mp4') return false;
			
			if (DEBUG) console.log('>>', url);
			
			getInfo( filename, ext, url, function(info){ 
			
				if (info && info.type) {
					
					if (info.type == 'full') {
						console.log('\n ---full----', info);
						detect_convert({  video: info, audio: null    });
					}
					else if (info.type == 'audio') {
						if (DEBUG) console.log('\n ---audio----', info);
						find_video( info );
					}    
					else if (info.type == 'video') {
						if (DEBUG) console.log('\n ---video----', info);
						find_audio( info );
					}    
				
				}	
				
			});
			
			function find_video( info ) {
				
				for (var jj=0; jj<videoFacebook.length; jj++) {
					if (info.title) {
						if (videoFacebook[jj].info && videoFacebook[jj].info.title == info.title && videoFacebook[jj].info.type == 'video' ) {
							detect_convert({audio: info, video: videoFacebook[jj].info });
						}
					}
					else if (info.duration) {
						if (videoFacebook[jj].info && compare_duration(videoFacebook[jj].info.duration, info.duration) && videoFacebook[jj].info.type == 'video' ) {
							detect_convert({audio: info, video: videoFacebook[jj].info });
						}    
					}
				}	
				
			}

			function find_audio( info ) {

				for (var jj=0; jj<videoFacebook.length; jj++) {
					if (info.title) {
						if (videoFacebook[jj].info && videoFacebook[jj].info.title == info.title && videoFacebook[jj].info.type == 'audio' ) {
							detect_convert({video: info, audio: videoFacebook[jj].info });
						}
					}    
					else if (info.duration) {
						if (videoFacebook[jj].info && compare_duration(videoFacebook[jj].info.duration, info.duration) && videoFacebook[jj].info.type == 'audio' ) {
							detect_convert({video: info, audio: videoFacebook[jj].info });
						}    
					}
				}        
			}
			
			// ----------------------------------------------
			function compare_duration(x, y) {
				if ( !x || !y )  return false;

				var xx = get_time(x);
				var yy = get_time(y);

				if ( (xx-yy)/xx*100 < 1 )  return true;

				return false;
			}    
			// ----------------------------------------------
			function get_time(str) {
				
				if (typeof str == 'number') return str;
				
				try {
					return parseInt(str);
				}
				catch(ex) {	
					var p = str.split('.');
					var n = p[0].split(':');

					if (n.length==3) {
						return parseInt(n[2])*3600 + parseInt(n[1])*60 + parseInt(n[0])
					}           
					if (n.length==2) {
						return parseInt(n[1])*60 + parseInt(n[0])
					}           
					if (n.length==1) {
						return parseInt(n[0])
					}           
				}	
				return 0;
			} 
			// --------------------------------
			function detect_convert( d ) {
	
				if (DEBUG) console.log('detect_convert', d);
				
				var label = d.video.quality ? (d.video.quality.width + 'x' + d.video.quality.height) : "";
				
				var detect_media = {	videoId: 	d.video.title,
				
										videoUrl:	delete_bytestart(d.video.url),
										audioUrl:	d.audio? delete_bytestart(d.audio.url) : null,
										
										filename:   d.video.filename,
										ext:   		'mp4',

										duration:   d.video.duration,
										filename:   d.video.filename,
										
										quality:	d.video.quality,
												
										tabId:		media.tabId,
										tabUrl:		media.tabUrl,
										tabTitle:	media.tabTitle,
										thumbnail:	media.thumbnail,
										
										label:		label,
										hash: 		d.video.title + '_' + label,										
									};

				graph_media( detect_media );
			}	
			
			function delete_bytestart(url) {
			
				var k = url.indexOf('&bytestart=0');
				if ( k != -1 )  url = url.substring(0, k);
				return url;
			}
			
			// --------------------------------
			function graph_media( d ) {
			
				if (DEBUG) console.log('graph_media', d, graph);

				if ( !d.videoId ) {
					if (d.audioUrl == null) {
						add_full_media( d );
					}
				}
				else if (graph[d.videoId]) {
					if (graph[d.videoId].info) {
						d.title = graph[d.videoId].info.name || graph[d.videoId].info.from.name;
						d.thumbnail = graph[d.videoId].info.picture;
						
						addVideo({  tabId: 		media.tabId,
									tabUrl: 	media.tabUrl,
									url:    	graph[d.videoId].info.source,
									thumbnail: 	graph[d.videoId].info.picture,
									title:		graph[d.videoId].info.name || graph[d.videoId].info.from.name,
									videoId:	d.videoId
								});
					}
					else if (d.audioUrl == null) {	
						add_full_media( d );
					}
				}
				else {
					graph[d.videoId] = { videoId: d.videoId,
										 info: null,	
									   }; 

					graphVideo(d.videoId, function(rez){
						
						if (rez) {
							graph[d.videoId].info = rez;

							addVideo({  tabId: 		media.tabId,
										tabUrl: 	media.tabUrl,
										url:    	rez.source,
										thumbnail: 	rez.picture,
										title:		rez.name || rez.from.name,
										videoId:	d.videoId
									});
						}
						else if (d.audioUrl == null) {
							add_full_media( d );
						}
						else {						
							add_convert_video( d );
						}
						
					});
				}
			}
			
			// --------------------------------
			function add_full_media( d ) {

				addVideo({  tabId: 		media.tabId,
							tabUrl: 	media.tabUrl,
							url:    	d.videoUrl,
							thumbnail: 	media.thumbnail,
							title:		media.tabTitle,
							videoId:	d.videoId
						});

			}	
			
			// --------------------------------
			function add_convert_video( d ) {
				
				addConvertVideo({  
							tabId: 		media.tabId,
							tabUrl: 	media.tabUrl,
							url:    	d.videoUrl,
							thumbnail: 	media.thumbnail,
							title:		media.tabTitle,
							videoId:	d.videoId,
							audio_url:  d.audioUrl
						});

			}	
		}
		
		// -----------------------------------------------------
		function graphVideo(videoId, callback) {

			if (!videoId) 	return;

			var url = 'https://graph.facebook.com/'+videoId+'?fields=name,picture,source,from,length';
			if (DEBUG) console.log('--graphVideo---', url)
			getAJAX(url, null, function(resp){
				
					if (resp) {
						try {
							var x = JSON.parse(resp);
							if (x.error) {
								callback(null);
							}  
							else {
								callback(x);
							}
						}
						catch(ex){
							console.error(ex);
							callback(null);
						}
					}
					else {
						callback(null);
					}    
			});
		}
		
		// --------------------------------------------------------------------------------
		function addVideo( params ){
			
			if (DEBUG) console.log('addVideo', params);

			var displayName = params.title ? params.title : params.tabTitle;
			var downloadName = displayName;
			
			var ff = GetThemAll.Utils.extractPath( params.url );
			var ext = ff.ext;
			var filename = ff.name;

			var ft = "";
			if ( params.label) {	
				ft = '<span>[</span>' 
					+'<span>'+params.label+', </span>' 
					+'<b>'+GetThemAll.Utils.upperFirst(ext )+'</b>'
					+'<span>] </span>'; 
			}			
			
			GetThemAll.Storage.add( {
					url: 		params.url,
					tabId: 		params.tabId,
					tabUrl: 	params.tabUrl,
					
					videoId: 	params.videoId,
					hash: 		params.videoId + (params.label ? '_'+params.label : ''),
					thumbnail: 	params.thumbnail,
					
					ext: 		ext,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		filename,
					
					groupId:		params.group ? params.group : null,
					orderField: 	params.order ? params.order : null,
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"media",
					metod: 		'download',
					source: 	"FaceBook",
					quality:    params.label ? params.label : null,
					
					dwnl:		1,
					
				},{
					findThumbnail: false,
					noReplace: true
				});

		}		
		
		// --------------------------------------------------------------------------------
		function addConvertVideo( params ){
			
			if (DEBUG) console.log('addConvertVideo', params);
			return;

			var displayName = params.title ? params.title : params.tabTitle;
			var downloadName = displayName;
			
			var ff = GetThemAll.Utils.extractPath( params.url );
			
			var ext = ff.ext;
			var filename = ff.name;
			
			ff = GetThemAll.Utils.extractPath( params.audio_url );
			var audio_ext = ff.ext;

			GetThemAll.Storage.add( {
					url: 		params.url,
					tabId: 		params.tabId,
					tabUrl: 	params.tabUrl,
					
					videoId: 	params.videoId,
					hash: 		params.videoId,
					thumbnail: 	params.thumbnail,
					
					ext: 		ext,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	'',
					filename: 		filename,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"media",
					metod: 		'convert',
					source: 	"FaceBook",
					quality:    null,
					
					dwnl:		1,
					
					params:    { audio_url:  params.audio_url,
								 audio_ext:  audio_ext   }
					
				},{
					findThumbnail: true,
					noReplace: true
				});

		}		
		
		// --------------------------------------------------------------------------------
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		// --------------------------------------------------------------------------------
		function parse_VideoData( data ){
			
			var mediaFound = false;
			var parsedMediaList = [];
			var videoTitle;
			var thumbnail = data.thumbnail;
			
			var title = data.tabTitle;
	
			getAJAX( data.url, null, function(content){
				if ( !content ) return;
				var mm = content.match( /<title\sid="pageTitle">(.+?)<\/title>/im ); 
				if (mm) title = mm[1];		

				var k = 0; 	
				var kk = 0;
				do {
					k = content.indexOf('videoData');	
					kk++;
					
					if ( k != -1 ) {
						var l = content.lastIndexOf('background-image:', k);
						if (l != -1) {
							var str = content.substr( l, k);
							var ll = content.match( /url\((.+?)\);/im ); 
							if (ll) {
								thumbnail = ll[1].replace(/\\/g,'').replace(/&amp;/g,'&');
							}	
						}
						
						var m = content.match( /"?videoData"?:\[\{(.+?)\}\]/im ); 
						if (m) {
							var info = m[1];
							
							var videoId = get_JSON_param( 'video_id', info );
							var srcHD = get_JSON_param( 'hd_src', info );
							var srcSD = get_JSON_param( 'sd_src', info );

							k += info.length;
							content = content.substring(k, content.length);
							var videoTitle = get_JSON_param( 'ownerName', content );
							var groupMedia = GetThemAll.Storage.nextGroupId();     
							
							if (srcHD) {
								addVideo({  tabId: 		data.tabId,
											tabUrl: 	data.tabUrl,
											url:    	srcHD.replace(/\\/g,''),
											thumbnail: 	thumbnail,
											title:		videoTitle || title,
											videoId:	videoId,
											label:      'hd',
											order:    2,
											group: 		groupMedia
										});
							}
							if (srcSD) {
								addVideo({  tabId: 		data.tabId,
											tabUrl: 	data.tabUrl,
											url:    	srcSD.replace(/\\/g,''),
											thumbnail: 	thumbnail,
											title:		videoTitle || title,
											videoId:	videoId,
											label:      'sd',
											order:    1,
											group: 		groupMedia
										});
							}
							
						}
					}
					
				} while ( k != -1 && kk < 100 );
				
			});


		}	
		
		// ------------------------------
		function get_JSON_param( name, val ){           
		
			var x = '"?' + name + '"?\s*:([^\,]+)';
			var rxe = new RegExp( x, 'i');
			var m  = rxe.exec(val);
			if (m)  {
				if ( m[1] == "null" ) return null;
				return m[1].substring(1, m[1].length-1);
			}   
			return null;
		}
		
		// ------------------------------
		function getFileName( url ){
		
			if ( !url ) return null;
		
			var ext = null;
			var ff = url;
			var k = ff.indexOf('?');
			if (k != -1) {
				ff = ff.substring(0, k);	
			}
			
			k = ff.indexOf('//');
			if (k != -1) {
				ff = ff.substring(k+2, ff.length);	
			}
			
			k = ff.indexOf('/');
			if (k != -1) {
				ff = ff.substring(k, ff.length);	
			}
			
			k = ff.lastIndexOf('.');
			if (k != -1) {
				ext = ff.substring(k+1, ff.length);	
				ff = ff.substring(0, k);	
				k = ff.lastIndexOf('/');
				if (k != -1) {
					ff = ff.substring(k+1, ff.length);	
					return { name: ff, ext: ext};
				}	
			}

			return null;	
		}
		
		// --------------------------------------------------------------------------------
		function detectVideo_page( data ){

			setTimeout( function(){
				WorkerForContent( data )
			}, 3000);
		}	
		
		// ---------
		function WorkerForContent(data) {

			console.log('WorkerForContent: ', data.tabId);

			chrome.tabs.sendRequest(data.tabId, {	type: "get-video"	}, function(results) {
					
				var video = results.videos;
				
				for (var i=0; i<video.length; i++) {
					var displayName = data.tabTitle;
					var downloadName = displayName;
			
					var ff = GetThemAll.Utils.extractPath( video[i].url );
					var ext = ff.ext;
					var filename = ff.name;
			
					var hash = hex_md5(video[i].url);
					
					var ft = '<span>[</span>' 
							+'<span>'+video[i].quality.width+'x'+video[i].quality.height+', </span>'
							+'<b>'+GetThemAll.Utils.upperFirst(ext )+'</b>'
							+'<span>] </span>';
					
				
					GetThemAll.Media.Storage.add( {
							url: 		video[i].url,
							tabId: 		data.tabId,
							tabUrl: 	data.tabUrl,
							
							hash: 		hash,
							thumbnail: 	data.thumbnail,
							
							ext: 		ext,
							title: 		displayName,
							format: 	"",
							
							downloadName: 	downloadName,
							displayName: 	displayName,
							displayLabel: 	ft,
							filename: 		filename,
							
							priority: 	10,
							vubor:  	0,
							size: 		0,
							type: 		"video",
							metod: 		'download',
							source: 	"FaceBook",
							quality:    video[i].quality.height,
							
							dwnl:		1,
							
						},{
							findThumbnail: false,
							noReplace: true
						});

			
				}
			});
				
		
		}
		
		
		// --------------------------------------------------------------------------------
		this.isEqualItems = function( item1, item2 ){
			
			if(  item1.hash == item2.hash  )		return 1;
			
			return 0;
			
		}

		// ====================================================================	
		this.getMedia = function( media ){

			return media;	
		}

	}
	
	GetThemAll.Media.FaceBook = new FaceBook();
	
})( );
