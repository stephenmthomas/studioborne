(function(){
	
	var MediaManifest = function(){		
		
		const TITLE_MAX_LENGTH  = 96;
	
		var mediaDetectCallbacks = [];
		
		var self = this;
		
		const IGNORE_URL_SIGNS = [];
		
		var lastStreamId = 0;	

		const DEBUG = false;

		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url.toLowerCase();
			
			if( /^https?:\/\/[^\?]*\.f4m/.test(url) )  {			// https://tv.nrk.no/program/FUHA04001888/leonard-cohen-i-oslo-konserthus-1988#
				return 1;
			} 
			else if( /^https?:\/\/(.*)seg(\d+)-frag(\d+)/.test(url) ) {
				return -1;            
			}    
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			var ignore = false;
			IGNORE_URL_SIGNS.forEach(function( sign ){
				if( data.url.toLowerCase().indexOf( sign ) != -1 ){
					ignore = true;
					return false;
				}
				if( data.tab.url.toLowerCase().indexOf( sign ) != -1 ){
					ignore = true;
					return false;
				}
			});
			if( ignore )			return false;


			getAJAX( data.url, null, function(content){

				var xml = GetThemAll.Utils.parseXml( content );
				if (xml) {
					ParseManifest(xml, data);
				}

			});
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function ParseManifest( xml, media ){

			var url = media.url;
			var hh = hex_md5(url);
			var videoId = null;
			var videoTitle = media.tabTitle;
			var groupMedia = GetThemAll.Storage.nextGroupId();
			
			var domain = null, k, tt, host = null, prot = "", search = null;
			var x = GetThemAll.Utils.parse_URL(url);
			host = x.protocol + '//' + x.hostname + x.path+'/';
			domain = x.protocol + '//' + x.hostname;
			search = x.search || "";
			
			console.log(xml, domain, host);	

			var duration = "",
				t = '',
				e = '',
				streamType = '',
				baseURL = null,
				bootstrapInfo = {};
				
			try {
				// тип записи
				t = xml.getElementsByTagName('streamType');;
				e = t.item(0); 
				if (e) streamType = e.textContent || e.streamType.textContent;
		
				// базовый адрес
				t = xml.getElementsByTagName('baseURL');  
				e = t.item(0); 
				if (e) baseURL = e.textContent || e.baseURL.textContent;
				else   baseURL = host;

				// продолжительность
				t = xml.getElementsByTagName('duration');  
				e = t.item(0); 
				if (e) duration = e.textContent || e.duration.textContent;

				// bootstrapInfo
				t = xml.getElementsByTagName('bootstrapInfo');
				for (var i=0; i<t.length; i++) {    
					e = t.item(i);
					if (e) {
						var id = e.getAttribute('id');
						var url = e.getAttribute('url');
						var text = e.textContent;
						bootstrapInfo[id] = {id: id, text: text, url: url};
					}    
				}   
			}
			catch(ex) {
				return;
			}	
console.log(bootstrapInfo);			
			
			if (streamType == 'recorded') {
				ParseRecorder();
			}
			else if (streamType == 'live') {			
				ParseLive();
			}
			
			// -----------------------------------------------------------
			function ParseRecorder()  {
				
				var mediaXML = [];
				
				t = xml.getElementsByTagName('media');
				for (var i=0; i<t.length; i++) {
					var bootId = t[i].getAttribute('bootstrapInfoId');
					var width = t[i].getAttribute('width');
					var height = t[i].getAttribute('height');
					var streamId = t[i].getAttribute('streamId');
					var bitrate = t[i].getAttribute('bitrate');
					var uri = t[i].getAttribute('url');
					if ( ! /^https?/.test(uri) ) {            
						uri = baseURL + uri;            
					} 

					var tt = t[i].getElementsByTagName('metadata');
					if (tt && tt.item(0)) {
						var text = tt.item(0).textContent.trim();

						var bootstrap = bootstrapInfo[bootId].text;
						if (bootstrap) bootstrap = GetThemAll.jspack.stringToBytes(window.atob(bootstrap));

						mediaXML.push({		streamId: streamId,
											bootId: bootId,
											width:	width,
											height:	height,
											bitrate: bitrate,
											uri: uri,			
											metadata: window.atob(text),
											bootstrap: bootstrap,
											duration: duration,
											streamType: streamType,
											group: groupMedia
									});
					}				
				}	
				
				console.log(mediaXML);				
				if (mediaXML.length == 0) return;

				for (var i=0; i<mediaXML.length; i++) {
					addMediaRecorder(mediaXML[i]);			
				}	
			}	
				
			// -----------------------------------------------------------
			function addMediaRecorder(mXML)  {
				
				console.log(mXML.bootId);

				var paramsBootstrap = {};

				// omMetaData
				var onMetaData = GetThemAll.jspack.stringToBytes(mXML.metadata);  

				var x = GetThemAll.Bootstrap.decodeAMF(onMetaData);  
			
				if (x && x.length>1) {
					mXML.amf = x[1];
					if (mXML.amf['width'])  mXML.width = mXML.amf['width']; 
					if (mXML.amf['height'])  mXML.height = mXML.amf['height']; 
					if (mXML.amf['filesize'])  mXML.size = mXML.amf['filesize']; 
				}

				var label = "" + (mXML.width ? mXML.width : "") + ((mXML.width && mXML.height) ? 'x' : '') + (mXML.height ? mXML.height : "");
				if (!label) label = mXML.bitrate ? mXML.bitrate : ""; 
				if (!label) {
					var m = url.match(/([0-9]*)x([0-9]*)/g);
					if(m)   label = m[m.length-1];   
				}   
				if (!label)     label = streamId;
				
				paramsBootstrap.uri = mXML.uri;
				
				var list = GetThemAll.Bootstrap.listSegment(mXML.bootstrap, paramsBootstrap);
				
				var initSeg = GetThemAll.Bootstrap.WriteMetadata(GetThemAll.jspack.stringToBytes(mXML.metadata));
				
				var ext = 'flv';
				if (mXML.streamId) {
					var k = mXML.streamId.lastIndexOf('.');
					if ( k != -1 )  {
						var ee = mXML.streamId.substring(k+1, mXML.streamId.length);
						if (['mp4','flv','webm'].indexOf(ee) != -1)  ext = ee;
					}
				}
				else {    
					lastStreamId++;
					mXML.streamId = "stream"+lastStreamId;
				}            

				addVideo( { 
							hash: mXML.streamId+'_'+(label ? label : ''), 
							url:  url, 
							playlist: list, 
							quality: label, 
							videoTitle: videoTitle, 
							ext: ext, 
							metadata: initSeg,
							bootstrap: paramsBootstrap,
							group: mXML.group,
							data: media,
						} );
				
				// -----------------------------			
			
			}	
			
			// -----------------------------------------------------------
			function ParseLive()  {

				var mediaXML = [];

				t = xml.getElementsByTagName('media');
				for (var i=0; i<t.length; i++) {
					var bootId = t[i].getAttribute('bootstrapInfoId');
					var width = t[i].getAttribute('width');
					var height = t[i].getAttribute('height');
					var streamId = t[i].getAttribute('streamId');
					var bitrate = t[i].getAttribute('bitrate');
					var uri = t[i].getAttribute('url');
					if ( ! /^https?/.test(uri) ) {            
						uri = baseURL + uri;            
					} 
					
					var u = bootstrapInfo[bootId].url;
					if (u.indexOf('http') != 0) {
						if (u.indexOf('/') == 0)  u = domain + u;
						else    u = host + u;
					}
					if (u.indexOf('?') == -1 && u.indexOf('#') == -1 && search) {
						u = u + search;
					}    

					var tt = t[i].getElementsByTagName('metadata');
					if (tt && tt.item(0)) {
						var text = tt.item(0).textContent.trim();

						mediaXML.push({		streamId: streamId,
											bootId: bootId,
											width:	width,
											height:	height,
											bitrate: bitrate,
											uri: uri,			
											metadata: window.atob(text),
											bootstrapUrl: u,
											duration: duration,
											streamType: streamType,
											group: groupMedia
									});
					}				
				}	
				
				console.log(mediaXML);				
				if (mediaXML.length == 0) return;

				for (var i=0; i<mediaXML.length; i++) {
					addMediaLive(mediaXML[i]);			
				}	
			
			}

		
			// -----------------------------------------------------------
			function addMediaLive(mXML)  {
				
				// omMetaData
				var onMetaData = GetThemAll.jspack.stringToBytes(mXML.metadata);  

				var x = GetThemAll.Bootstrap.decodeAMF(onMetaData);  
			
				if (x && x.length>1) {
					mXML.amf = x[1];
					if (mXML.amf['width'])  mXML.width = mXML.amf['width']; 
					if (mXML.amf['height'])  mXML.height = mXML.amf['height']; 
					if (mXML.amf['filesize'])  mXML.size = mXML.amf['filesize']; 
				}

				var label = "" + (mXML.width ? mXML.width : "") + ((mXML.width && mXML.height) ? 'x' : '') + (mXML.height ? mXML.height : "");
				if (!label) label = mXML.bitrate ? mXML.bitrate : ""; 
				if (!label) {
					var m = url.match(/([0-9]*)x([0-9]*)/g);
					if(m)   label = m[m.length-1];   
				}   
				if (!label)     label = streamId;
				
				var initSeg = GetThemAll.Bootstrap.WriteMetadata(GetThemAll.jspack.stringToBytes(mXML.metadata));
				
				var ext = 'flv';
				if (mXML.streamId) {
					var k = mXML.streamId.lastIndexOf('.');
					if ( k != -1 )  {
						var ee = mXML.streamId.substring(k+1, mXML.streamId.length);
						if (['mp4','flv','webm'].indexOf(ee) != -1)  ext = ee;
					}
				}
				else {    
					lastStreamId++;
					mXML.streamId = "stream"+lastStreamId;
				}            

				addLive( { 
							hash: mXML.streamId+'_'+(label ? label : ''), 
							baseUrl:  mXML.uri, 
							url: mXML.bootstrapUrl, 
							quality: label, 
							videoTitle: videoTitle, 
							ext: ext, 
							metadata: initSeg,
							group: mXML.group,
							data: media,
						} );
				
				// -----------------------------			
			
			}	
			
			
		}	

		// --------------------------------------------------------------------------------
		function addVideo( params ){
			
			console.log(params);
			
			var q = null;
			if (params.quality) {
				var m = params.quality.match( /([0-9]+)x([0-9]+)/im ); 
				q = m ? m[2] : params.quality; 
				try { q = parseInt(q);	} catch(ex) {}		
			} 

			var ft = '<span>[</span>' 
					+(params.quality ? '<span>'+params.quality+', </span>' : '') 
					+'<b>'+GetThemAll.Utils.upperFirst(params.ext )+'</b>'
					+'<span>] </span>';
					
			var displayName = params.data.tabTitle ? params.data.tabTitle : params.data.fileName;

			fileName = params.quality;
			var ff = GetThemAll.Utils.extractPath( params.url );
			if (ff) {
				fileName = (params.quality ? params.quality+'_' : '')+ff.name;
			}					
			else {
				fileName = (params.quality ? '['+params.quality+'] ' : '')+params.data.tabTitle;	
			}	
			
			GetThemAll.Storage.add( {
					url: 		params.url,
					tabId: 		params.data.tabId,
					tabUrl: 	params.data.tabUrl,
					frameId: 	params.data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	params.data.thumbnail,
					
					ext: 		params.ext,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	displayName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					playlist: 		params.playlist,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"media",
					metod: 		'stream',
					source: 	"MediaManifest",
					quality:    q,
					
					groupId: 	params.group,
					orderField: q,
					dwnl:		1,
					
					params:     {"metadata": params.metadata,
								 "bootstrap": params.bootstrap,
								 "base_url": params.baseUrl
								}
					
				});
			
		}
		
		
		// --------------------------------------------------------------------------------
		function addLive( params ){
			
			console.log(params);
			
			var q = null;
			if (params.quality) {
				var m = params.quality.match( /([0-9]+)x([0-9]+)/im ); 
				q = m ? m[2] : params.quality; 
				try { q = parseInt(q);	} catch(ex) {}		
			} 

			var ft = '<span>[</span>' 
					+(params.quality ? '<span>'+params.quality+', </span>' : '') 
					+'<b>'+GetThemAll.Utils.upperFirst(params.ext )+'</b>'
					+'<span>] </span>';
					
			var displayName = params.data.tabTitle ? params.data.tabTitle : params.data.fileName;

			fileName = params.quality;
			var ff = GetThemAll.Utils.extractPath( params.url );
			if (ff) {
				fileName = (params.quality ? params.quality+'_' : '')+ff.name;
			}					
			else {
				fileName = (params.quality ? '['+params.quality+'] ' : '')+params.data.tabTitle;	
			}	
			
			GetThemAll.Storage.add( {
					url: 		params.url,
					tabId: 		params.data.tabId,
					tabUrl: 	params.data.tabUrl,
					frameId: 	params.data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	params.data.thumbnail,
					
					ext: 		params.ext,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	displayName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					playlist: 		params.playlist,
					
					priority: 	10,
					vubor:  	0,
					size: 		0,
					type: 		"media",
					metod: 		'record',
					source: 	"MediaManifest",
					quality:    q,
					
					groupId: 	params.group,
					orderField: q,
					dwnl:		1,
					
					params:     {"metadata": params.metadata,	
								 "base_url":  params.baseUrl	}
					
				});
			
		}
		
		// ====================================================================	
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		// -----------------------------------------------------------
		this.onMediaDetect = {
			addListener: function( callback ){
				if( mediaDetectCallbacks.indexOf( callback ) == -1 )
				{
					mediaDetectCallbacks.push( callback );
				}
			}
		};
		
		// ====================================================================	
		this.getMedia = function( media ){

			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "MediaManifest" )   stream_media.push( item );
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	
		}

	};
	
	GetThemAll.Media.MediaManifest = new MediaManifest();
	
})( );
