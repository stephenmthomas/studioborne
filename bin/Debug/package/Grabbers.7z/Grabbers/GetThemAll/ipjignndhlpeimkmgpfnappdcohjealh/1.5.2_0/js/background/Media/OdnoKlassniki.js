(function(){
	
	var OdnoKlassniki = function(){		
	
		const TITLE_MAX_LENGTH  = 96;
	
		var mediaDetectCallbacks = [];
		
		// --------------------------------------------------------------------------------
		this.checkMedia = function( data ){
			
			var x = check_media(data);
			
			if (x>0) return 1;
			
			return x;
		}
		
		function check_media(data) {
			
			var url = data.url;
			
			if(/\/stream.manifest\/sig\/(.+?)\/CHROME\/video\?/i.test(url)) {		// OK Live
				return 1;
			}        
			else if(/ok\.ru\/video\/(.+?)/i.test(url)) {		
				return 2;
			}        
			// ------------- ignore
			else if(/\/stream.manifest\/sig\/(.+?)\/CHROME\/frag/i.test(url)) {		
				return -1;
			}
			else if(/^https:\/\/(.+?)\.mycdn.me\/\?(.+?)\&bytes=([0-9]+)-([0-9]+)/i.test(url)) {		
				return -1;
			}
			
			return 0;
			
		}	

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			var t = check_media(data);
			
			if ( t <= 0 ) return 0;
			
			if( t == 1 )  {
				detectLiveVideo(data);
			}	
			else if( t == 2 )  {
				detectVideo(data);
			}	
			
			return 1;
		}
		
		// --------------------------------------------------------------------------------
		function detectLiveVideo( data ){

			var url, streamId, groupMedia;

			url = data.url;
			var mm = url.match( /\/dash\/(.+?)\/stream.manifest\//im ); 
			if (mm) {
				streamId = mm[1];
				getAJAX( url, null, function(content){

					if (content) {

						groupMedia = GetThemAll.Storage.nextGroupId();     

						try {
							var info = JSON.parse(content);
							for ( var i=0; i<info.length; i++) {

								add_live_video( info[i] );

							}
						}
						catch(ex){
							console.error(ex);
						}
					}
				});	
			}

			// -------------------------------------------------------------
			function IsRequestSuccessful (httpReq) {
				var success = (httpReq.status == 0 || (httpReq.status >= 200 && httpReq.status < 300) || httpReq.status == 304 || httpReq.status == 1223);
				return success;
			}
			// -------------------
			function add_live_video( v ) {

				var hash = streamId + '_' + v.name;

				var x = GetThemAll.Utils.parse_URL(url);
				var host = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '') + x.path+'/';
				var search = x.search || "";

				var headerUrl = host + v.headerUrl;
				
				var httpRequest = new XMLHttpRequest(); 
				httpRequest.open ("GET", headerUrl, true);
				httpRequest.responseType = "arraybuffer"; 
				httpRequest.onreadystatechange = function() {
						if (httpRequest.readyState==4) {
							if (IsRequestSuccessful (httpRequest)) 	{

								var boot = new Uint8Array(httpRequest.response);
								
								var indexUrl = host + v.idxUrl + search;
								
								addLiveVideo( { hash: 		hash,
												url: 		url,

												ext: 		'mp4',
												quality: 	{ width: v.video.width, height: v.video.height },
												playlist: 	indexUrl,
												videoId: 	streamId,

												groupId: 	groupMedia,
												orderField: v.video.height,
												initSeg:    boot,
												template:   v.fragUrlTemplate,
												baseUrl: 	host, 
											  }, data )
								
							}
							else 	{
								console.log('====ERROR=====load_dash==== httpRequest =====');
							}
						}
				};

				httpRequest.send();
			}
		}
		
		// --------------------------------------------------------------------------------
		function addLiveVideo( params, data ){

			console.log(params)

			var ft = '<span>[</span>' 
					+'<span>'+params.quality.width+'x'+params.quality.height+', </span>'
					+'<b>'+GetThemAll.Utils.upperFirst(params.ext )+'</b>'
					+'<span>] </span>';
					
			var displayName = data.tabTitle;
			var downloadName = displayName;

			var fileName = params.hash;	
			
			GetThemAll.Storage.add( {
					url: 		params.url,
					tabId: 		data.tabId,
					tabUrl: 	data.tabUrl,
					frameId: 	data.frameId,
					
					hash: 		params.hash,
					thumbnail: 	data.thumbnail,
					
					ext: 		params.ext,
					title: 		displayName,
					format: 	"",
					
					downloadName: 	downloadName,
					displayName: 	displayName,
					displayLabel: 	ft,
					filename: 		fileName,
					
					playlist:       params.playlist,
					
					priority: 		10,
					vubor:  		0,
					size: 			0,
					type: 			"media",
					metod: 			"record",
					source: 		"OdnoKlassniki",
					quality:    	params.quality,
					
					groupId: 		params.groupId,
					orderField: 	params.orderField,
					dwnl:			1,
					
					params: 	{	init:    params.initSeg,
									frag_template: params.template,
									base_url: params.baseUrl
								}
				},{
                    "findThumbnail": false,
					"noReplace":     true
                }			
            );    


		}
		
		// --------------------------------------------------------------------------------
		function detectVideo( data ){

			getAJAX( data.url, null, function(content){

				if (content) {
					
					var m = content.match( /data-options="(.+?)"/gm ); 
					if (m) {
						for ( var ii=0; ii<m.length; ii++) {

							var mm = m[ii].match( /data-options="(.+?)"/i ); 
							if ( !mm ) continue;

							var str = mm[1].replace(/&quot;/g,'"');
							try {
								var options = JSON.parse(str);
							}
							catch(ex) {
								console.error('parse_odnoklassniki (options)',ex);
								continue;
							}  
						
							var playerId = options["playerId"];
							var flashvars = options["flashvars"];
							var metadata = flashvars["metadata"];
							
							if (!metadata) continue;

							try {
								metadata = JSON.parse(metadata);
							}
							catch(ex) {
								console.error('parse_odnoklassniki (metadata)',ex);
								continue;
							}   

							if (!metadata)  continue;	
				
							var movie = metadata['movie'];
							var videoId = movie["id"];
							var title = movie['title'] || data.tabTitle;
							var thumbnail = movie['poster'];
							var duration = movie['duration'];

							var videos = metadata['videos'];
							
							var ext = "mp4";
						
							groupMedia = GetThemAll.Storage.nextGroupId();
							
							for (var i=0; i<videos.length; i++) {
								var url = decodeURIComponent(videos[i].url);
								var label = videos[i].name;

								var hash = label+'_'+videoId;

								var ft = '<span>[</span>' 
										+'<span>'+label+', </span>'
										+'<b>'+GetThemAll.Utils.upperFirst(ext )+'</b>'
										+'<span>] </span>';
								
								GetThemAll.Storage.add( {
										url: 		url,
										tabId: 		data.tabId,
										tabUrl: 	data.tabUrl,
										frameId: 	data.frameId,
										
										hash: 		hash,
										thumbnail: 	thumbnail ? thumbnail : data.thumbnail,
										
										ext: 		ext,
										title: 		title,
										format: 	"",
										
										downloadName: 	title,
										displayName: 	title,
										displayLabel: 	ft,
										filename: 		hash,
										
										priority: 		10,
										vubor:  		0,
										size: 			0,
										type: 			"media",
										metod: 			"download",
										source: 		"OdnoKlassniki",
										quality:    	label,
										
										groupId: 		groupMedia,
										dwnl:			1,
										
									},{
										"findThumbnail": false,
										"noReplace":     true
									} );			
							}
						}	
					}
				}	
			});
		}	
		
			
		// --------------------------------------------------------------------------------
		function getAJAX( url, headers, callback ){
			
			var ajax = new XMLHttpRequest();
			ajax.open('GET', url, true);
			ajax.setRequestHeader('Cache-Control', 'no-cache');
			ajax.setRequestHeader('X-FVD-Extra', 'yes');
			
			if (headers) {
				for (var key in headers) {
					ajax.setRequestHeader(key, headers[key]);
				}
			}	
			
			ajax.onload = function(){
						var content = this.responseText;
						callback( content );
			}
			
			ajax.onerror = function(){
				callback( null );
			}
			
			ajax.send( null );
		
		}
		
		// ====================================================================	
		this.getMedia = function( media ){

			var other_media = [];
			var sniffer_media = [];
			var stream_media = [];
			
			media.forEach(function( item ){
										if ( item.source == "OdnoKlassniki" ) stream_media.push( item );
										else if ( item.source == "Sniffer" )  sniffer_media.push( item );
										else  other_media.push( item );
									});
			
			if (stream_media.length > 0) {
				other_media.forEach(function( item ){	 stream_media.push( item )  });
				return stream_media;
			}	
			else {
				other_media.forEach(function( item ){	 sniffer_media.push( item )  });
				return sniffer_media;
			}	

		}

	};
	
	GetThemAll.Media.OdnoKlassniki = new OdnoKlassniki();
	
})( );

