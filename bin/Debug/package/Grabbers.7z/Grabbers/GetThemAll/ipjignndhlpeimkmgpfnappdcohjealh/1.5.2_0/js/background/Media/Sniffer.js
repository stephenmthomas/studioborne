(function(){

    var MediaSniffer = function(){
		
		const DEBUG = true;
    
        const VIDEO_EXTENSIONS = ["flv", "ram", "mpg", "mpeg", "avi", "rm", "wmv", "mov", "asf", "rbs", "movie", "divx", "mp4", "ogg", "mpeg4", "m4v", "webm"];
        
        const AUDIO_EXTENSIONS = ["mp3",
								  "m4a"
								 ];
        
        const GAME_EXTENSION = ["swf"];
        
        const CONTENT_TYPE_RE = /^(video)/i;
        
        const IGNORE_EXTENSIONS = ["jpg", "jpeg", "gif", "png", "bmp", "tiff", "js", "css", "woff", "woff2"];
        
        const TRIGGER_VIDEO_SIZE = 1048576;
        const MIN_FILESIZE_TO_CHECK = 100 * 1024;
		
		const VIDEO2EXT = {		
			'mpeg' : 'mp4',
			'm4v': 'mp4',
			'mp4': 'mp4',
			'3gpp' : '3gp',
			'flv' : 'flv',
			'x-flv' : 'flv',
			'quicktime' : 'mov',
			'msvideo' : 'avi',
			'ms-wmv' : 'wmv',
			'ms-asf' : 'asf',
			'web' : 'webm',
			'webm' : 'webm'
		};
		
		const AUDIO2EXT = {		
			'realaudio' : 'ra',
			'pn-realaudio' : 'rm',
			'midi' : 'mid',
			'mpeg' : 'mp3',
			'mpeg3' : 'mp3',
			'wav' : 'wav',
			'aiff' : 'aif',
			'webm' : 'webm'
		};

		const IGNORE_SIGNS = [
			"soloset.net",
			"solosing.com",
			"static.doubleclick.net",
		];
		
		const TRANSLATE_EXT = {
			"m4v" : "mp4"
		};

		const IGNORE_ROOT_URL = [
			'ustream.tv\/([^.]*)',
			'twitch.tv\/([^.]*)',
			'periscope.tv\/([^.]*)',
			'break.com\/video\/([^.]*)',
			'http:\/\/(www\.)?dailymotion(\.co)?\.([^\.\/]+)\/',
			'www\.facebook\.com\/(.*)',
			'metacafe\.com\/watch\/(.*)',
			"hulu.com",
			"cnn.com",
			"cbsnews.com",
			"ok\.ru",
			"www\.youtube\.com",    
			"gaming\.youtube\.com",    
			"vimeo\.com",  
			
			// звуковые сайты - игнорируем
			"www.vevo.com",
			"www.pandora.com",
			"www.music.yahoo.com",
			"www.spotify.com",
			"www.tunein.com",
			"www.last.fm",
			"www.iheart.com",
			"www.allmusic.com",
			"www.radio.com",
			"soundcloud.com"
		];
		
		const EXT_PATTERN = new RegExp("\\.([a-z0-9]{1,5})(?:\\?|#|$)","i");
		const NAME_PATTERN = new RegExp("/([^/]+?)(?:\\.([a-z0-9]{1,5}))?(?:\\?|#|$)","i");

		const IMAGE_TYPE_PATTERN = new RegExp("^image/(?:x-)?([^; ]+)");
		
        var self = this;
        
        var mediaDetectCallbacks = [];

		
		// -------------------------------------------------------------------
		function ListenResponse( data ){
			
			if( getHeaderValue("x-fvd-extra", data) )      return;
			
            data.contentType = getHeaderValue("content-type", data);
			var contentTypeImage = IMAGE_TYPE_PATTERN.exec(data.contentType);
			
			data.size = parseInt(getHeaderValue("content-length", data));
			if (data.size == 0) {
				//if (DEBUG)  console.log('sniffer: length == 0   - ignored\n');   
				return false;
			}  
			
			var fileName = null;
			var ext = null;
			var ff = GetThemAll.Utils.extractPath( data.url );
			if (ff) {
				if (!ext) ext = ff.ext;
				fileName = ff.name;
			}	
			if( !isAllowedExt( ext ) )	ext = null;

			if (!fileName) {
				fileName = self.getFileName( data );
			}	

			if (!ext) {
				ext = getExtByContentType( data.contentType );
			}
			
 			if( !ext ) {
				ext = GetThemAll.Utils.extractExtension( data.url );
			} 
			
			data.ext = ext;
			data.tabUrl = data.tab.url;
			data.tabTitle = data.tab.title;
			data.fileName = fileName;
			
			data.type = 'video';
			if ( data.contentType && data.contentType.indexOf('audio') != -1)  data.type = 'audio';
			
			data.contentRange = getHeaderValue("content-range", data);
			data.contentDisp = getHeaderValue("content-disposition", data);
			
			var check = GetThemAll.Media.checkMedia( data );
			
			if ( check == -9 ) {
				if( GetThemAll.Storage.hasDataForTab( data.tabId ) ) {
					GetThemAll.Storage.removeTabData( data.tabId );
				}
			}	

			if (contentTypeImage) {
				//if (DEBUG)  console.log('sniffer: contentType ', data.contentType, ' - ignored\n');   
				return false;
			}
            if (ext && IGNORE_EXTENSIONS.indexOf(ext) != -1) {
            	//if (DEBUG)  console.log( extension, "is ignored" );
                return false;
            }

			if (check >= 1)  {
				
				data.frame = null;
				chrome.webNavigation.getAllFrames({
					tabId: data.tabId,
				},function(frames) {
					frames.forEach(function(frame) {
						if(frame.frameId==data.frameId) 	data.frame = frame;
					});
					if(data.frame) {
						setTimeout( function() {
							WorkerForContent();
						}, 300);	
					}
				});
			
			}
			
			// ---------
			function WorkerForContent() {

				//console.log('WorkerForContent: ', data);

				chrome.tabs.executeScript(data.tab.id,{
					file: "/js/contentScripts/contentSniffer.js",
				},function() {
					chrome.tabs.sendRequest(data.tab.id, {	type: "get-title"	}, function(message) {
								data.thumbnail = message && message.thumbnail ? message.thumbnail : null;
								GetThemAll.Media.detectMedia( data );
					});
					
				});
			
			}
		}
		
		// -------------------------------------------------------------------
		this.checkMedia = function( data ){

            if (data.contentType) {
                var tmp = data.contentType.split("/");
                if (CONTENT_TYPE_RE.test(data.contentType)) {
                    return 1;
                }
            }

			var x = GetThemAll.Prefs.get( "gta.trigger_video_more" );
			var min_filesize = MIN_FILESIZE_TO_CHECK;
			if ( x == 'video_100kb')  min_filesize = 102400;
			else if (x == 'video_1mb') min_filesize = 1048576;
			if ( data.size < min_filesize )  return -1;
			
			if( isAllowedExt( data.ext ) )	return 1;
			
			if( data.contentDisp ){
				var disposExt = GetThemAll.Utils.extractExtension( data.contentDisp );
				if( isAllowedExt( disposExt ) ) 	return 1;
			}
			
			if( data.size >= TRIGGER_VIDEO_SIZE )	return 1;
			
			return 0;	// не определено
		}

		// -------------------------------------------------------------------
		this.detectMedia = function( data ){
			
			if (self.checkMedia(data) != 1 ) return 0;

		    // check url is in ignore list
		    var ignore = false;
		    if (data.tabUrl) {
		        IGNORE_ROOT_URL.forEach(function( sign ){
		            if( data.tabUrl.indexOf( sign ) != -1 ){
		                ignore = true;
		                return false;
		            }
		        });
		    }    
		    if( ignore )            return false;

			// игнорируемый список - сейчас будет  тип NOT
			var metod = 'download';
			for( var i = 0; i != IGNORE_SIGNS.length; i++ )		{
				var sign = IGNORE_SIGNS[i];
				if( data.url.indexOf(sign) != -1 ) {
					metod = 'not';
					break;
				}	
			}
			
			var ext = data.ext;
			var displayName = data.tabTitle ? data.tabTitle : self.getFileName( data );
			var downloadName = displayName;
			var displayLabel = '<span>[</span><b>'+GetThemAll.Utils.upperFirst( ext )+'</b><span>] </span>';
			var fileName = data.fileName;

			if (!ext) {	
				ext = GetThemAll.Utils.extractExtension( data.disposName );
			}	
			
			if(TRANSLATE_EXT[ext])	{
				ext = TRANSLATE_EXT[ext];
			}
			
			var size = data.size;
			
			var orderField = 0;
			orderField = new Date().getTime()

			displayName = displayName.replace(/&quot;/g,''); 
			
			var findThumbnail = metod == 'not' ? false : isAllowedExt( ext );
			if (AUDIO_EXTENSIONS.indexOf(ext) != -1 || data.type == 'audio') {
				findThumbnail = false;
				if (!data.thumbnail) data.thumbnail = '/images/thumbnail/audio.png';				 
			}	

			if( data.tabUrl.indexOf( 'vk.com' ) != -1 ){
				if (AUDIO_EXTENSIONS.indexOf(ext) == -1) return false;
				data.thumbnail = null;
				findThumbnail = false;
			} 

			GetThemAll.Storage.add( {
					url: 		data.url,
					tabId: 		data.tabId,
					tabUrl: 	data.tabUrl,
					frameId: 	data.frameId,
					
					thumbnail: 	data.thumbnail,
					
					ext: 		ext,
					title: 		displayName,
					format: "",
					
					downloadName: 	downloadName ? downloadName : "media",
					displayName: 	displayName,
					displayLabel: 	displayLabel,
					filename: 		fileName ? fileName : data.url,
					
					priority: 	10,
					vubor:  	0,
					size: 		size,
					type: 		"media",
					metod: 		metod,
					source: 	"Sniffer",
					groupId: 	0,
					dwnl:		1,
					orderField: orderField
				},{
                    "findThumbnail": findThumbnail
                }			
			);
		
		}
		
        this.isMedia = function(data){

			if( !data.tabId )		return false;

            var contentType = getHeaderValue("content-type", data);
            if (contentType) {
                var tmp = contentType.split("/");
                if (CONTENT_TYPE_RE.test(contentType)) {
                    return true;
                }
                //else if( CONTENT_TYPE_IGNORE_RE.test(contentType) ){
                	//console.log( "Content type ", contentType, " is ignored" );
                	//return true;
                //}
            }
			
            var size = getHeaderValue("content-length", data);
            if (!size)                return false;
            
			var x = GetThemAll.Prefs.get( "gta.trigger_video_more" );
			var min_filesize = MIN_FILESIZE_TO_CHECK;
			if ( x == 'video_100kb')  min_filesize = 102400;
			else if (x == 'video_1mb') min_filesize = 1048576;

			if ( size < min_filesize )             return false;
			
            var extension = GetThemAll.Utils.extractExtension(data.url);
 
            if (extension && IGNORE_EXTENSIONS.indexOf(extension) != -1) {
            	//console.log( extension, "is ignored" );
                return false;
            }

			if( isAllowedExt( extension ) ){
				return true;
			}
			
			var disposName = dispositionName( data );
			
			if( disposName ){
				var disposExt = GetThemAll.Utils.extractExtension( disposName );
				if( isAllowedExt( disposExt ) ){
					return true;
				}
			}
			
			if( size >= TRIGGER_VIDEO_SIZE ){
				return true;
			}
           
            return false;
        }
		
		
		this.prepareMedia = function( media ){

			var ext = null;

			if (media.url.indexOf("#") != -1)  media.url = media.url.substring(0,media.url.indexOf("#"));
			// ни в коем случае не отбрасывать после (?) - приводит к отваливанию множества сайтов
			
			if ( (media.url.indexOf("tumblr.com") != -1) && (media.url.indexOf("#_=_") != -1) ) media.url = media.url.replace("#_=_", "");			//thumblr.com

			if( media.url.toLowerCase().indexOf( "dailymotion.com/video/" ) != -1 ) return null;
			if( media.url.toLowerCase().indexOf( "break.com" ) != -1 )  			return null;
			if( media.url.toLowerCase().indexOf( "edgecastcdn.net" ) != -1 )  		return null;
			
			if( /^https?:\/\/(.*)seg(\d+)-frag(\d+)/.test(media.url.toLowerCase()) )   return null;			
			if( /\/segment\-[0-9]+\.m4s/.test(media.url.toLowerCase()) )		return null;
			if( /^https?:\/\/(.*)\.ts/.test(media.url.toLowerCase()) )  return null;


			// игнорируемый список - сейчас будет  тип NOT
			var metod = 'download';
			if( GetThemAll.noYoutube )		{
				for( var i = 0; i != NO_YOUTUBE_SIGNS.length; i++ )		{
					var sign = NO_YOUTUBE_SIGNS[i];
					if( media.url.indexOf(sign) != -1 ) {
						metod = 'not';
						break;
					}	
				}
			}

			
			var disposName = dispositionName( media );
			
			if( disposName ) {
				ext = GetThemAll.Utils.extractExtension( disposName );
			}
			
			var fileName = null;
			var ff = GetThemAll.Utils.extractPath( media.url );
			if (ff) {
				if (!ext) ext = ff.ext;
				fileName = ff.name;
			}	
			else {
				fileName = self.getFileName( media );
				ext = getExtByContentType( getHeaderValue( "content-type", media ) );
			}
 			if( !ext ) {
				ext = GetThemAll.Utils.extractExtension( media.url );
			} 
			
			ext = ext.toLowerCase();
			if(TRANSLATE_EXT[ext])	{
				ext = TRANSLATE_EXT[ext];
			}
			
			var size = getHeaderValue( "Content-Length", media );
			
			if( media.tab.title ) {
				var downloadName = media.tab.title;					
				//if( ext )	downloadName += "." + ext;
			}
			else {
				var downloadName = self.getFileName( media );						
			}
			var displayName = downloadName;
			
			var orderField = 0;
			orderField = new Date().getTime()

			var title = fileName ? fileName : media.url;
			var frmt = "no name";
			if (title) {
				frmt = title;
				if ( frmt.length > 10) frmt = frmt.substr(0,10)+"...";
			}
	
			var result = {				
				url: media.url,
				tabId: media.tabId,
				tabUrl: media.tab.url,
				frameId: media.frameId,
				ext: ext,
				
				title: title,
				format: "",
				
				downloadName: downloadName ? downloadName : "media",
				displayName: displayName,
				filename: fileName ? fileName : media.url,
				priority: 10,
				vubor:  0,
				size: size,
				type: "video",
				metod: metod,
				source: "Sniffer",
				groupId: 0,
				dwnl:	1,
				orderField: orderField
			};
			
console.log(result);			
			
			return result;
			
		}
		
		// -------------------------------------------------------------------
		this.getFileName = function( data ){
			// check disposition name
			
			var dn = dispositionName( data );
			if( dn ){
				return dn;
			}
			
			var url = data.url;
			var tmp = url.split( "?" );
			url = tmp[0];
			tmp = url.split( "/" );
			tmp = tmp[ tmp.length - 1 ];
			
			if( tmp.indexOf( "." ) != -1 ){
				var replaceExt = getExtByContentType( getHeaderValue( "content-type", data ) );
				if( replaceExt ){
					tmp = tmp.split( "." );
					tmp.pop();
					tmp.push( replaceExt );
					tmp = tmp.join(".");
				}
				
				try{
					return decodeURIComponent(tmp);					
				}
				catch( ex ){
					if( window.unescape ){
						return unescape(tmp);										
					}
					else{
						return tmp;
					}
				}

			}
			
			return  null;		
		}; 
		
		// -------------------------------------------------------------------
		function getExtByContentType( contentType ){
			if( !contentType ){
				return null;
			}
			var tmp = contentType.split("/");
			if( tmp.length == 2 ){
				switch( tmp[0] ){
					case "audio":
						if( AUDIO2EXT[tmp[1]] ){
							return AUDIO2EXT[tmp[1]];
						}
					break;
					case "video":
						if( VIDEO2EXT[tmp[1]] ){
							return VIDEO2EXT[tmp[1]];
						}						
					break;					
				}
			}			
			
			return null;
		}
		
		// -------------------------------------------------------------------
		function getHeadersAll( data ){
			var result = [];
            for (var i = 0; i != data.responseHeaders.length; i++) {
            	result.push( data.responseHeaders[i].name + ": " + data.responseHeaders[i].value );
            }
			return result;
		}
		
		// -------------------------------------------------------------------
        function getHeaderValue(name, data){
			if (!data.responseHeaders) return null;
            name = name.toLowerCase();
            for (var i = 0; i != data.responseHeaders.length; i++) {
                if (data.responseHeaders[i].name.toLowerCase() == name) {
                    return data.responseHeaders[i].value;
                }
            }
            return null;
        }
        
		// -------------------------------------------------------------------
        function dispositionName(data){
            try {
                var cd = getHeaderValue('Content-Disposition', data);
                var at = cd.match(/^(inline|attachment);/i);
                
                if ((at != null) && (at[1].toLowerCase() == 'attachment')) {
                    cd = cd.substr(at[0].length);
                    if (cd.charAt(cd.length - 1) != ';')     cd += ';';
                    
                    var fnm = cd.match(/filename="(.*?)"\s*?(?:;|$)/i);
                    if (fnm == null)   fnm = cd.match(/filename=(.*?)\s*?(?:;|$)/i);
                    if (fnm != null)   return fnm[1];
                }
            } 
            catch (e) {        }
			
            return null;
        }
		
		// -------------------------------------------------------------------
		function isAllowedExt( extension ){
            if (VIDEO_EXTENSIONS.indexOf(extension) != -1) {
                return true;
            }
            
            if (AUDIO_EXTENSIONS.indexOf(extension) != -1) {
                return true;
            }
            
            if (GAME_EXTENSION.indexOf(extension) != -1) {
                return true;
            }
			
			return false;
		}
        
		this.onMediaDetect = {
			addListener: function( callback ){
				if( mediaDetectCallbacks.indexOf( callback ) == -1 )	mediaDetectCallbacks.push( callback );   
			},
			removeListener: function(  ){
				mediaDetectCallbacks.length=0;   
			}
		};
		
		this.isEqualItems = function( item1, item2 ){
			
			if (item1.url == item2.url) return 1;

			return 0;
			
		};
		
		// ====================================================================	
		this.getMedia = function( media ){

			return media;	
		}

		

		// ====================================================================	
        chrome.webRequest.onResponseStarted.addListener(function(data){
			
			if( !data || data.tabId < 0 )		return false;
		
			chrome.tabs.get( data.tabId, function( tab ){
				
				if (chrome.runtime.lastError) {
					//console.log(chrome.runtime.lastError.message);
				} 
				else if ( !tab ) {
					console.log( data );
				}	
				else {
					data.tab = tab;
					if (data.method == 'GET')	ListenResponse(data);
				}	
			});
			
        }, {
            urls: ["<all_urls>"],
        }, ["responseHeaders"]);
        
		chrome.webRequest.onBeforeRequest.addListener( function(data) {
			
			if (data.method == "POST") {
				if( !data || data.tabId < 0 )		return false;
				
				chrome.tabs.get( data.tabId, function( tab ){
			
					if (chrome.runtime.lastError) {
						//console.log(chrome.runtime.lastError.message);
					} 
					else if ( !tab ) {
						console.log( data );
					}	
					else {
						data.tab = tab;
						data.responseHeaders = null;
						if (data.method == 'POST')	ListenResponse(data);
					}
				});	
			}
 		},
		  {urls: ["https://vk.com/*"]},
		  ["requestBody"]
		); 
		// ====================================================================	
    };
    
    GetThemAll.Media.Sniffer = new MediaSniffer();

    
})();
