var GetThemAll = {
	noYoutube: false,
	noLink:    false,
	noImage:   false,
	noFile:    false,
	noGame:    false,
	noWelcome: false
	};