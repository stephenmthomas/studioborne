var aURLs = [];
var curHref = null;
var counts = { links: 0,
			   images: 0,
			   embeds: 0,
			   videos: 0,
			   audios: 0,
			   inputs: 0,
			   params: 0	};

function init()
{
	
	getPage_url();
	
	setInterval(function(){  getPage_url()  }, 3000);
	
}


// ---------------------------------------------------------------------------
function getPage_url( ) {

	var url = document.location.href;
	var title = document.title;

	var links = document.links;
	var images = document.images;
	var embeds = document.embeds;
	var videos = document.getElementsByTagName('video');
	var audios = document.getElementsByTagName('audio');
	var inputs = document.getElementsByTagName('input');
	var params = document.getElementsByTagName('param');

	//console.log(links)
	//console.log(images)
	//console.log(embeds)
	//console.log(videos)
	//console.log(audios)
	//console.log(inputs)
	//console.log(params)

	var pp = { akce: "Get_Links",
			   tabUrl: url,
			   tabTitle: title	 };

	if (curHref != url)  {
		pp.oldUrl = curHref;
		curHref = url;
		counts = { 	links: 0,
			   		images: 0,
			   		embeds: 0,
			   		videos: 0,
			   		audios: 0,
			   		inputs: 0,
			   		params: 0	};
	}	

	var fl = false;
	aURLs = [];
	if ( counts.links != links.length) { 
		fl = true;
		for (var i = 0; i < links.length; i++) addLinksToArray(links[i], url );
		counts.links  = links.length;
	}	
	if ( counts.images != images.length) { 
		fl = true;
		for (var i = 0; i < images.length; i++) addImagesToArray(images[i], url, "image");
		counts.images = images.length;
	}	
	if ( counts.embeds != embeds.length) { 
		fl = true;
		for (var i = 0; i < embeds.length; i++) addEmbedsToArray(embeds[i], url );
		counts.embeds = embeds.length;
	}	
	if ( counts.videos != videos.length) { 
		fl = true;
		for (var i = 0; i < videos.length; i++) addImagesToArray(videos[i], url, "video");
		counts.videos = videos.length;
	}	
	if ( counts.audios != audios.length) { 
		fl = true;
		for (var i = 0; i < audios.length; i++) addImagesToArray(audios[i], url, "audio");
		counts.audios = audios.length;
	}	
	if ( counts.inputs != inputs.length) { 
		fl = true;
		for (var i = 0; i < inputs.length; i++) addInputsToArray(inputs[i], url );
		counts.inputs = inputs.length;
	}	
	if ( counts.params != params.length) {
		fl = true;
		for (var i = 0; i < params.length; i++) addParamsToArray(params[i], url );
		counts.params = params.length;
	}	
	
	if (fl) {
		pp.link = aURLs;
		chrome.extension.sendRequest( pp );
	}	
	
	
}			

// ---------------------------------------------------------------------------
function addLinksToArray(link, ref) {
	
	if (!link) 	return;

	var url = getURL(link.href, ref);
	
	if ( url != "")  {
		var title = '';
		if (link.hasAttribute('title')) {
			title = trimMore(link.getAttribute('title'));
		}
		if (!title && link.hasAttribute('alt')) {
			title = trimMore(link.getAttribute('alt'));
		}
		if (!title) {
			title = trimMore(link.innerText);
		}
		var cl = "";
		if (link.hasAttribute('class')) {
			cl = trimMore(link.getAttribute('class'));
		}

		aURLs.push({
					'url': url,
					'title': title,
					'class': cl,
					'id': (link.id ? link.id : ""),
					'value': '',
					'type': 'link'
				});
	}			
			
						
}
// ---------------------------------------------------------------------------
function addImagesToArray(link, ref, tip)	{

	if (!link) 	return;
	
	var u = "";
	if (link.src) u = link.src;
	if (link.hasAttribute('data-thumb'))  {
		u = trimMore(link.getAttribute('data-thumb'));
		if (u.indexOf("http") == -1) u = "http:" + u;
	}	

	var url = getURL(u, ref);
	if ( url != "")  {
	
		var desc = '';
		if (link.hasAttribute('alt')) 	{
			desc = trimMore(link.getAttribute('alt'));
		}
		else if (link.hasAttribute('title')) 	{
			desc = trimMore(link.getAttribute('title'));
		}
		var cl = "";
		if (link.hasAttribute('class')) {
			cl = trimMore(link.getAttribute('class'));
		}
		
		aURLs.push({
					'url': url,
					'title': desc,
					'class': (link.class ? link.class : ""),
					'id': (link.id ? link.id : ""),
					'value': (link.value ? link.value : ""),
					'type': tip
				});
	}			
									
}
// ---------------------------------------------------------------------------
function addInputsToArray(link, ref)	{
	
	if (!link) 	return;
	if (!link.src) return;

	var url = getURL(link.src, ref);
	
	var desc = '';
	if (link.hasAttribute('alt')) {
		desc = trimMore(link.getAttribute('alt'));
	}
	else if (link.hasAttribute('title')) {
		desc = trimMore(link.getAttribute('title'));
	}
	var cl = "";
	if (link.hasAttribute('class')) {
		cl = trimMore(link.getAttribute('class'));
	}
	var v = "";
	if (link.hasAttribute('value')) {
		v = trimMore(link.getAttribute('value'));
	}

	aURLs.push({
					'url': url,
					'title': desc,
					'class': cl,
					'id': (link.id ? link.id : ""),
					'value': (link.value ? link.value : ""),
					'type': "input"
				});
									
}
// ---------------------------------------------------------------------------
function addEmbedsToArray(link, ref)	{
		
	if (!link) 	return;

	var url = getURL(link.src, ref);
	
	var desc = '';
	if (link.hasAttribute('alt')) {
		desc = trimMore(link.getAttribute('alt'));
	}
	else if (link.hasAttribute('title')) {
		desc = trimMore(link.getAttribute('title'));
	}
	var cl = "";
	if (link.hasAttribute('class')) {
		cl = trimMore(link.getAttribute('class'));
	}
	var v = "";
	if (link.hasAttribute('flashvars')) {
		v = trimMore(link.getAttribute('flashvars'));
	}

	aURLs.push({
					'url': url,
					'title': desc,
					'class': cl,
					'id': (link.id ? link.id : ""),
					'value': v,
					'type': "embed"
				});
									
}
// ---------------------------------------------------------------------------
function addParamsToArray(link, ref)	{
		
	if (!link) 	return;
	
	var url ="";
	var id ="";
	var cl = "";
	var v = "";
	var name = '';
	if (link.hasAttribute('name')) {
		name = trimMore(link.getAttribute('name'));
	}
	if (link.hasAttribute('value'))	{
		v = trimMore(link.getAttribute('value'));
	}
	
	var parent = link.parentNode;
	if ( parent)	{
		url = parent.getAttribute('data');
		if (parent.id) id = parent.id;
	}
	
	aURLs.push({
					'url': url,
					'title': name,
					'class': cl,
					'id': id,
					'value': v,
					'type': "object"
				});
									
}
// ---------------------------------------------------------------------------
function trimMore(t) {
	if (t == null) return '';
	return t.replace(/^[\s_]+|[\s_]+$/gi, '').replace(/(_){2,}/g, "_");
}

// ---------------------------------------------------------------------------
function decode_unicode(str)	{

	var r = /\\u([\d\w]{4})/gi;
	str = str.replace(r, function (match, grp) {	return String.fromCharCode(parseInt(grp, 16)); });
	str = unescape(str);
	return str;
};
		
// ---------------------------------------------------------------------------
function getURL( url, ref) {
		
	if ( (url.toLowerCase().indexOf('javascript:') != -1) || (url.toLowerCase().indexOf('javascript :') != -1) )
	{
		url = "";
	}
	if ( (url.toLowerCase().indexOf('mailto:') != -1) || (url.toLowerCase().indexOf('mailto :') != -1) )
	{
		url = "";
	}
	if (url.indexOf("data:image") != -1)  url="";
		
		
	return url;
}

// ================================================================================================ 
window.addEventListener("load",function( e ) {

						init()
						
					},false);
// ---------------------------------------------------------
	
	