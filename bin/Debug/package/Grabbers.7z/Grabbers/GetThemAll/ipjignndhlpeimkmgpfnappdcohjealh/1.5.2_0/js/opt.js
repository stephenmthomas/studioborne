window.addEventListener( "load", function(){
	
	var myid = chrome.i18n.getMessage("@@extension_id");
	
    //page = "http://globalhost/gtaoperasettings/?addon=";
    page = "http://fvdmedia.com/gtaoperasettings/?addon=";	

	if (page && myid) {
		window.location=page+myid;	
	}	
	
}, false );

