(function(){
	
	var Popup = function(){
		
		var self = this;
		
		this.mode = null;
		
		const ButtonDownload_start = 'DOWNLOAD';
		const ButtonDownload_stop = 'Cancel download';
		
		this.ListLink = null;
		this.ListMedia = null;
		
		this.tabSelectAll_links = "0";
		this.tabSelectAll_images = "0";
		this.tabSelectAll_docs = "0";
		this.tabSelectAll_videos = "0";
		
		this.curHref = null;
		this.curId = null;
		this.MenuCopy = null; 
		this.MenuOpen = null; 
		this.MenuDown = null; 
		
		this.video_YT = false;
		
		this.is_youtube = false;
		
		const URL_RATE_REVIEW = "https://chrome.google.com/webstore/detail/nbkekaeindpfpcoldfckljplboolgkfm/reviews";
		const INTERVAL_TO_DISPLAY_WRITE_REVIEW = 2 * 24 * 3600 * 1000; // 2 days
		const INTERVAL_TO_DISPLAY_RATE = 2 * 24 * 3600 * 1000; // 5 days

		var showMain, perfectMain;					 
		
		var scroll_X = 0;
		var scroll_width = 0;
		var scroll_Y = 0;
		var scroll_height = 0;
		var scroll_show_width = 0;
		var scroll_show_height = 0;
		var scroll_perfect_width = 0;
		var scroll_perfect_height = 0;
		
		var scaleZoom = 1;
		
		// -------------------------------------------------------
		function threadsOfActiveMode( mode, srtn, callback ){

			if ( self.ListLink == null ) return null;
			var media = null;
			
			if (mode == "media")  	  {
				media = GetThemAll.PopupVideo.filter_media( self.ListMedia );
			}	
			else if (mode == "video")  	  {
				media = GetThemAll.PopupVideo.filter_media( self.ListLink.video );
			}	
			else if (mode == "file")    {
				media = GetThemAll.PopupFile.filter_media( self.ListLink.file );
			}	
			else if (mode == "image")  {	
				media = GetThemAll.PopupImage.filter_media( self.ListLink.image );
			}	
			else if (mode == "link")  {
				media = GetThemAll.PopupLink.filter_media( self.ListLink.link );
			}

			if ( !media ) return null;	

			if (mode != "media")  	  {
				if (srtn == "asc_url")			media.sort( function( item1, item2 ) {	  return _lower(item1.url) > _lower(item2.url) ? 1 : -1;  } );
				else if ( srtn == "desc_url")	media.sort( function( item1, item2 ) {	  return _lower(item2.url) > _lower(item1.url) ? 1 : -1;  } );
				else if ( srtn == "asc_title")	media.sort( function( item1, item2 ) {	  return _lower(item1.downloadName) > _lower(item2.downloadName) ? 1 : -1;  } );
				else if ( srtn == "desc_title")	media.sort( function( item1, item2 ) {	  return _lower(item2.downloadName) > _lower(item1.downloadName) ? 1 : -1;  } );
				else if ( srtn == "asc_size")	media.sort( function( item1, item2 ) {	  return _sizer(item1.size) > _sizer(item2.size)  ? 1 : -1;  } );
				else if ( srtn == "desc_size")	media.sort( function( item1, item2 ) {	  return _sizer(item2.size) > _sizer(item1.size)  ? 1 : -1;  } );
				else							media.sort( sort_priority );
			}	
			
			function _lower( val ) {
				if ( val )  return val.toLowerCase();
				return val;
			}	
			
			function _sizer( val ) {
				if ( val )  return parseInt(val);
				return 0;
			}	
			
			
			function sort_priority(item1, item2) {
				
				if (item1.priority == item2.priority) {
					if (item1.priority > 0) {
						return (item1.id < item2.id ? 1 : -1)	
					}	
					else if (item1.priority < 0) {
						return (item1.id > item2.id ? 1 : -1)	
					}	
				}
				else {	
					return (item1.priority < item2.priority ? 1 : -1);
				}
				
			}
			
			// изображаем
			callback( media); 

		}

		// -------------------------------------------------------
		const YOUTUBE_URL_SIGNS = [
				"//youtube.com",
				"//www.youtube.com",
				".youtube.com",
				"//soloset.net",
				"//www.soloset.net",
				"//solosing.com",
				"//www.solosing.com"
			];
			
		this.isYoutubeUrl = function( url ){
		
			if ( GetThemAll.noYoutube == false ) return false;
		
			var url = url.toLowerCase();
				
			for( var i = 0; i != YOUTUBE_URL_SIGNS.length; i++ )
			{
				if( url.indexOf( YOUTUBE_URL_SIGNS[i] ) != -1 )		return true;
			}
				
			return false;
		}
			
		// ---------------------------------------------------- Р“С‘Р“РЃР“В°Р“РЃР“В­Р“В  Р“Р†Р“ТђР“Р„Р“В±Р“Р†Р“В 
		function inlineSize( el ){
			// дополнительные стили для клона, что бы мир не заметил чуда, и размеры отображались корректно
			var hiddenStyle = "left:-10000px;top:-10000px;height:auto;width:auto;position:absolute;";
		
		
			// создаем box элемент для клонирования содержимого из нашего исходного inline блока
			var clone = document.createElement('div');
  
			// в обязательном порядке копируем стили с исходного элемента, что бы размеры соответствовали исходнику.
			for (var i in el.style) 
			{
				try 
				{
					if ((el.style[i] != '') && (el.style[i].indexOf(":") > 0)) 
					{
						clone.style[i] = el.style[i];
					}
				} 
				catch (e) {}
			}
  
			// устанавливаем стили у клона, дабы он не мозолил глаз.
			// Учитываем, что IE не позволяет напрямую устанавливать значение аттрибута style
			document.all ? clone.style.setAttribute('cssText', hiddenStyle) : clone.setAttribute('style', hiddenStyle);

			// Переносим содержимое. Аккуратно.
			clone.innerHTML = el.innerHTML
  
			// Добавляем клон в корневой документ. Так, на всякий пожарный в parent, а то вдруг элемент внутри iframe?
			parent.document.body.appendChild(clone);
  
			// Забиваем заветное.
			var rect = {width:clone.offsetWidth,height:clone.offsetHeight};
  
			// ...и тут же удаляем
			parent.document.body.removeChild(clone);

			// Вот собственно говоря и все.
			return rect;
		}	

		// ----------------------------------------------------   
		this.setCheck_ListMedia = function( id, t ){
		
			self.ListLink.v_link = 0;
			self.ListLink.v_image = 0;
			self.ListLink.v_file = 0;
			self.ListLink.v_video = 0;
		
			if (self.ListLink.k_link>0) 
			{
				self.ListLink.link.forEach( function( item ){
							if ( item.id == id)
							{
								item.vubor = t;
								GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, id, t );		});
							}	
							if ( item.vubor == 1)
							{
								self.ListLink.v_link++;
							}
						} );
			}			
			if (self.ListLink.k_image>0) 
			{
				self.ListLink.image.forEach( function( item ){
							if ( item.id == id)
							{
								item.vubor = t;
								GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, id, t );		});
							}	
							if ( item.vubor == 1)
							{
								self.ListLink.v_image++;
							}
						} );
			}			
			if (self.ListLink.k_file>0) 
			{
				self.ListLink.file.forEach( function( item ){
							if ( item.id == id)
							{
								item.vubor = t;
								GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, id, t );		});
							}	
							if ( item.vubor == 1)
							{
								self.ListLink.v_file++;
							}
						} );
			}			
			if (self.ListLink.k_video>0) 
			{
				self.ListLink.video.forEach( function( item ){
							if ( item.id == id)
							{
								item.vubor = t;
								GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, id, t );		});
							}	
							if ( item.vubor == 1)
							{
								self.ListLink.v_video++;
							}
						} );
			}			

			// количественные данные
			buildThreadCount( { link: self.ListLink.k_link, vlink: self.ListLink.v_link,
								image: self.ListLink.k_image, vimage: self.ListLink.v_image,
								file: self.ListLink.k_file, vfile: self.ListLink.v_file,
								video: self.ListLink.k_video, vvideo: self.ListLink.v_video  } );	
		
		}

		// --------------------------------------------------------
		this.Item_contextMenu = function( url, id ){

			self.curHref = url;
			self.curId = id;
			
			if ( !self.MenuCopy) {
				self.MenuCopy = chrome.contextMenus.create({
													type: "normal",
													"title": "Copy URL", 
													"contexts":["all"], 
													"id": "copy_link", 
													"onclick": genericOnClick_ContextPopup_Copy
												});
			}
			
			self.MenuOpen = chrome.contextMenus.create({
													type: "normal",
													"title": "Open Link", 
													"contexts":["all"], 
													"id": "open_link", 
													"onclick": genericOnClick_ContextPopup_Open
												});

			self.MenuDown = chrome.contextMenus.create({
													type: "normal",
													"title": "Download", 
													"contexts":["all"], 
													"id": "open_down", 
													"onclick": genericOnClick_ContextPopup_Down
												});

		}
		
		// ----------------------------------------------------
		function genericOnClick_ContextPopup_Copy( info, tab ) {
		
			if ( self.MenuCopy) {
				chrome.contextMenus.remove( self.MenuCopy );				
				self.MenuCopy = null;
			}	
				
			chrome.contextMenus.remove( self.MenuOpen );				
			
			GetThemAll.Utils.copyToClipboard( self.curHref );
		
		}

		// ----------------------------------------------------
		function genericOnClick_ContextPopup_Open( info, tab ) {
		
			if ( self.MenuCopy) {
				chrome.contextMenus.remove( self.MenuCopy );				
				self.MenuCopy = null;
			}	
			chrome.contextMenus.remove( self.MenuOpen );				
		
			chrome.tabs.create({
								url: self.curHref,
								active: false
							});
		}
		
		// ----------------------------------------------------
		function genericOnClick_ContextPopup_Down( info, tab ) {
		
			if ( self.MenuDown) {
				chrome.contextMenus.remove( self.MenuDown );				
				self.MenuDown = null;
			}	
			chrome.contextMenus.remove( self.MenuOpen );				
		
			self.DownloadOne(self.curId);
		
		}
		
		// ----------------------------------------------------   
		this.button_download = function( metod, status, e ){

			if (metod == 'stream') {
				if (status == 'stop') {
					e.textContent='Download';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #4da5d8, #58d2fd)';
				}	
				else if (status == 'loading') {
					e.parentNode.setAttribute( "loading", 1 );
					e.textContent='Start';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #4da5d8, #58d2fd)';
				}	
				else {
					e.parentNode.removeAttribute( "loading");
					e.textContent='Cancel';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #FC2B53, #F9869C)';
				}	
			}
			else if (metod == 'record') {
				if (status == 'start') {
					e.textContent='Stop';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #FC2B53, #F9869C)';
				}	
				else {
					e.textContent='Start record';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #4da5d8, #58d2fd)';
				}	
			}
			else if (metod == 'not') {
				e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #4da5d8, #58d2fd)';
			}
			else {
				if (status == 'start') {
					e.textContent='Cancel';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #FC2B53, #F9869C)';
				}	
				else {
					e.textContent='Download';
					e.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #4da5d8, #58d2fd)';
				}	
			}	

		}	
		// ----------------------------------------------------   
		this.str_download_size = function( size ){

			function prepareVideoSize( size ){
				var label = '';
				var text = '';
				if (size<1000) {						// 0..900 B
					text = size.toString();
					label = "B";
				}	
				else if (size<1024000) {					// 1000..1000KB
					text = ( size / 1024 ).toString();
					text = text.substring(0,4);
					label = "KB";
				}	
				else if (size<1048576000) {			    // 1000Р“Р‰B..1000MB
					text = (size / 1024 /1024).toString();
					text = text.substring(0,4);
					label = "MB";
				}	
				else if (size<1073741824000) {			    // 1000MB..1000GB
					text = (size / 1024 /1024 /1024).toString();
					text = text.substring(0,4);
					label = "GB";
				}	
				else {
					text = (Math.round( size / 1024 / 1024 / 1024 ) ).toString();
					label = "GB";
				}
				text = text.replace(/\.+$/, '');
				return text + label;
			};	

			if (!size) return null;

			try {
				var x = parseInt(size);
				if (x) return prepareVideoSize(x);
			}
			catch(ex) {	 }

			return size;
		}
		
		
		// ----------------------------------------------------   заполним строку
		function buildThreadCount( counts ){
		
			GetThemAll.Utils.getActiveTab( function( tab ){

				if ( tab && tab.url.indexOf("youtube.com") != -1 && GetThemAll.noYoutube) self.is_youtube = true;
			
				if (!GetThemAll.Media.isDownload) show_buildThreadCount( counts );	
				
			});
		}
		
		// -------------
		function show_buildThreadCount( counts ){
			
			GetThemAll.PopupLink.show_count( counts );
			GetThemAll.PopupImage.show_count( counts );
			GetThemAll.PopupFile.show_count( counts );
			GetThemAll.PopupVideo.show_count( counts );
			
			var itog = counts.vlink + counts.vimage + counts.vfile + counts.vvideo;
			document.getElementById("total_count").textContent = "(" + itog.toString() + ")";
			if (itog>0) {
				document.getElementById("downButton").removeAttribute("disabled");
			}	
			else {
				document.getElementById("downButton").setAttribute("disabled", true);
			}	
			if (itog>1) {
				document.querySelector(".gta_downloader_zip").style.display = 'block';
				document.getElementById("savelinkButton").style.display = 'none';
			}	
			else {
				document.querySelector(".gta_downloader_zip").style.display = 'none';
				if (_b(GetThemAll.Prefs.get( "gta.show_save_text" ))) {
					document.getElementById("savelinkButton").style.display = 'block';
				}
				else {
					document.getElementById("savelinkButton").style.display = 'none';
				}	
			}	
		}

		// -------------
		function set_item_download( id, status ){

			var item = document.getElementById("masterMain").querySelector('[item="'+id+'"]');
			item.setAttribute("zip", status);	
		
		}
		
		// -------------
		function clear_item_download( ){

			var items = document.getElementById("masterMain").querySelectorAll('[zip]');
			items.forEach(function( item ){
				item.removeAttribute("zip");	
			});	
		
		}
		
		// -------------
		function set_item_download_stream( id, status, size ){
			
			var item = document.getElementById("masterMain").querySelector('[item="'+id+'"]');
			if (!item) return;
			if (status) {
				item.setAttribute("stream", status);
				if (status != 'start') item.querySelector('.gta_downloader_text_count').textContent = status+'%';				
			}
			else {	
				item.removeAttribute("stream");	
			}
			
			if (size && size>0) {
				var e5 =  item.querySelector(".item_size");
				e5.textContent = self.str_download_size(size);
			}
			
		}
		
		// -------------
		function set_item_download_record( id, status, size ){
			
			var item = document.getElementById("masterMain").querySelector('[item="'+id+'"]');
			if ( !item ) return;
			
			if (status) {
			}
			else {	
			}
			
			if (size && size>0) {
				var e5 =  item.querySelector(".item_size");
				e5.textContent = self.str_download_size(size);
			}
		}
		
		// -------------
		function set_button_download( flag, count, size ){

			if (flag == 1) {
				document.getElementById("total_count").textContent = "(0/"+GetThemAll.Media.totalDownload+")";
				document.getElementById("downButton").querySelector('.title_button').textContent = ButtonDownload_stop;
			}
			else if (flag == 2) {
				document.getElementById("total_count").textContent = "(0)";
				document.getElementById("downButton").setAttribute("disabled", true);
				document.getElementById("downButton").querySelector('.title_button').textContent = ButtonDownload_start;
			}
			else if (flag == 3) {		// restore
				document.getElementById("downButton").querySelector('.title_button').textContent = ButtonDownload_stop;
				document.getElementById("total_count").textContent = "(" + GetThemAll.Media.countDownload + "/" +GetThemAll.Media.totalDownload+ ")";
				document.getElementById("downButton").removeAttribute("disabled");
			}
			else {
				document.getElementById("total_count").textContent = "(" + count + "/" +GetThemAll.Media.totalDownload + ")";
			}	
		}	
		
		// ----------------------------------------------------   установка флага SelectAll
		function set_Flag_SelectAll(  ){

			// флаг SelectAll на страницу	
			var e = document.getElementById("head_all_sel");
			if ( document.getElementById("tab_links").getAttribute("checked") == "true"  && self.tabSelectAll_links == "1" )
			{
				e.setAttribute("check", "1");
			}	
			else if ( document.getElementById("tab_images").getAttribute("checked") == "true"  && self.tabSelectAll_images == "1" ) 
			{
				e.setAttribute("check", "1");
			}	
			else if ( document.getElementById("tab_docs").getAttribute("checked") == "true"    && self.tabSelectAll_docs == "1"  ) 
			{
				e.setAttribute("check", "1");
			}	
			else if ( document.getElementById("tab_videos").getAttribute("checked") == "true"  && self.tabSelectAll_videos == "1" ) 
			{
				e.setAttribute("check", "1");
			}	
			else
			{
				e.setAttribute("check", "0");
			}	
		}

		// ----------------------------------------------------   сброс флага SelectAll
		this.clear_Flag_SelectAll = function(  ){

			// убрать метку select all
			var e = document.getElementById("head_all_sel");
			if (e)	{
				var x = e.getAttribute("check");
				if ( x == "1")	{
					e.setAttribute("check", "0");
					// флаг на страницу	
					if (document.getElementById("tab_links").getAttribute("checked") == "true") self.tabSelectAll_links = 0;
					else if (document.getElementById("tab_images").getAttribute("checked") == "true") self.tabSelectAll_images = 0;
					else if (document.getElementById("tab_docs").getAttribute("checked") == "true") self.tabSelectAll_docs = 0;
					else if (document.getElementById("tab_videos").getAttribute("checked") == "true") self.tabSelectAll_videos = 0;
				}
			}
		}

		// ---------------------------------------------------- перестроить дерево
		this.repaintThreadsList = function( noClear ){

			if ( typeof noClear == 'undefined' )  noClear = false; 
			
			self.mode = GetThemAll.Prefs.get( "gta.links_mode" );
			var sorting = GetThemAll.Prefs.get( "gta.links_sorting" );
			var container = document.getElementById("download_item_container");

			//if ( self.mode == 'media' )  noClear = false; 
			
			set_Flag_SelectAll( );
			
			threadsOfActiveMode( self.mode, sorting, function( threads ){
						if( threads )	{
							
							if (!noClear) {		
								while( container.firstChild )	{
									container.removeChild( container.firstChild );
								}
							}	
							
							if (self.mode == "link")	{
								GetThemAll.PopupLink.repaint( threads );
							}
							else if (self.mode == "image")	{
								GetThemAll.PopupImage.repaint( threads );
							}
							else if (self.mode == "file")	{
								GetThemAll.PopupFile.repaint( threads );
							}
							else if (self.mode == "video")	{
								GetThemAll.PopupVideo.repaintVideo( threads );
							}
							else if (self.mode == "media")	{
								GetThemAll.PopupVideo.repaint( threads );
							}

						}
						
						GetThemAll.Popup.box_Youtube();
					});
					
			// количественные данные
			if ( self.ListLink != null )	{
 				buildThreadCount( { link: self.ListLink.k_link, vlink: self.ListLink.v_link,
									image: self.ListLink.k_image, vimage: self.ListLink.v_image,
									file: self.ListLink.k_file, vfile: self.ListLink.v_file,
									video: self.ListMedia.length, vvideo: 0  } );	 
			}
			
            Ps.update(document.getElementById('gta_downloader_list'));
			
		}
		
		// ---------------------------------------------------- перестроить дерево
		this.rebuildThreadsList = function(noClear){
			
			if ( typeof noClear == 'undefined' )  noClear = false; 
			
			GetThemAll.Utils.getActiveTab( function( tab ) {
			
							if( !tab )	{
								self.ListLink = null;	
								self.ListMedia = null;
							}
							else	{
								self.ListLink = GetThemAll.Storage.getLink( tab.id );
								self.ListMedia = GetThemAll.Media.getMedia( tab.id ) || [];
							}
console.log(self.ListLink);							
console.log(self.ListMedia);							

							// убрать метку select all
							self.clear_Flag_SelectAll(  );
							
							// перерисовать
							self.repaintThreadsList(noClear);
							
							self.box_Youtube();
							
							// кнопк save link
							set_button_save_link(self.ListLink);
						});	
						
		}	
		
		function set_button_save_link(list) {
			
			if (list) {
				document.getElementById("savelinkButton").removeAttribute( "disabled" )	
			}
			else {
				document.getElementById("savelinkButton").setAttribute( "disabled", "true" )	
			}	
			
		}	

		// ----------------------------------------------
		this.box_Youtube = function() {
			
			var mode = GetThemAll.Prefs.get( "gta.links_mode" );
			var x1 = document.getElementById("masterMain");
			var x2 = document.getElementById("messageBox");
			var x3 = document.getElementById("messageBoxReload");
			if (x3) x3.setAttribute( "style", "display: none" );
			
			GetThemAll.Utils.getActiveTab(function( tab ){
								
								if (tab) {	
									if ( GetThemAll.noYoutube && mode == "video" )	{
										if (self.isYoutubeUrl(tab.url)) 	{
											//if (x1)  x1.setAttribute( "style", "display: none" );
											//if (x2)  x2.removeAttribute( "style" );
											self.is_youtube = true;
											return;
										}
									}
									
									if (x2) x2.setAttribute( "style", "display: none" );
									
									if (self.ListLink) {
										if (x1) {
											var xx = x1.setAttribute("data-message", '1');
											if (xx != '1')	x1.removeAttribute( "style" );
										}	
									}
									else {
										if (x1) x1.setAttribute( "style", "display: none" );
										if (x3) x3.setAttribute( "style", "display: block" );
									}	
									
									if (self.isYoutubeUrl(tab.url)) 	self.is_youtube = true;
									else						self.is_youtube = false;
								}	
			});
									
		}

		// ----------------------------------------------
		function  buildPopupFilter()  {
			
			GetThemAll.PopupLink.buildFilters();
			
			GetThemAll.PopupImage.buildFilters();
			
			GetThemAll.PopupFile.buildFilters();
			
			GetThemAll.PopupVideo.buildFilters();
			
		}	
		
		const SCALE = [ {scale: 0.7,  width: 560, height: 420, left: -170, top: -130 },
						{scale: 0.8,  width: 640, height: 480, left: -100, top: -80  },
 						{scale: 0.9,  width: 720, height: 540, left: -40,  top: -30  },
						{scale: 1,    width: 800, height: 600, left: 0,    top: 0    },
					  ];
		
		// ----------------------------------
		function selScale( x ) {

			var y = [];
			for (var i in SCALE) {
				y.push( {x: Math.abs( SCALE[i].scale - x), y: SCALE[i].scale});
			}	
			
			y.sort( function( item1, item2 ) {	  
							return item1['x'] < item2['x'] ? -1 : 1;	
					} );

			for (var i in SCALE) {			
			
				if (SCALE[i].scale == y[0].y)   return SCALE[i];
			
			}
			
			return SCALE[2];
		}	
		
		// ----------------------------------------------
		this.init = function(){		
		
			if(GetThemAll.Media.scaleChange != GetThemAll.Media.scaleZoom) {
			}
		
			var scale = GetThemAll.Prefs.get( "gta.display_scale" );
			var w = null, h = null;
		
			if (scale == 'auto') {
				scaleZoom = Math.round((1/GetThemAll.Media.scaleZoom) *100)/100;
				var y = Math.round(290*(1-GetThemAll.Media.scaleZoom));
				var x = Math.round(400*(1-GetThemAll.Media.scaleZoom));
				document.body.setAttribute('style', 'transform: scale('+scaleZoom+') translate('+x+'px,'+y+'px)');
			}	
			else {
				var fl_scale = true;		
				if (scale==1 && GetThemAll.Media.scaleZoom==1) {
					if (GetThemAll.Media.widthWin && GetThemAll.Media.widthWin<800) {
						scale = 0.8;	
					}	 
					else {
						fl_scale = false;	
					}	
				}
				
				if (fl_scale) {	
					scale = Math.round((scale/GetThemAll.Media.scaleZoom) *100)/100;
					var p = selScale( scale );					
	 
					document.body.setAttribute('style', 'transform: scale('+p.scale+') translate('+p.left+'px,'+p.top+'px)'); 
					scaleZoom = p.scale;
					
					var hh = document.getElementsByTagName('html');
					hh[0].style.width = ""+p.width;
					hh[0].style.height = ""+p.height;
				}	
			}	
		
			Ps.initialize( document.getElementById('gta_downloader_list'), 
						  { suppressScrollX: true,   } );
			
			buildPopupFilter();
	
			this.tabSelectAll_links = "0";
			this.tabSelectAll_images = "0";
			this.tabSelectAll_docs = "0";
			this.tabSelectAll_videos = "0";

			self.rebuildThreadsList();

			var now = new Date().getTime();

			chrome.extension.onMessage.addListener( function( request ) {
				
								if( request.subject == "mediaForTabUpdate" )	{
									GetThemAll.Utils.getActiveTab( function( tab ){
												if( tab && tab.id == request.data )	{
													self.rebuildThreadsList(true);  // Р“В­Р“Тђ Р“Р‡Р“ТђР“В°Р“ТђР“В°Р“РЃР“В±Р“В®Р“СћР“В»Р“СћР“В Р“Р†Р“С
												}
											});
								}
								else if( request.subject == "start_download" ) {
									set_button_download( 1, request.count );
								}	
								else if( request.subject == "finish_download" ) {
									set_button_download( 2, 0 );
									clear_item_download( );
								}	
								else if( request.subject == "status_download" ) {
									set_button_download( 0, request.count, request.size );
									set_item_download( request.id, 2 );
								}	
								else if( request.subject == "load_zip_download" ) {
									set_item_download( request.id, 1 );
								}	
								else if( request.subject == "start_download_streams" ) {
									set_item_download_stream( request.id, 'start' );
								}	
								else if( request.subject == "load_download_streams" ) {
									set_item_download_stream( request.id, request.progress, request.size );
								}	
								else if( request.subject == "finish_download_streams" ) {
									set_item_download_stream( request.id, null );
								}	
								else if( request.subject == "save_download_streams" ) {
									var item = document.querySelector('[item="'+request.id+'"');
									var e =  item.querySelector(".js-download-button");
									e.parentNode.removeAttribute( "loading");
									e.textContent='Stop';
								}	
								else if( request.subject == "load_download_record" ) {
									set_item_download_record( request.id, request.count, request.size );
								}	
								else if( request.subject == "mediaDownloadState" )  {
									GetThemAll.PopupVideo.set_status( request );
								}	
							} );

			// инициализируем форматы
			self.init_Format();

			// --- Rate
			var now = new Date().getTime();
			var elem = document.getElementById("help_link_rate");
			if (elem)	{
				if( now - GetThemAll.Prefs.get( "install_time" ) < INTERVAL_TO_DISPLAY_WRITE_REVIEW )		{
					elem.parentNode.style.display = "none";
				}
				if( !_b(GetThemAll.Prefs.get( "popup.display_rate" )) )	{
					elem.parentNode.style.display = "none";
				}
				if ( !GetThemAll.noYoutube )  {
					elem.parentNode.style.display = "none";
				}
				
				menu = document.createElement( "div" );
				menu.setAttribute( "id", "help_link_rate_review" );
				menu.style.display = "none";
				elem.appendChild(menu);
				
				span = document.createElement( "span" );
				span.setAttribute( "class", "help_link_rate_title" );
				span.textContent = "What do you think?";
				menu.appendChild(span);

				var buttonContent2 = '<span style="margin-right:5px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkI2Q0ExOUU2Q0U5MzExRTJCRUI5QTUwMkI5OEY0M0ZFIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkI2Q0ExOUU3Q0U5MzExRTJCRUI5QTUwMkI5OEY0M0ZFIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QjZDQTE5RTRDRTkzMTFFMkJFQjlBNTAyQjk4RjQzRkUiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QjZDQTE5RTVDRTkzMTFFMkJFQjlBNTAyQjk4RjQzRkUiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5y/i71AAACYklEQVR42qRUS2sTURT+7kzM5NFJ0pQk0or2kYRAi1I34qpoFy5UBEFxJxR/QcGdIoiudFHBhQuFIG5LEZetLoJpfZWWFmkxpY4So/ZhzWsmk8nc60mjRTvueuBwX+d85zvfvTNMCIG9mIQ9mmtndo21RhtJtOMB1NhRWBurqNhzqCIDBVmksYLTFNNOflPsAmiaQCdUjKP77ACiXgLjg7ClQejlEazNfsLw2nMCGgPHopNBa3UV8VMD2FwGZGKkBGmvDVADQPjMISRqI8hlLqCQf0jRo/9qIHAQ0dA5FEuAvwZ4VNqjY94A6mXA+AIwDhw+ryKEi04RZeqdH+gBikAgRInUI2vqwloja4LVCYjO63jlbEGQNJH9VJkC5XVaU5Ik/a4htivATawMC9Cx5GQg4TVWp55tB/uSwL5mCzSX3bTuJI9RIjHQsiYsTDsZSPhMyJfwZvIK+lK30HNEhV2hqhGgQKIXZnMwMIEGnsKHmf+10GSpU8ubCEb8cBFlTuovpN//mMdtbVoel07YdYtIlLaAYQeAsQ0SQhe7gVhSAjeBuSfa/ax6+dH3noV5OeBKvPXLuW8fbeQ/QOzW4PjMEN5tIIVIKgEf3f/iRPX6VPjuaK7f9bOqHEspegLY6urwszZFcTOHiDbd+Vi+X6svL00ic6+cfoE7j7/2ad2K1ethvF0IppL7O7w+bzwe38ljf77Gk0NDeCl7WK++EQialei6pDafkUouuQQzG4xXdcMob9ZqZVPTTM658ymrshArlrcY1HnR5WfhkCR03ipjNQTM0vqaYXm8jb9/Ab8EGAAOWeW36rTgEQAAAABJRU5ErkJggg==" align="left"></span>Bad';
				var button2 = document.createElement("button");
				button2.setAttribute("class", "help_link_rate_button");
				button2.setAttribute("type", "button");
				button2.setAttribute("id", "help_link_rate_bad");
				button2.innerHTML = buttonContent2;
				menu.appendChild(button2);
				button2.addEventListener( "click", function(){
								self.set_no_rating();
								var m = document.getElementById("help_link_rate_review");
								setTimeout( function() {   m.style.display = "none";		}, 500);
							}, false );
				
				var buttonContent1 = '<span style="margin-right:5px;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjdCRkM1QTIyQ0U5MzExRTJCNDlEOTdEQjg5QkY1MzVEIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjdCRkM1QTIzQ0U5MzExRTJCNDlEOTdEQjg5QkY1MzVEIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6N0JGQzVBMjBDRTkzMTFFMkI0OUQ5N0RCODlCRjUzNUQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6N0JGQzVBMjFDRTkzMTFFMkI0OUQ5N0RCODlCRjUzNUQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5nMHf4AAACmUlEQVR42qRSTU8TURQ9M1PaOqVFSmkhgJgmQCoYCEElxpiImpi4MXHpkq1xReLKxJWJ7mTtj9AYNFEXLDGoNIALgVCpWApi25nOTGfa+fC0hUBcyMJ5ufPeu+/d88499wqe5+F/Pl/j/1AA6jgSutCK+xAQh4XX0Gj79CdoYZpGE2kumvefeY1tc+M2VjGExFFEIlcRwAh9Ik4geBxA5MsJdIymkLw2hK6Bu/Tc5Enrv0DEY2uX4xfMnSxkGeg7P45ucYb+YTiEPpFBC01ABkv5OWQ3MgiHBQzeuIKR2BOE8AA6gWqQ/wbzHcwCh0S4foKdhmlKqBkULhLEuYkpFLJJFNcuw7C/UNxVmEiTbZFxhtAo44wQZfggIphG1/gtxBO98FcBpwLIcfJsBWyqrO7XkFvcQL44S6CPeOot+Q6yTyGI64gP3UMi5keLzgCaFwQqCstrAafaWaOeeqIp6O8myZToWGpqEGBm/oYWfqiqhIreFEbgseeQCQFsmsj3omeA9v5h9sWFIxGDFE9iXsb6J+hmFSaDHWol8VgiiwC7yM9ZYFouGcEKMbLtSEQTu3wwzTw/sOoDLEm0rit8ZCyQmiTXAT2ov3X8XC8in19ElfcPAZ6v98BwxO247LydblmZQmxsErGzrAyZVExAyQK5vZ2VzcL7+W/2m0sRLAyFUWo7BNi2ZLgeXLXsLs+mO2cnSqWdvvhaqua4mla2iht5Zyu9J6aXCx2fF3LO1xdjinax/VgfhCQbEhkbDrS5XORVtVbKRr8ryfm9tqphueUtzbe9WQn+KNSgQK14L7NB7Ooma84M633w+E4SIgEsCp7RJNzuVZDRw+Kj1W4/RNffGYQUcHS7rJQstVSy4TguBAFuuYw/AgwAs58ROceXw74AAAAASUVORK5CYII=" align="left"></span>Good';
				var button1 = document.createElement("button");
				button1.setAttribute("class", "help_link_rate_button");
				button1.setAttribute("type", "button");
				button1.setAttribute("id", "help_link_rate_good");
				button1.innerHTML = buttonContent1;
				menu.appendChild(button1);
				button1.addEventListener( "click", function(){
								self.set_no_rating();
								self.give_us_rating();
							}, false );
			
				elem.addEventListener( "click", function(){
								self.clickMenu = true;
								var m = document.getElementById("help_link_rate_review");
								if (m.style.display == "none")  m.style.display = "block";
													else m.style.display = "none";
							}, false );
				
				document.addEventListener( "click", function(){
								if (self.clickMenu == true)		{
									self.clickMenu = false;
								}
								else		{	
									var m = document.getElementById("help_link_rate_review");
									m.style.display = "none";
								};
							}, false );
			}
			
			// рейтинг для GTA Suggestion аддона
			var showMessageRate = GetThemAll.Prefs.get( "gta.rate_message.show" );
			var elem = document.getElementById("GtaSuggestionMessage");
			if (elem) {
				if (showMessageRate == 1) {
					elem.removeAttribute("hidden");	
				}	
				elem.addEventListener( "click", function(){
										GetThemAll.Prefs.set( "gta.rate_message.show", 2 );
										self.navigate_url(URL_RATE_REVIEW);
									}, false );
			}						
			
			GetThemAll.AD.rotateOnPage();
			
			// проверим на включение закачки
			if (GetThemAll.Media.isDownload) {
				set_button_download( 3, 0 );
			}	
			
		}
		
		// ----------------------------------------------
		function download_set( request ){	

			var item = document.querySelector( '[item="'+request.id+'"]' );			
			if (!item) return;
			
			var btn =	item.querySelector(".js-download-button");
			var e_siz =	item.querySelector(".item_size");

			if (request.status == 'start') {
				item.setAttribute( "status", 'start' );
				btn.textContent = 'Cancel';
				btn.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #FC2B53, #F9869C)';
			}
			else if (request.status == 'stop') {
				item.setAttribute( "status", 'stop' );
				btn.textContent = 'Download';
				btn.parentNode.style['background'] = '-webkit-linear-gradient(90deg, #4da5d8, #58d2fd)';
			}
			else if (request.status == 'progress') {
				if( request.size && request.size>0 )	{
					e_siz.textContent = self.str_download_size( request.size );
				}
			}
			
		}
		
		// ----------------------------------------------
		this.give_us_rating = function(){

			var url;
			if( GetThemAll.noYoutube )	{
				url = URL_RATE_REVIEW;
			}	
			else	{
				url = "http://flashvideodownloader.org/fvd-suite/to/s/rate_ch_cn";
			}	

			chrome.tabs.create( {	active: true,
									url: url
								}, function( tab ){ }
							);
		}
		// ----------------------------------------------
		this.set_no_rating = function(){
			GetThemAll.Prefs.set( "popup.display_rate", false );
		}
		
		// ---------------------------------------------------- инициализируем форматы
		this.init_Format = function(){
		
			var mode = GetThemAll.Prefs.get( "gta.links_mode" );
		
			// ---- форматы
			var filters = document.getElementById("filter_block");
			var elems = filters.querySelectorAll( ".gta_downloader_check_element" );
			for (var i=0; i<elems.length; i++)	{
				if ( elems[i].type=="checkbox" && elems[i].id.indexOf("filter_") != -1 )	{
					var id = elems[i].getAttribute("id");
					var x = GetThemAll.Prefs.get( "gta."+id );
				
					if (x && x=="true") elems[i].setAttribute("checked","true");
				
					elems[i].addEventListener( "change", function(event){
								self.change_Format( this );		
							}, false );				
				}			
				if ( elems[i].type=="checkbox" && elems[i].id == "flag_image_preview" )	{
					document.getElementById("flag_image_preview").checked  = _b(GetThemAll.Prefs.get( "gta.flag_image_preview" ));
				}
				if ( elems[i].type=="text" && elems[i].id == "filter_image_size" )	{
					document.getElementById("filter_image_size").value  = GetThemAll.Prefs.get( "gta.filter_image_size" );
				}
			}
			
			// ---- фильтр по размеру
			var elem_size = document.getElementById("filter_image_size");
			const arrKey = [48,49,50,51,52,53,54,55,56,57,190,96,97,98,99,100,101,102,103,104,105,110,8,37,39,46];
			if (elem_size)	{
				elem_size.addEventListener( "keydown", function(event){
				
								if (arrKey.indexOf(event.keyCode) == -1)	{
									// отменить дальнейшую обработку
									event.returnValue = false;
									event.stopPropagation();
									event.preventDefault();
									return false;								
								}
				
							}, false );
				elem_size.addEventListener( "keyup", function(event){
									GetThemAll.Prefs.set( "gta.filter_image_size", this.value )
									self.repaintThreadsList();			
							}, false );
			}

			// ---- вид отображения
			var elem_view = document.getElementById("flag_image_preview");
			if (elem_view)	{
				elem_view.addEventListener( "change", function(event){
				
								var v = document.getElementById("flag_image_preview").checked;
								if (v)	GetThemAll.Prefs.set( "gta.flag_image_preview", "true" );
								else	GetThemAll.Prefs.set( "gta.flag_image_preview", "false" );

								//if (v)	document.getElementById("button_select_all").setAttribute('style', 'display: block');
								//else	document.getElementById("button_select_all").setAttribute('style', 'display: none');
								
								self.repaintThreadsList();			
							}, false );
			}
			
			
			// ---- Сортировка
			var srtn = GetThemAll.Prefs.get( "gta.links_sorting" );
			if (mode == "link" && (srtn == "asc_size" || srtn == "desc_size") ) srtn == "none";
			var e1 = document.getElementById("sort_url");
			var e2 = document.getElementById("sort_descr");
			var e3 = document.getElementById("sort_size");
			if (srtn == "asc_url")	{
				e1.setAttribute("sort", "asc");
				e2.setAttribute("sort", "none");
				e3.setAttribute("sort", "none");
			}
			else if (srtn == "desc_url")  {
				e1.setAttribute("sort", "desc");
				e2.setAttribute("sort", "none");
				e3.setAttribute("sort", "none");
			}
			else if (srtn == "asc_title")	{
				e2.setAttribute("sort", "asc");
				e1.setAttribute("sort", "none");
				e3.setAttribute("sort", "none");
			}
			else if (srtn == "desc_title")	{
				e2.setAttribute("sort", "desc");
				e1.setAttribute("sort", "none");
				e3.setAttribute("sort", "none");
			}
			else if (srtn == "asc_size")  {
				e3.setAttribute("sort", "asc");
				e2.setAttribute("sort", "none");
				e1.setAttribute("sort", "none");
			}
			else if (srtn == "desc_size")  {
				e3.setAttribute("sort", "desc");
				e2.setAttribute("sort", "none");
				e1.setAttribute("sort", "none");
			}
			else  {
				e1.setAttribute("sort", "none");
				e2.setAttribute("sort", "none");
				e3.setAttribute("sort", "none");
			}
		}	

		// ----------------------------------------------------   после выбора all - остальные сбрасываем
		function clear_format( tip ){

			// ---- форматы
			var filters = document.getElementById("filter_block");
			var elems = filters.querySelectorAll( "input" );
		
			for (var i=0; i<elems.length; i++)
			{
				var id = elems[i].getAttribute("id");
				if ( id.indexOf("filter_"+tip+"_all") != -1) continue; 
				if ( id.indexOf("filter_image_preview") != -1) continue; 
				if ( id.indexOf("filter_image_size") != -1) continue; 
				if ( id.indexOf("filter_"+tip) != -1)
				{
					elems[i].checked = false;
					GetThemAll.Prefs.set( "gta."+id , "false" );
				}	
			}
		
		}
		// ----------------------------------------------------   после отключения all - хоть один должен быть включен
		function set_one_format( tip ){

			// ---- форматы
			var filters = document.getElementById("filter_block");
			var elems = filters.querySelectorAll( "input" );
		
			for (var i=0; i<elems.length; i++)
			{
				var id = elems[i].getAttribute("id");
				if ( id.indexOf("filter_"+tip+"_all") != -1) continue; 
				if ( id.indexOf("filter_image_size") != -1) continue; 
				if ( id.indexOf("filter_"+tip) != -1) 
				{
					if ( elems[i].checked )   return;   // есть выбранная уходим
				}	
			}

			for (var i=0; i<elems.length; i++)
			{
				var id = elems[i].getAttribute("id");
				if ( id.indexOf("filter_"+tip+"_all") != -1) continue; 
				if ( id.indexOf("filter_image_size") != -1) continue; 
				if ( id.indexOf("filter_"+tip) != -1) 
				{
					elems[i].checked = true;
					GetThemAll.Prefs.set( "gta."+id , "true" );
					return;   
				}	
			}
		}
		
		
		// ---------------------------------------------------- инициализируем форматы
		this.change_Format = function( elem ){

			var id = elem.getAttribute("id");
			var x = elem.checked;
			if (x)	GetThemAll.Prefs.set( "gta."+id , "true" );
			else GetThemAll.Prefs.set( "gta."+id , "false" );
			
			// проверка на all
			if ( id == "filter_link_all" )
			{
				if ( x )		clear_format( "link" );
				else			set_one_format( "link" );
			}	
			else if ( id == "filter_image_all" )
			{
				if ( x )		clear_format( "image" );
				else			set_one_format( "image" );
			}	
			else if ( id == "filter_file_all" )
			{
				if ( x )		clear_format( "file" );
				else			set_one_format( "file" );
			}	
			else if ( id == "filter_video_all" )
			{
				if ( x )		clear_format( "video" );
				else			set_one_format( "video" );
			}
			else
			{
				if ( id.indexOf("link") != -1)
				{
					document.getElementById("filter_link_all").checked = false;
					GetThemAll.Prefs.set( "gta.filter_link_all" , "false" );
				}
				else if ( id.indexOf("image") != -1)
				{
					document.getElementById("filter_image_all").checked = false;
					GetThemAll.Prefs.set( "gta.filter_image_all" , "false" );
				}
				else if ( id.indexOf("file") != -1)
				{
					document.getElementById("filter_file_all").checked = false;
					GetThemAll.Prefs.set( "gta.filter_file_all" , "false" );
				}
				else if ( id.indexOf("video") != -1)
				{
					document.getElementById("filter_video_all").checked = false;
					GetThemAll.Prefs.set( "gta.filter_video_all" , "false" );
				}
			}	
			
			this.repaintThreadsList();			
			
		}
		// ---------------------------------------------------- загрузка одной
		this.DownloadOne = function(id){
			
			var media = null;

			self.ListLink.link.forEach( function( item )  {
						if ( item.id == id)	{
							media = item;		
						}	
			} ); 
			self.ListLink.image.forEach( function( item )  {
						if ( item.id == id)	{
							media = item;		
						}	
			} ); 
			self.ListLink.file.forEach( function( item )  {
						if ( item.id == id)	{
							media = item;		
						}	
			} ); 
			self.ListLink.video.forEach( function( item )  {
						if ( item.id == id)	{
							media = item;		
						}	
			} ); 
			
			if (media) {
				GetThemAll.Utils.getActiveTab( function( tab )  {		
					GetThemAll.Media.clickOneDownload( media, tab );
				});	 
			}
			
		}
		
		// ---------------------------------------------------- перестроить список загрузок 
		this.DownloadList = function(){

			if (GetThemAll.Media.isDownload) {		// уже качается - стоп
				GetThemAll.Media.isDownload = false;
				GetThemAll.Media.stopListDownload( );
			}
			else {
		
				var list = [];
				//-------------- загрузка ссылок
				if (self.ListLink.k_link>0) 	{
					self.ListLink.link.forEach( function( item )  {
								if ( item.vubor == 1)	{
									item.vubor == 0;		
									GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, item.id, 0 );		});
									list.push( item );
								}	
							} ); 
				}			
				
				//--------------- загрузка изображений
				if (self.ListLink.k_image>0) 	{
					self.ListLink.image.forEach( function( item )  {
								if ( item.vubor == 1)	{
									item.vubor == 0;		
									GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, item.id, 0 );		});
									list.push( item );
								}	
							} ); 
				}			
				
				//--------------- загрузка документов
				if (self.ListLink.k_file>0) {
					self.ListLink.file.forEach( function( item )  {
								if ( item.vubor == 1)	{
									item.vubor == 0;		
									GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, item.id, 0 );		});
									list.push( item );
								}	
							} ); 
				}			
				
				//--------------- загрузка видео
				if (self.ListLink.k_video>0) 	{
					self.ListLink.video.forEach( function( item )  {
								if ( item.vubor == 1)	{
									item.vubor == 0;		
									GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Status( tab.id, item.id, 0 );		});
									list.push( item );
								}	
							} ); 
				}			
				
				if (list.length>0) {
					GetThemAll.Utils.getActiveTab( function( tab )  {		
						GetThemAll.Media.startListDownload( list, tab.title );
					});	
					
				}	
				
				var container = document.getElementById("download_item_container");
				var elems = container.querySelectorAll( ".item_sel" );
				for (var i=0; i<elems.length; i++)	{
					elems[i].checked = false;
				}	
				
			}	
			
		}
		
		// ---------------------------------------------------- выделить все
		this.SelectAll = function(){
		
			var view = _b(GetThemAll.Prefs.get( "gta.flag_image_preview" ));
		
			var cl = 'div.item_sel';
			var container = document.getElementById("download_item_container");
			
			var e = document.getElementById("head_all_sel");
			
			if (e)	{
				var x = e.getAttribute("check");
				if ( x == "1")	{		// unselect
					e.setAttribute("check", "0");
					GetThemAll.Utils.getActiveTab( function( tab ){
								var elems = container.querySelectorAll( '.js-item' );
								
								for (var i=0; i<elems.length; i++)	{
									var id = parseInt( elems[i].getAttribute("item") );
									var e = elems[i].querySelector(".item_sel");
									e.checked = false;
								    self.setCheck_ListMedia( id, 0);
								}
							});
					x = "0";
				}
				else	{				// select
					e.setAttribute("check", "1");
					GetThemAll.Utils.getActiveTab( function( tab ){
								var elems = container.querySelectorAll( '.js-item' );
								for (var i=0; i<elems.length; i++)	{
									var id = parseInt( elems[i].getAttribute("item") );
									var e = elems[i].querySelector(".item_sel");
									var d = e.getAttribute('disabled');
									if (d) continue;
								
									e.checked = true;
								    self.setCheck_ListMedia( id, 1);
								}
							});
					x = "1";
				}
				
				// флаг на страницу	
				//if (document.getElementById("tab_links").getAttribute("checked") == "true") this.tabSelectAll_links = x;
				//else if (document.getElementById("tab_images").getAttribute("checked") == "true") this.tabSelectAll_images = x;
				//else if (document.getElementById("tab_docs").getAttribute("checked") == "true") this.tabSelectAll_docs = x;
				//else if (document.getElementById("tab_videos").getAttribute("checked") == "true") this.tabSelectAll_videos = x;
			}

		}
		// ---------------------------------------------------- выделить все
		this.SortMedia = function( tip ){
		
			if ( tip == "url" )
			{
				var e = document.getElementById("sort_url");
				var x = e.getAttribute("sort");
	
				if ( x == "none")
				{
					e.setAttribute("sort", "asc");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "asc_url" );
				}
				else if ( x == "asc")
				{
					e.setAttribute("sort", "desc");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "desc_url" );
				}
				else
				{
					e.setAttribute("sort", "none");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "none" );
				}
				var e1 = document.getElementById("sort_descr");
				e1.setAttribute("sort", "none");
				var e2 = document.getElementById("sort_size");
				e2.setAttribute("sort", "none");
			}
			else if ( tip == "descr" )
			{
				var e = document.getElementById("sort_descr");
				var x = e.getAttribute("sort");
				if ( x == "none")
				{
					e.setAttribute("sort", "asc");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "asc_title" );
				}
				else if ( x == "asc")
				{
					e.setAttribute("sort", "desc");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "desc_title" );
				}
				else
				{
					e.setAttribute("sort", "none");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "none" );
				}
				var e1 = document.getElementById("sort_url");
				e1.setAttribute("sort", "none");
				var e2 = document.getElementById("sort_size");
				e2.setAttribute("sort", "none");
			}
			else if ( tip == "size" )
			{
				var e = document.getElementById("sort_size");
				var x = e.getAttribute("sort");
				if ( x == "none")
				{
					e.setAttribute("sort", "asc");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "asc_size" );
				}
				else if ( x == "asc")
				{
					e.setAttribute("sort", "desc");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "desc_size" );
				}
				else
				{
					e.setAttribute("sort", "none");
					GetThemAll.Prefs.set( "gta.links_sorting" ,  "none" );
				}
				var e1 = document.getElementById("sort_url");
				e1.setAttribute("sort", "none");
				var e2 = document.getElementById("sort_descr");
				e2.setAttribute("sort", "none");
			}
			self.repaintThreadsList();
			
		}
		// ----------------------------------------------
		this.display_setting = function(){
			chrome.tabs.query( 	{
							url: chrome.extension.getURL( "/options.html" )
						}, function( tabs ){

									if( tabs.length > 0 )
									{
										foundTabId = tabs[0].id;
										chrome.tabs.update( foundTabId, {
																		active: true
																		} );
									}
									else
									{
										chrome.tabs.create( {	active: true,
																url: chrome.extension.getURL("/options.html")
															}, function( tab ){ }
														);
									}
					} );
		}
		// ----------------------------------------------
		this.openGetSatisfactionSuggestions = function(){
		
			window.open( "https://fvdmedia.userecho.com/list/21579-chrome-extensions/?category=4919" );
			
		}
		// ----------------------------------------------
		this.navigate_url = function( url ){
			chrome.tabs.query( 	{
							url:  url 
						}, function( tabs ){

									if( tabs.length > 0 )
									{
										foundTabId = tabs[0].id;
										chrome.tabs.update( foundTabId, {
																		active: true
																		} );
									}
									else
									{
										chrome.tabs.create( {	active: true,
																url: url
															}, function( tab ){ }
														);
									}
					} );
		}
		
		// ----------------------------------------------------- показать сообщение о рейтинге
		this.show_rate_message = function(){

			var showMessageRate = GetThemAll.Prefs.get( "gta.rate_message.show" );

			if (showMessageRate == 0) {
				var now = new Date().getTime();

				if( now - GetThemAll.Prefs.get( "install_time" ) > INTERVAL_TO_DISPLAY_RATE )		{

					GetThemAll.Prefs.set( "gta.rate_message.show", 1 );
					showMessageRate = 1;
				}	
			}	

			if (showMessageRate == 1) {
				var elem = document.getElementById("GtaSuggestionMessage");
				if (elem) elem.removeAttribute("hidden");	
			}	

		}
		
		// ----------------------------------------------------- 
		this.ShowFilter = function(){

			var elem = document.getElementById("filter_block");
			var v = elem.style.display;
			if (v == 'block') {
				elem.style.display = 'none';
			}
			else {
				elem.style.display = 'block';
			}	

		}
		this.CloseFilter = function(){

			var elem = document.getElementById("filter_block");
			elem.style.display = 'none';

		}
		// -----------------------------------------------	
		this.filtering_mask = function(){

			var text = document.getElementById("filter_mask_text").value;
			if (text.length == 0) return;
			
			var container = document.getElementById("download_item_container");
			var elems = container.querySelectorAll( '.js-item' );
								
			for (var i=0; i<elems.length; i++)	{
				var id = parseInt( elems[i].getAttribute("item") );
				var e = elems[i].querySelector(".item_sel");
				if (check_mask(id, text)) {
					e.checked = true;
					self.setCheck_ListMedia( id, 1);
				}	
				else {
					e.checked = false;
					self.setCheck_ListMedia( id, 0);
				}	
			}

		}
		function check_mask(id, text) {
			
			var f = false;
			if (self.ListLink.k_link>0) {
				self.ListLink.link.forEach( function( item ){
							if ( item.id == id)	{
								if ( item.url.indexOf(text) != -1 ) f = true;
							}	
						});
				if (f) return true;		
			}			
			if (self.ListLink.k_image>0) {
				self.ListLink.image.forEach( function( item ){
							if ( item.id == id)		{
								if ( item.url.indexOf(text) != -1 ) f = true;
							}	
						} );
				if (f) return true;		
			}			
			if (self.ListLink.k_file>0) {
				self.ListLink.file.forEach( function( item ){
							if ( item.id == id)		{
								if ( item.url.indexOf(text) != -1 ) f = true;
							}	
						} );
				if (f) return true;		
			}			
			if (self.ListLink.k_video>0) {
				self.ListLink.video.forEach( function( item ){
							if ( item.id == id)		{
								if ( item.url.indexOf(text) != -1 ) f = true;
							}	
						} );
				if (f) return true;		
			}			
			
			return false;
		}	
		
		// ----------------------------------------------------- 
		this.SaveLink = function(){

			if (self.ListLink) {
				GetThemAll.Utils.getActiveTab( function( tab ){
					GetThemAll.Media.SaveLink( self.ListLink, tab.title );
				});	
			}
		
		}
		
		// ----------------------------------------------------- 
		this.ClearAllMedia = function(){

			var mode = GetThemAll.Prefs.get( "gta.links_mode" );
		
			GetThemAll.Utils.getActiveTab( function( tab ){
				GetThemAll.Storage.removeTabDataMode( tab.id, mode );
				
				self.rebuildThreadsList();
		
			});
		
		}

		// ----------------------------------------------------- 
		this.filter_extensions = function( media, filters ){

			var ff = {};

			for ( var id in filters ) {
				if ( !filters[id].ext ) continue;
				ff[id] = {  id: 	id,  	
							flag:   _b(GetThemAll.Prefs.get( "gta.filter_"+id )),
							list:   filters[id].ext	 };
			}	

			var m = media.filter( function (item, i, arr) {

				if ( !item.ext )  return false;

				for ( var id in ff ) {
					if ( ff[id].flag )  {
						if (ff[id].list.indexOf(item.ext) != -1) return true;
					}
				}	

				return false;
			});	

			return m;

		}	

		// ----------------------------------------------------- 
		this.set_popup = function( x ){

			GetThemAll.Prefs.set( "gta.links_mode", x );
			self.mode = x;

			document.getElementById("tab_links").removeClass("gta_downloader_tab_active");
			document.getElementById("tab_docs").removeClass("gta_downloader_tab_active");
			document.getElementById("tab_images").removeClass("gta_downloader_tab_active");
			document.getElementById("tab_videos").removeClass("gta_downloader_tab_active");
			document.getElementById("filter_links").style.display="none";
			document.getElementById("filter_images").style.display="none";
			document.getElementById("filter_videos").style.display="none";
			document.getElementById("filter_docs").style.display="none";

			if ( x == "file" ) 	{
				document.getElementById("tab_docs").addClass("gta_downloader_tab_active");
				document.getElementById("filter_docs").style.display="block";
				document.getElementById("head_size").style.display="block";
				document.getElementById("downloaderHead").style.display="block";
				document.getElementById("footer_buttons").style.display="block";
				document.getElementById("filter_block").style.display="block";
			}	
			else if ( x == "image" )		{
				document.getElementById("tab_images").addClass("gta_downloader_tab_active");
				document.getElementById("filter_images").style.display="block";
				document.getElementById("head_size").style.display="block";
				document.getElementById("downloaderHead").style.display="block";
				document.getElementById("footer_buttons").style.display="block";
				document.getElementById("filter_block").style.display="block";
			}	
			else if ( x == "media" ) 	{
				document.getElementById("tab_videos").addClass("gta_downloader_tab_active");
				document.getElementById("filter_videos").style.display="block";
				document.getElementById("head_size").style.display="block";
				document.getElementById("downloaderHead").style.display="none";
				document.getElementById("footer_buttons").style.display="none";
				document.getElementById("filter_block").style.display="none";
			}	
			else if ( x == "video" ) 	{
				document.getElementById("tab_videos").addClass("gta_downloader_tab_active");
				document.getElementById("filter_videos").style.display="block";
				document.getElementById("head_size").style.display="block";
				document.getElementById("downloaderHead").style.display="block";
				document.getElementById("footer_buttons").style.display="block";
				document.getElementById("filter_block").style.display="block";
			}	
			else	{
				document.getElementById("tab_links").addClass("gta_downloader_tab_active");
				document.getElementById("filter_links").style.display="block";
				document.getElementById("head_size").style.display="none";
				document.getElementById("downloaderHead").style.display="block";
				document.getElementById("footer_buttons").style.display="block";
				document.getElementById("filter_block").style.display="block";
			}	
			
			setTimeout( function(){
				var elem1 = document.getElementById("masterMain");
				var box1 = elem1.getBoundingClientRect();
				
				var elem2 = document.getElementById("masterHead");
				var box2 = elem2.getBoundingClientRect();
				
				var elem3 = document.getElementById("downloaderHead");
				var box3 = elem3.getBoundingClientRect();
				
				var elem4 = document.getElementById("masterFooter");
				var box4 = elem4.getBoundingClientRect(); 
				
				var elem5 = document.getElementById("GtaSuggestionMessage");
				var box5 = elem5.getBoundingClientRect(); //
				
				var h = 600 - box2.height - box3.height - box4.height - box5.height;

				var elem5 = document.getElementById("showMain");
				elem5.setAttribute('style', 'height: '+h+'px;');
				
			},100);
		
		}
		// -----------------------------------------------	
		
	}
	
	this.Popup = new Popup();
	
}).apply( GetThemAll );
