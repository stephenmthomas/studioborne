(function(){
	
	var PopupFile = function(){
		
		var self = this;
		
		const FILTER_FILE = {  
								'file_all':		{	title: 'All files' },
							  	'file_doc':		{   title: 'doc',  	ext: ["doc", "docx", "rtf"] },
							  	'file_xls':		{	title: 'xls',	ext: ["xls", "xlsx"] },
							  	'file_ppt':		{	title: 'ppt',	ext: ["ppt", "pptx"] },
							  	'file_pdf':		{	title: 'pdf',	ext: ["pdf", "odf", "odt"] },
							  	'file_exe':		{	title: 'exe & msi', ext: ["exe", "bin", "msi", "iso", "dmg"] },
							  	'file_addon':	{	title: 'addon', ext: ["xpi", "crx", "nex", "oex"] },
							  	'file_zip':		{	title: 'zip',	ext: ["zip"] },
							  	'file_rar':		{	title: 'rar',	ext: ["rar"] },
							  	'file_7z':		{	title: '7z',	ext: ["7z"] },
							  	'file_jar':		{	title: 'jar',   ext: ["jar"] },
							  	'file_tar':		{	title: 'tar',	ext: ["tar", "bz2", "qz"] },
							};
							
		const SHOW_TYPE = [ 'file', 'archiv' ];						
							  
		// ----------------------------------------------------- 
		this.buildFilters = function(  ){
			
			var block_link = document.getElementById("filter_docs").querySelector('.gta_downloader_filter_set_content');			
			for (var id in FILTER_FILE) {
				var item = document.createElement('div');
				item.setAttribute('class', 'gta_downloader_filter_item');
				item.innerHTML = '<label class="gta_downloader_check">'+
								 '	<input type="checkbox" id="filter_'+ id +'" class="gta_downloader_check_element">'+
								 '	  <span class="gta_downloader_check_block"><i></i></span>'+
								 FILTER_FILE[id].title+ 
								 '</label>';
				block_link.appendChild(item);				
			}	
			
		}

		// ----------------------------------------------------- 
		this.repaint = function( threads ){

			var container = document.getElementById("download_item_container");
		
			threads.forEach(function( thread ){
						if ( SHOW_TYPE.indexOf( thread.type ) != -1) {
							var item = buildThreadItem( thread, GetThemAll.Popup.mode );	
							if (item) container.appendChild( item );				
						}	
			});
		
		}
		
		// ----------------------------------------------------   заполним строку
		this.filter_media = function( media ){
			
			if ( GetThemAll.Prefs.get( "gta.filter_file_all" ) == "false" )		{

				media = GetThemAll.Popup.filter_extensions( media, FILTER_FILE );

			}						
			
			return media;
		
		}	
		
		// ----------------------------------------------------   заполним строку
		function buildThreadItem( media, mode ){

			//console.log(media);		
			
			function fbc( className ){
				return item.getElementsByClassName(className)[0];
			}

			if (!media.url || media.url == "") return null;
			
			var item = null;
			
			var item = document.querySelector('[item="'+media.id+'"');
			if (item) {		// исправим
				// --  url
				var e1 =  fbc("item_url");
				e1.textContent = media.url;			
				e1.title = media.url;
				e1.href = media.url;

				// --  descr
				var e2 =  fbc("item_descr");
				e2.textContent = media.displayName;
				e2.title = media.title;
			
				return;
			}
			
			item = document.getElementById("download_item_template").cloneNode( true );
			item.removeAttribute( "id" );
			item.setAttribute("item", media.id);
			item.setAttribute("status", media.status);

			if (media.zip>0) item.setAttribute("zip", media.zip);	
			
			// --  url
			var e1 =  fbc("item_url");
			e1.textContent = media.url;			
			e1.title = media.url;
			e1.href = media.url;
			
			e1.addEventListener( "contextmenu", function( event ){

							GetThemAll.Popup.Item_contextMenu( this.title, media.id );
			
						}, false ); 
						
			// --  descr
			var e2 =  fbc("item_descr");
			e2.textContent = media.displayName;
			e2.title = media.title;

			// --  extension
			var e3 =  fbc("item_ext");
			var extClass = 'gta_downloader_icon_ic_list_other';
			
			switch ( media.ext )    {
				case "rtf":
				case "docx":
				case "doc":   extClass = "gta_downloader_icon_ic_list_doc";   break;
				case "xlsx":
				case "xls":   extClass = "gta_downloader_icon_ic_list_xls";   break;
				case "pptx":
				case "ppt":   extClass = "gta_downloader_icon_ic_list_ppt";   break;
				case "odf":
				case "odt":
				case "pdf":   extClass = "gta_downloader_icon_ic_list_pdf";   break;
				case "zip":	  extClass = "gta_downloader_icon_ic_list_zip";   break;	
				case "rar":	  extClass = "gta_downloader_icon_ic_list_rar";   break;	
				case "7z":    extClass = "gta_downloader_icon_ic_list_7z";    break;
				case "jar":   extClass = "gta_downloader_icon_ic_list_jar";   break;
				case "qz":
				case "bz2":	  extClass = "gta_downloader_icon_ic_list_bz2";   break;
				case "tar":   extClass = "gta_downloader_icon_ic_list_tar";   break;
				case "exe":
				case "bin":
				case "iso":
				case "dmg":
				case "msi":   extClass = "gta_downloader_icon_ic_list_exe";   break;
				case "xpi":   extClass = "gta_downloader_icon_ic_list_xpi";   break;
				case "crx":   extClass = "gta_downloader_icon_ic_list_crx";   break;
				case "nex":
				case "oex":   extClass = "gta_downloader_icon_ic_list_oex";   break;
				default: 	  extClass = "gta_downloader_icon_ic_list_file";
			}
			e3.addClass(extClass);
			e3.title = media.ext ? media.ext : media.type;
			
			// -- select
			var e4 =  fbc("item_sel");
			if ( GetThemAll.Popup.isYoutubeUrl(media.url) && (mode == "video") )		{
				return null;
			}
			else if ( media.metod == "record" || media.metod == "stream" )		{
				e4.setAttribute('disabled', true);
			}
			else	{
				if ( media.vubor == 1) 	e4.checked = true;
								  else  e4.checked = false;
								  
				e4.addEventListener( "click", function( event ){

						var x = this.checked;
						var id = parseInt( this.getAttribute("item") );
						if (x)	{
							GetThemAll.Popup.setCheck_ListMedia( id, 1);
						}	
						else 	{
							GetThemAll.Popup.setCheck_ListMedia( id, 0);
							GetThemAll.Popup.clear_Flag_SelectAll(  );  // убрать метку select all
						}
								
					}, false );
			}					  
			
			e4.title = media.source;
			e4.setAttribute("item", media.id);			

			// -- size
			if ( media.metod == "download" )  {
				var e5 =  fbc("item_size");
				e5.parentNode.removeAttribute("hidden");
				e5.textContent = "";	
				
				if (media.size) 	{
					e5.textContent = GetThemAll.Popup.str_download_size(media.size);
				}
				else	{
					e5.setAttribute( "loading", 1 );
				
					GetThemAll.Utils.getSizeByUrl( media.url, function( size ){
					
														e5.removeAttribute( "loading" );
														if( size ) 	{
															GetThemAll.Utils.getActiveTab( function( tab ){		
																if (tab) GetThemAll.Storage.setData_Attribute( tab.id, media.id, "size", size );		
															});
														
															e5.textContent = GetThemAll.Popup.str_download_size( size );
														}
					
													} );				

				}
			}
			else   {

				if (media.status == 'start') 	{
					if (media.progressByte && media.progressByte>0) {
						fbc("item_size").textContent = GetThemAll.Popup.str_download_size(media.progressByte);
					}	
				}

			}	
			
			// -- download
			var e6 =  fbc("js-download-button");
			
			if ( e6 )		{
				GetThemAll.Popup.button_download(media.metod, media.status, e6);
				
				e6.setAttribute("item", media.id);		
				e6.addEventListener( "click", function( event ){
					var id = parseInt( this.getAttribute("item") );

					item.setAttribute("status", media.status == 'start' ? 'stop' : 'start');
					
					if (media.metod == "download") {
						GetThemAll.Popup.button_download(media.metod, media.status == 'start' ? 'stop' : 'start', e6)
					}
					else {	
						GetThemAll.Popup.button_download(media.metod, media.status == 'start' ? 'stop' : 'start', e6)
					}
					
					GetThemAll.Popup.DownloadOne(id);					
					
					event.stopPropagation();
				}, false );
			}		
			
			
			return item;
			
		}
		
		// ----------------------------------------------------   
		this.show_count = function( counts ){

			if (counts.vfile > 0) {
				document.getElementById("vubor_docs").textContent  = counts.vfile.toString();
				document.getElementById("vubor_docs").style.display = 'inline-block';
			}
			else {
				document.getElementById("vubor_docs").textContent  = '';
				document.getElementById("vubor_docs").style.display = 'none';
			}	
			if (counts.file > 0) {
				document.getElementById("count_docs").innerHTML  = '<span class="count">' + counts.file.toString() + '</span> '+
																   '<span class="label">' + _("popup_tab_detected") + '</span>';
			}
			else {
				document.getElementById("count_docs").textContent  = _("popup_tab_not_detected");
			}	
		
		}	
		
		// ----------------------------------------------------- 
		this.set_popup = function( e ){

			GetThemAll.Popup.set_popup( "file" );
			
			GetThemAll.Popup.box_Youtube();
			GetThemAll.Popup.repaintThreadsList();		
		}
		// -----------------------------------------------	
		
	}
	
	this.PopupFile = new PopupFile();
	
}).apply( GetThemAll );
