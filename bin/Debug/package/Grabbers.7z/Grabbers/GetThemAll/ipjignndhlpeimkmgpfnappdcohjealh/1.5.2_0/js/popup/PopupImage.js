(function(){
	
	var PopupImage = function(){
		
		var self = this;

		const FILTER_IMAGES = { 
								'image_all':    {	title: 'All files' },
								'image_jpg':    {	title: 'jpg',  ext: ["jpg", "jpeg"] },
								'image_gif':    {	title: 'gif',  ext: ["gif"] },
								'image_png':    {	title: 'png',  ext: ["png"] },
								'image_bmp':    {	title: 'bmp',  ext: ["bmp"] },
								'image_ico':    {	title: 'ico',  ext: ["ico"] },
								'image_vector': { 	title: 'Vector files', ext: ["svg", "svgt", "wmf", "swf", "cgm"] },
							  };
							  
		const SHOW_TYPE = [ 'image' ];						
							  
		// ----------------------------------------------------- 
		this.buildFilters = function(  ){
			
			var block_link = document.getElementById("filter_images").querySelector('.gta_downloader_filter_set_content');			
			for (var id in FILTER_IMAGES) {
				var item = document.createElement('div');
				item.setAttribute('class', 'gta_downloader_filter_item');
				item.innerHTML = '<label class="gta_downloader_check">'+
								 '	<input type="checkbox" id="filter_'+id+'" class="gta_downloader_check_element">'+
								 '	  <span class="gta_downloader_check_block"><i></i></span>'+
								 FILTER_IMAGES[id].title+ 
								 '</label>';
				block_link.appendChild(item);				
			}	
			
		}

		// ----------------------------------------------------- 
		this.repaint = function( threads ){

			var container = document.getElementById("download_item_container");
			var view = _b(GetThemAll.Prefs.get( "gta.flag_image_preview" ));
		
			threads.forEach(function( thread ){
						var item = null;
						if ( SHOW_TYPE.indexOf( thread.type ) != -1) {
							if (view)	{
								item = buildThreadItemAlternative( thread, GetThemAll.Popup.mode );	
								if (item) container.appendChild( item );				
							}	
							else	{
								item = buildThreadItem( thread, GetThemAll.Popup.mode );	
								if (item) container.appendChild( item );				
							}	
						}	
			});
		
		}
		
		// ----------------------------------------------------   заполним строку
		this.filter_media = function( media ){
			
			if ( GetThemAll.Prefs.get( "gta.filter_image_all" ) == "false" )	{

				media = GetThemAll.Popup.filter_extensions( media, FILTER_IMAGES );

			}

			var v = document.getElementById("filter_image_size").value;
			if (!v || v == "") v = 0;
			var min_size = parseFloat(v);
			
			if ( min_size )	{
				min_size = min_size * 1024;
				media = media.filter( function (item, i, arr) {
										if ( item.size != "" && item.size < min_size ) return false;
										return true;
									} );			
			}
			
			return media;
		
		}	

		// ----------------------------------------------------   заполним строку
		function buildThreadItem( media, mode ){

			//console.log(media);		
			
			function fbc( className ){
				return item.getElementsByClassName(className)[0];
			}

			if (!media.url || media.url == "") return null;
			
			var item = null;
			
			var item = document.querySelector('[item="'+media.id+'"');
			if (item) {		// исправим
				// --  url
				var e1 =  fbc("item_url");
				e1.textContent = media.url;			
				e1.title = media.url;
				e1.href = media.url;

				// --  descr
				var e2 =  fbc("item_descr");
				e2.textContent = media.displayName;
				e2.title = media.title;
			
				return;
			}
			
			item = document.getElementById("download_item_template").cloneNode( true );
			item.removeAttribute( "id" );
			item.setAttribute("item", media.id);
			item.setAttribute("status", media.status);

			if (media.zip>0) item.setAttribute("zip", media.zip);	
			
			// --  url
			var e1 =  fbc("item_url");
			e1.textContent = media.url;			
			e1.title = media.url;
			e1.href = media.url;
			
			e1.addEventListener( "contextmenu", function( event ){

							GetThemAll.Popup.Item_contextMenu( this.title, media.id );
			
						}, false ); 
						
			var e1e =  fbc("item_ext");
			e1e.setAttribute("adr", media.url);
			e1e.addEventListener( "mouseover", function( event ){

						var ee = document.getElementById("image-tooltip");
						
						var x = event.clientX + 20;
						var y = event.clientY;
						if (y > 250)   y = event.clientY-100;
						if (y > 340)   y = event.clientY-200;
						if (y > 440)   y = event.clientY-300;
						
						ee.style.left = x;
						ee.style.top = y;
						ee.style.opacity = 1;
						ee.style.display = "block";
						
						var img_url = this.getAttribute("adr");

						var ii = document.getElementById("preview-image");
						ii.src = img_url;
						ii.addEventListener( "load", function( event ){
									
											var ee = document.getElementById("rg3fbpz-title");
											ee.removeAttribute("loading");
						
										});
						
					}, false );
		
			e1e.addEventListener( "mouseout", function( event ){

						var ee = document.getElementById("image-tooltip");
						ee.style.opacity = 0;
						ee.style.display = false;
						var ii = document.getElementById("preview-image");
						ii.src = '';
						var ee = document.getElementById("rg3fbpz-title");
						ee.setAttribute("loading","1");
					
					}, false );

			// --  descr
			var e2 =  fbc("item_descr");
			e2.textContent = media.displayName;
			e2.title = media.title;

			// --  extension
			var e3 =  fbc("item_ext");
			var extClass = 'gta_downloader_icon_ic_list_other';
			
			switch ( media.ext )	{
				case "jpeg":
				case "jpg":   extClass = "gta_downloader_icon_ic_list_jpg";   break;
				case "gif":   extClass = "gta_downloader_icon_ic_list_gif";   break;
				case "png":   extClass = "gta_downloader_icon_ic_list_png";   break;
				case "bmp":   extClass = "gta_downloader_icon_ic_list_bmp";   break;
				case "ico":   extClass = "gta_downloader_icon_ic_list_ico";   break;
				case "svg":   extClass = "gta_downloader_icon_ic_list_svg";   break;
				default: 	  extClass = "gta_downloader_icon_ic_list_jpg";
			}
			e3.addClass(extClass);
			e3.title = media.ext ? media.ext : media.type;
			
			// -- select
			var e4 =  fbc("item_sel");
			if ( GetThemAll.Popup.isYoutubeUrl(media.url) && (mode == "video") )		{
				return null;
			}
			else if ( media.metod == "record" || media.metod == "stream" )		{
				e4.setAttribute('disabled', true);
			}
			else	{
				if ( media.vubor == 1) 	e4.checked = true;
								  else  e4.checked = false;
								  
				e4.addEventListener( "click", function( event ){

						var x = this.checked;
						var id = parseInt( this.getAttribute("item") );
						if (x)	{
							GetThemAll.Popup.setCheck_ListMedia( id, 1);
						}	
						else 	{
							GetThemAll.Popup.setCheck_ListMedia( id, 0);
							GetThemAll.Popup.clear_Flag_SelectAll(  );  // убрать метку select all
						}
								
					}, false );
			}					  
			
			e4.title = media.source;
			e4.setAttribute("item", media.id);			

			// -- size
			if ( media.metod == "download" )  {
				var e5 =  fbc("item_size");
				e5.parentNode.removeAttribute("hidden");
				e5.textContent = "";	
				
				if (media.size) 	{
					e5.textContent = GetThemAll.Popup.str_download_size(media.size);
				}
				else	{
					e5.setAttribute( "loading", 1 );
				
					GetThemAll.Utils.getSizeByUrl( media.url, function( size ){
					
														e5.removeAttribute( "loading" );
														if( size ) 	{
															GetThemAll.Utils.getActiveTab( function( tab ){		
																if (tab) GetThemAll.Storage.setData_Attribute( tab.id, media.id, "size", size );		
															});
														
															e5.textContent = GetThemAll.Popup.str_download_size( size );
														}
					
													} );				

				}
			}
			else   {

				if (media.status == 'start') 	{
					if (media.progressByte && media.progressByte>0) {
						fbc("item_size").textContent = GetThemAll.Popup.str_download_size(media.progressByte);
					}	
				}

			}	
			
			// -- download
			var e6 =  fbc("js-download-button");
			
			if ( e6 )		{
				GetThemAll.Popup.button_download(media.metod, media.status, e6);
				
				e6.setAttribute("item", media.id);		
				e6.addEventListener( "click", function( event ){
					var id = parseInt( this.getAttribute("item") );

					item.setAttribute("status", media.status == 'start' ? 'stop' : 'start');
					
					if (media.metod == "download") {
						GetThemAll.Popup.button_download(media.metod, media.status == 'start' ? 'stop' : 'start', e6)
					}
					else {	
						GetThemAll.Popup.button_download(media.metod, media.status == 'start' ? 'stop' : 'start', e6)
					}
					
					GetThemAll.Popup.DownloadOne(id);					
					
					event.stopPropagation();
				}, false );
			}		
			
			
			return item;
			
		}
		
		// ----------------------------------------------------   заполним строку иконками
		function buildThreadItemAlternative( media, mode ){
	
			function fbc( className ){
				return item.getElementsByClassName(className)[0];
			}
			
			var item = document.getElementById("download_icon_template").cloneNode( true );
			item.removeAttribute( "id" );
			item.setAttribute("item", media.id);			
			
			var img =  fbc("info_img");
			img.src = media.url;
			img.title = media.title;

			img.addEventListener( "click", function( event ){

							chrome.tabs.create({
												url: media.url,
												active: false
											});
								
					}, false );
					
			img.addEventListener( "contextmenu", function( event ){

							GetThemAll.Popup.Item_contextMenu( this.src, media.id );
			
						}, false );
					
			// -- select
			var e4 =  fbc("item_sel");
			if ( GetThemAll.Popup.isYoutubeUrl(media.url) && (mode == "video") )		{
				return null;
			}
			else	{
				if ( media.vubor == 1) 	e4.checked = true;
								  else  e4.checked = false;
								  
				e4.addEventListener( "click", function( event ){
						var x = this.checked;
						var id = parseInt( this.getAttribute("item") );
						if (x)	{
							GetThemAll.Popup.setCheck_ListMedia( id, 1);
						}	
						else 	{
							GetThemAll.Popup.setCheck_ListMedia( id, 0);
							GetThemAll.Popup.clear_Flag_SelectAll(  );  // убрать метку select all
						}
								
					}, false );
			}					  
			e4.title = media.source;
			e4.setAttribute("item", media.id);			
				
			// -- size
			var elem_size =  fbc("info_size");
			elem_size.parentNode.removeAttribute("hidden");
			elem_size.textContent = "";	
				
			if (media.size)	{
				elem_size.textContent = GetThemAll.Popup.str_download_size(media.size);
			}
			else	{
				elem_size.setAttribute( "loading", 1 );
			
				GetThemAll.Utils.getSizeByUrl( media.url, function( size ){
					
								elem_size.removeAttribute( "loading" );
								if( size )
								{
									GetThemAll.Utils.getActiveTab( function( tab ){		GetThemAll.Storage.setData_Attribute( tab.id, media.id, "size", size );		});
														
									elem_size.textContent = GetThemAll.Popup.str_download_size( size );
								}
					
							} );				
			}
					
			
		
			return item;
		}	
		
		// ----------------------------------------------------   
		this.show_count = function( counts ){

			if (counts.vimage > 0) {
				document.getElementById("vubor_images").textContent  = counts.vimage.toString();
				document.getElementById("vubor_images").style.display = 'inline-block';
			}
			else {
				document.getElementById("vubor_images").textContent  = '';
				document.getElementById("vubor_images").style.display = 'none';
			}	
			if (counts.image > 0) {
				document.getElementById("count_images").innerHTML  = '<span class="count">' + counts.image.toString() + '</span> '+
																	 '<span class="label">' + _("popup_tab_detected") + '</span>';
			}
			else {
				document.getElementById("count_images").textContent  = _("popup_tab_not_detected");
			}	
		
		}	
		
		// ----------------------------------------------------- 
		this.set_popup = function( e ){

			GetThemAll.Popup.set_popup( "image" );
			
			GetThemAll.Popup.box_Youtube();
			GetThemAll.Popup.repaintThreadsList();		
		
		}
		// -----------------------------------------------	
		
	}
	
	this.PopupImage = new PopupImage();
	
}).apply( GetThemAll );
