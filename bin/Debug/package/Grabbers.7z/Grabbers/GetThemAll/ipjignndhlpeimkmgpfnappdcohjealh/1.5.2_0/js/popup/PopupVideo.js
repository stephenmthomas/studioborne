(function(){
	
	var PopupVideo = function(){
		
		var self = this;
		
		const FILTER_VIDEO = { 
							'video_all':  {	title: 'All files' },
							'video_mp4':  {	title: 'mp4',  ext: ["mp4", "m4s"] },
							'video_flv':  {	title: 'flv',  ext: ["flv"] },
							'video_avi':  {	title: 'avi',  ext: ["avi"] },
							'video_webm': {	title: 'webm', ext: ["webm"] },
							'video_3gp':  {	title: '3gp',  ext: ["3gp"] },
							'video_mov':  {	title: 'mov',  ext: ["mov"] },
							'video_mp3':  {	title: 'mp3',  ext: ["mp3"] },
							'video_wav':  {	title: 'wav',  ext: ["wav"] },
							'video_mid':  {	title: 'mid',  ext: ["mid", "midi"] },
							};
							 
		const SHOW_TYPE = [ "audio", "video", "game" ];						
							 
		var current_group_id = null;
		var groupContainer = null;
		var enabledStream = true;
							 
		// ----------------------------------------------------- 
		this.buildFilters = function(  ){
			
			var block_link = document.getElementById("filter_videos").querySelector('.gta_downloader_filter_set_content');			
			for (var id in FILTER_VIDEO) {
				var item = document.createElement('div');
				item.setAttribute('class', 'gta_downloader_filter_item');
				item.innerHTML = '<label class="gta_downloader_check">'+
								 '	<input type="checkbox" id="filter_'+id+'" class="gta_downloader_check_element">'+
								 '	  <span class="gta_downloader_check_block"><i></i></span>'+
								 FILTER_VIDEO[id].title+ 
								 '</label>';
				block_link.appendChild(item);				
			}	
			
		}

		// ----------------------------------------------------- 
		this.repaint = function( threads ){

			current_group_id = 0;
			threads.forEach(function( thread ){
						buildThreadItem( thread, GetThemAll.Popup.mode );	
			});
		
		}
							 
		// ----------------------------------------------------- 
		this.repaintVideo = function( threads ){

			console.log(threads, GetThemAll.Popup.mode);

			var container = document.getElementById("download_item_container");
			threads.forEach(function( thread ){
					if ( SHOW_TYPE.indexOf( thread.type ) != -1) {
						var item = buildVideoItem( thread, GetThemAll.Popup.mode );	
						if (item) container.appendChild( item );				
					}	
			});
		
		}
							 
 		// ----------------------------------------------------   заполним строку
		this.filter_media = function( media ){

			if ( GetThemAll.Prefs.get( "gta.filter_video_all" ) == "false" )	{
				
				media = GetThemAll.Popup.filter_extensions( media, FILTER_VIDEO );
				
			}						
		
			return media;
		
		}	
		
		// ----------------------------------------------------   заполним строку
		function buildThreadItem( media, mode ){

			//console.log(media);	

			function fbc( className ){
				return item.getElementsByClassName(className)[0];
			}

			if (!media.url || media.url == "") return null;
			if (media.type == "remove") return null;

			var hash = media.hash;
			var id = media.id;
			var group_id = media.groupId;
			
			var item = null;
			
			if (current_group_id != group_id) {

				groupItem = document.getElementById('group_'+group_id);
				if ( !groupItem ) {
					groupItem = document.getElementById("download_template_group").cloneNode( true );
					groupItem.removeAttribute( "id" );
					groupItem.setAttribute( "id", 'group_'+group_id );
					groupItem.classList.add( "one-item" );
					
					set_group();
					
					var container = document.getElementById("download_item_container");
					container.appendChild( groupItem );
					
					var groupContent = groupItem.querySelector(".group_download_content");
					add_item( groupContent );
				}	
				else {
					set_group();
				}	

				current_group_id = group_id;
				groupContainer = groupItem.querySelector(".group_download_block");
			}
			else if (current_group_id == group_id && groupContainer) {
				var prnt = GetThemAll.Utils.closest(groupContainer, '.group-video');
				prnt.classList.remove( "one-item" );
				var cnt = prnt.querySelector('.group_download_count').querySelector('.count');
				var x = parseInt(cnt.textContent);
				cnt.textContent = (++x).toString();

				add_item( groupContainer );
			}	
			else {
				console.error('insert_element ', media.id, media.groupId)
			}
			
			
			// ------------------------
			function add_item( container ) {
			
				item = document.querySelector('[media-id="'+id+'"');
				if (!item) {
					var ln = document.createElement("div");
					ln.setAttribute("class", "line");
					container.appendChild( ln );
					
					item = document.getElementById("download_template_group_item").cloneNode( true );
					item.removeAttribute( "id" );
					item.setAttribute( "id", hash );
					item.setAttribute( "media-id", id );
					item.setAttribute( "media-type", media.metod );

					set_item(true, container);	
				
					container.appendChild( item );
				}
				else {
					set_item(false, container);
				}	
			
			}
			// ------------------------
			function set_group() {
			
				var elemUrl = groupItem.querySelector(".group_download_title");
				var elemThumb = groupItem.querySelector(".thumbnail");
				
				elemUrl.setAttribute( "source", media.source );
				elemUrl.textContent = media.displayName;	
				elemUrl.innerHTML = '<span class="stream-video-name">'+media.displayName+'</span>';
				if (media.metod == 'stream')  elemUrl.innerHTML += '<span class="stream-video">(Streams)</span>';	

				if (media.thumbnail) {
					var tmbImg = document.createElement("img");
					tmbImg.setAttribute("style", "width: 100%");
					tmbImg.setAttribute("src", media.thumbnail);
					elemThumb.appendChild(tmbImg);
					elemThumb.classList.add('thumbnail-active');
				}  
				else  {
					if ( media.tabUrl.indexOf('facebook.com') != -1) {
						var tmbImg = document.createElement("img");
						tmbImg.setAttribute("style", "width: 100px");
						tmbImg.setAttribute("src", "/images/thumbnail/facebook.png");
						elemThumb.appendChild(tmbImg);
					}
					else if ( media.ext.indexOf('mp3') != -1) {
						var tmbImg = document.createElement("img");
						tmbImg.setAttribute("style", "width: 100px");
						tmbImg.setAttribute("src", "/images/thumbnail/audio.png");
						elemThumb.appendChild(tmbImg);
					}	
					else {
						var tmbImg = document.createElement("img");
						tmbImg.setAttribute("style", "width: 100px");
						tmbImg.setAttribute("src", "/images/thumbnail/blank.png");
						elemThumb.appendChild(tmbImg);
					}
				}    
				
				var cnt = groupItem.querySelector(".group_download_count")
				cnt.querySelector('.count').textContent = '1';
			
			
			}
			// ------------------------
			function set_item( flag, container ) {

//console.log( flag, media );				
			
				var elemLabel = item.querySelector(".label");
				elemLabel.innerHTML = media.displayLabel;	
				if (media.metod == 'convert')  elemLabel.innerHTML += '<span class="stream-video">(Converts)</span>';	
				
				var btndDwnl = item.querySelector(".download_button");
				var textDwnl = item.querySelector(".text");
				var mediaFormat = item.querySelector(".media_format");
				var sizeDwnl = item.querySelector(".size");
				var procentDwnl = item.querySelector(".procent");
				
				if (media.metod == 'not') {
					
					textDwnl.textContent = 'Not Allowed';
					textDwnl.setAttribute('title', 'Click to read why it is disabled');
									
					function onClickNot( event ) {
									console.log('GetThemAll.Media.NotAllowed');
									var BG = chrome.extension.getBackgroundPage();
									BG.navigateMessageDisabled(3);
									event.stopPropagation();												
								}
								
					btndDwnl.setAttribute( "href", "#" );	
					if (flag) btndDwnl.addEventListener("click", onClickNot, false);	
					
					var copyElem = fbc("copyLink");	
					if (flag) copyElem.addEventListener( "click", onClickNot, false );
					
				}	
				else {

					if ( ['download', 'convert'].indexOf(media.metod) != -1) {
						if (media.status == 'stop') {  
							if( media.size )  {
								sizeDwnl.textContent = GetThemAll.Popup.str_download_size(media.size);
							}
						}
						else {
							sizeDwnl.textContent = GetThemAll.Popup.str_download_size(media.progressByte || media.size);
						}	
					}
					else if ( ['stream'].indexOf(media.metod) != -1) {
						if (media.status == 'start') {  
							sizeDwnl.textContent = GetThemAll.Popup.str_download_size(media.progressByte || media.size);
							procentDwnl.textContent = '('+media.progress.toString() + '%)';
						}	
					}
					
					GetThemAll.Popup.button_download(media.metod, media.status, item.querySelector(".js-download-button"));
					
					if ( ['stream', 'convert'].indexOf(media.metod) != -1 ) {
						if ( media.status == 'stop' && !enabledStream ) {
							btndDwnl.setAttribute( "disabled", true );	
							btndDwnl.setAttribute( "title", "You are already downloading streaming video. Please wait till it finishes." );	
						}
					}	

					function onClick( event ) {
									if ( this.getAttribute("disabled") )  return;
									GetThemAll.Media.clickDownload( id );
									event.stopPropagation();	
								}
								
					btndDwnl.setAttribute( "href", "#" );	
					if (flag) btndDwnl.addEventListener("click", onClick, false);	
					
					if (flag) {
						var copyElem = fbc("copyLink");	
						copyElem.addEventListener( "click", function( event ){
										GetThemAll.Utils.copyToClipboard( media.url );
										event.stopPropagation();
									}, false );
					}	
				}				
				
				if (flag) {
					var removeElem = fbc("removeLink");	
					removeElem.addEventListener( "click", function( event ){

									GetThemAll.Storage.removeItem( media.id );
									media.type = 'remove';
									count_videos
									var x = document.getElementById("count_videos").querySelector(".count").textContent;
									try {
										x = parseInt(x);
										x--;
									}
									catch(ex){};	
									document.getElementById("count_videos").querySelector(".count").textContent = x;
									
									var prnt = GetThemAll.Utils.closest(item, '.group-video');

									var el = item.previousElementSibling;
									if (el && el.classList.contains('line')) container.removeChild( el );
									container.removeChild( item );

									var cnt = prnt.querySelector('.group_download_count').querySelector('.count');
									var x = parseInt(cnt.textContent);
									cnt.textContent = (--x).toString();

									if (x == 1) prnt.classList.add( "one-item" );
									else if (x == 0)  document.getElementById("download_item_container").removeChild( prnt );

									event.stopPropagation();
								}, false );
				}				

			}
			
			return item;
			
		}
		
		// ----------------------------------------------------   
		this.show_count = function( counts ){


			if ( GetThemAll.Popup.is_youtube )	{
				document.getElementById("count_videos").textContent = _("popup_tab_not_detected");
				document.getElementById("vubor_videos").textContent  = '';
				document.getElementById("vubor_videos").style.display = 'none';
			}
			else {
				if (counts.vvideo > 0) {
					document.getElementById("vubor_videos").textContent  = counts.vvideo.toString();
					document.getElementById("vubor_videos").style.display = 'inline-block';
				}
				else {
					document.getElementById("vubor_videos").textContent  = '';
					document.getElementById("vubor_videos").style.display = 'none';
				}	
				if (counts.video > 0) {
					document.getElementById("count_videos").innerHTML  = '<span class="count">' + counts.video.toString() + '</span> '+
																		 '<span class="label">' + _("popup_tab_detected") + '</span>';
				}
				else {
					document.getElementById("count_videos").textContent  = _("popup_tab_not_detected");
				}	
			}
		
		}	
		
		// ----------------------------------------------------- 
		this.set_popup = function( e ){

			if (e.ctrlKey || e.altKey) {
				GetThemAll.Popup.set_popup( "video" );
			}
			else {	
				GetThemAll.Popup.set_popup( "media" );
			}	
			
			GetThemAll.Popup.box_Youtube();
			GetThemAll.Popup.repaintThreadsList();		
		
			/*if (GetThemAll.Popup.isYoutubeUrl(currentTab.url)) {
				x = 'link';
				var BG = chrome.extension.getBackgroundPage();
				BG.navigateMessageDisabled();
			}
			else {	
				GetThemAll.Popup.set_popup( "video" );
				document.getElementById("head_size").style.display="block";
				GetThemAll.Popup.box_Youtube();
				GetThemAll.Popup.repaintThreadsList();	
			}*/	
			e.stopPropagation();
		}
		
		// ----------------------------------------------------- 
		this.set_status = function( request ){
			
			var item = document.querySelector( '[media-id="'+request.id+'"]' );
			if (!item) return;

			item.querySelector(".procent").textContent = "" 
			
 			if ( request.status )  {
				if (request.status == 'playlist') {
					item.querySelector(".size").textContent = 'preparing...';
				}
				else if (request.status == 'saving') {
					item.querySelector(".size").textContent = 'saving';
				}
				else {	
					GetThemAll.Popup.button_download(request.metod, request.status, item.querySelector(".js-download-button"));
				
					item.querySelector(".size").textContent = GetThemAll.Popup.str_download_size( request.size );
				}	
			}
			 
			// исправим размер файла
			if (request.size) {
				item.querySelector(".size").removeAttribute( "loading" );
				item.querySelector(".size").textContent = GetThemAll.Popup.str_download_size( request.size );
			}

			// прогресс
			if ( request.progress )  {
				item.querySelector(".procent").textContent = '('+request.progress.toString() + '%)';
			}
			if (request.byte)	{
				item.querySelector(".size").textContent = GetThemAll.Popup.str_download_size(request.byte);
			}
			

		}

		// ----------------------------------------------------   заполним строку
		function buildVideoItem( media, mode ){

			//console.log(media);		
			
			function fbc( className ){
				return item.getElementsByClassName(className)[0];
			}

			if (!media.url || media.url == "") return null;
			
			var item = null;
			
			var item = document.querySelector('[item="'+media.id+'"');
			if (item) {		// исправим
				// --  url
				var e1 =  fbc("item_url");
				e1.textContent = media.url;			
				e1.title = media.url;
				e1.href = media.url;

				// --  descr
				var e2 =  fbc("item_descr");
				e2.textContent = media.displayName;
				e2.title = media.title;
			
				return;
			}
			
			item = document.getElementById("download_item_template").cloneNode( true );
			item.removeAttribute( "id" );
			item.setAttribute("item", media.id);
			item.setAttribute("status", media.status);

			if (media.zip>0) item.setAttribute("zip", media.zip);	
			
			// --  url
			var e1 =  fbc("item_url");
			e1.textContent = media.url;			
			e1.title = media.url;
			e1.href = media.url;
			
			e1.addEventListener( "contextmenu", function( event ){

							GetThemAll.Popup.Item_contextMenu( this.title, media.id );
			
						}, false ); 
						
			// --  descr
			var e2 =  fbc("item_descr");
			e2.textContent = media.displayName;
			e2.title = media.title;

			// --  extension
			var e3 =  fbc("item_ext");
			var extClass = 'gta_downloader_icon_ic_list_other';
			
			switch ( media.ext )    {
					case "3gp":   extClass = "gta_downloader_icon_ic_list_3gp";   break;
					case "flv":   extClass = "gta_downloader_icon_ic_list_flv";   break;
					case "mp4":   extClass = "gta_downloader_icon_ic_list_mp4";   break;
					case "swf":   extClass = "gta_downloader_icon_ic_list_swf";   break;
					case "webm":  extClass = "gta_downloader_icon_ic_list_webm";  break;
					default: 	  extClass = "gta_downloader_icon_ic_list_video";
			}
			e3.addClass(extClass);
			e3.title = media.ext ? media.ext : media.type;
			
			// -- select
			var e4 =  fbc("item_sel");
			if ( GetThemAll.Popup.isYoutubeUrl(media.url) && (mode == "video") )		{
				return null;
			}
			else if ( media.metod == "record" || media.metod == "stream" )		{
				e4.setAttribute('disabled', true);
			}
			else	{
				if ( media.vubor == 1) 	e4.checked = true;
								  else  e4.checked = false;
								  
				e4.addEventListener( "click", function( event ){

						var x = this.checked;
						var id = parseInt( this.getAttribute("item") );
						if (x)	{
							GetThemAll.Popup.setCheck_ListMedia( id, 1);
						}	
						else 	{
							GetThemAll.Popup.setCheck_ListMedia( id, 0);
							GetThemAll.Popup.clear_Flag_SelectAll(  );  // убрать метку select all
						}
								
					}, false );
			}					  
			
			e4.title = media.source;
			e4.setAttribute("item", media.id);			

			// -- size
			if ( media.metod == "download" )  {
				var e5 =  fbc("item_size");
				e5.parentNode.removeAttribute("hidden");
				e5.textContent = "";	
				
				if (media.size) 	{
					e5.textContent = GetThemAll.Popup.str_download_size(media.size);
				}
				else	{
					e5.setAttribute( "loading", 1 );
				
					GetThemAll.Utils.getSizeByUrl( media.url, function( size ){
					
														e5.removeAttribute( "loading" );
														if( size ) 	{
															GetThemAll.Utils.getActiveTab( function( tab ){		
																if (tab) GetThemAll.Storage.setData_Attribute( tab.id, media.id, "size", size );		
															});
														
															e5.textContent = GetThemAll.Popup.str_download_size( size );
														}
					
													} );				

				}
			}
			else   {

				if (media.status == 'start') 	{
					if (media.progressByte && media.progressByte>0) {
						fbc("item_size").textContent = GetThemAll.Popup.str_download_size(media.progressByte);
					}	
				}

			}	
			
			// -- download
			var e6 =  fbc("js-download-button");
			
			if ( e6 )		{
				GetThemAll.Popup.button_download(media.metod, media.status, e6);
				
				e6.setAttribute("item", media.id);		
				e6.addEventListener( "click", function( event ){
					var id = parseInt( this.getAttribute("item") );

					item.setAttribute("status", media.status == 'start' ? 'stop' : 'start');
					
					if (media.metod == "download") {
						GetThemAll.Popup.button_download(media.metod, media.status == 'start' ? 'stop' : 'start', e6)
					}
					else {	
						GetThemAll.Popup.button_download(media.metod, media.status == 'start' ? 'stop' : 'start', e6)
					}
					
					GetThemAll.Popup.DownloadOne(id);					
					
					event.stopPropagation();
				}, false );
			}		
			
			
			return item;
			
		}

		// -----------------------------------------------	
		
	}
	
	this.PopupVideo = new PopupVideo();
	
}).apply( GetThemAll );
