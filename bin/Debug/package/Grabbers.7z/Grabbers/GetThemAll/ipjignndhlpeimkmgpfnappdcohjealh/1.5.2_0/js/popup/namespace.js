var GetThemAll = {
	noYoutube: chrome.extension.getBackgroundPage().GetThemAll.noYoutube
};