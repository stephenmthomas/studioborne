(function(){
	
	var Bootstrap = function(){		
		
		var self = this;
		
		// ====================================================================	
		this.listSegment = function( arr, params ){

			var list = [];

			var o = { fragPos: 0,
					  boxSize: 0,  
					  boxType: ''
					};

			self.ReadBoxHeader(arr, o);	

			self.ParseBootstrapBox(arr, o, params);
			
			var segNum  = params.segStart;
			var fragNum = params.fragStart;
			var lastFrag = fragNum;
			var firstFragment  = params.fragTable[0];
			
			while (fragNum < params.fragCount) {
				fragNum = fragNum + 1;
				var segNum = GetSegmentFromFragment(fragNum, params);
				list.push( params.uri + "Seg" + segNum + "-Frag" + fragNum	);
			}
			
			return list;

		}	
		
		// ====================================================================	
		//  opt: fragPos 
		//       boxType 
		//       boxSize
		//
		this.ReadBoxHeader = function( arr, opt ){

			if (!arr || arr.length==0) return;
		
			opt.boxSize = GetThemAll.jspack.ReadInt32(arr, opt.fragPos);
			opt.boxType = GetThemAll.jspack.bytesToString(arr.slice(opt.fragPos + 4, opt.fragPos + 8));
			
			if (opt.boxSize == 1)   {
				opt.boxSize = GetThemAll.jspack.ReadInt64(arr, opt.fragPos + 8) - 16;
				opt.fragPos += 16;
			}
			else  {
				opt.boxSize -= 8;
				opt.fragPos += 8;
			}
			if (opt.boxSize <= 0) opt.boxSize = 0;
		}	
					   
		// -----------------------------------------------------------
		//  opt: fragPos 
		//       boxType 
		//       boxSize
		//
		this.ParseBootstrapBox = function( arr, opt, params ){

			if (!arr || arr.length==0) return;
			
			params.version          = GetThemAll.jspack.ReadByte(arr, opt.fragPos);
			params.flags            = GetThemAll.jspack.ReadInt24(arr, opt.fragPos + 1);
			params.bootstrapVersion = GetThemAll.jspack.ReadInt32(arr, opt.fragPos + 4);
			var bt               = GetThemAll.jspack.ReadByte(arr, opt.fragPos + 8);
			params.profile          = (bt & 0xC0) >> 6;
			
			if ((bt & 0x20) >> 5)  {
				params.live     = true;
				params.metadata = false;
			}
			params.update = (bt & 0x10) >> 4;
			if (!params.update)  {
				params.segTable  = [];
				params.fragTable = [];
			}
			params.timescale           = GetThemAll.jspack.ReadInt32(arr, opt.fragPos + 9);
			params.currentMediaTime    = GetThemAll.jspack.ReadInt64(arr, opt.fragPos + 13);
			params.smpteTimeCodeOffset = GetThemAll.jspack.ReadInt64(arr, opt.fragPos + 21);
			opt.fragPos += 29;
			var x = GetThemAll.jspack.ReadString(arr, opt.fragPos);
			params.movieIdentifier = x.str;
			opt.fragPos = x.pos;	
			params.serverEntryCount = GetThemAll.jspack.ReadByte(arr, opt.fragPos++);
			
			params.serverEntryTable = [];
			for (var i = 0; i<params.serverEntryCount; i++)  {
				var x =  GetThemAll.jspack.ReadString(arr, opt.fragPos);
				opt.fragPos = x.pos;
				params.serverEntryTable.push(x.str)
			}	
			
			params.qualityEntryCount = GetThemAll.jspack.ReadByte(arr, opt.fragPos++);
			params.qualityEntryTable = [];
			for (var i=0; i<params.qualityEntryCount; i++) {
				var x =  GetThemAll.jspack.ReadString(arr, opt.fragPos);
				opt.fragPos = x.pos;
				params.qualityEntryTable.push(x.str);
			}	
			
			var x =  GetThemAll.jspack.ReadString(arr, opt.fragPos);
			opt.fragPos = x.pos;
			params.drmData = x.str;
			
			var x =  GetThemAll.jspack.ReadString(arr, opt.fragPos);
			opt.fragPos = x.pos;
			params.metadata = x.str;
  
			params.segRunTableCount = GetThemAll.jspack.ReadByte(arr, opt.fragPos++);
			
			params.segTable         = [];
			for (var i=0; i<params.segRunTableCount; i++)     {
				self.ReadBoxHeader(arr, opt);
				if (opt.boxType == "asrt") {
					params.segTable =  ParseAsrtBox(arr, opt.fragPos);
				}	
				opt.fragPos += opt.boxSize;
			}
			
			params.fragRunTableCount = GetThemAll.jspack.ReadByte(arr, opt.fragPos++);
			params.fragTable         = [];
			for (var i=0; i<params.fragRunTableCount; i++)  {
				self.ReadBoxHeader(arr, opt);
				if (opt.boxType == "afrt") {
					params.fragTable = ParseAfrtBox(arr, opt.fragPos);
				}	
				opt.fragPos += opt.boxSize;
			}
			
			self.ParseSegAndFragTable( params );
			
			
			// -----------------------------
			function ParseAsrtBox(asrt, pos)	{
				
				if ( !asrt || asrt.length==0) return;
				
				var segTable          = [];
				var version           = GetThemAll.jspack.ReadByte(asrt, pos);
				var flags             = GetThemAll.jspack.ReadInt24(asrt, pos + 1);
				var qualityEntryCount = GetThemAll.jspack.ReadByte(asrt, pos + 4);
				
				pos += 5;
				var qualitySegmentUrlModifiers = [];
				for (var i=0; i<qualityEntryCount; i++) {
					var x =  GetThemAll.jspack.ReadString(asrt, pos);
					pos = x.pos;
					qualitySegmentUrlModifiers.push( x.str );
				}
				
				var segCount = GetThemAll.jspack.ReadInt32(asrt, pos);
				
				pos += 4;
				for (var i=0; i<segCount; i++)  {
					var firstSegment = GetThemAll.jspack.ReadInt32(asrt, pos);
					var fragmentsPerSegment = GetThemAll.jspack.ReadInt32(asrt, pos + 4);
					segTable.push({  firstSegment: firstSegment,
									 fragmentsPerSegment: fragmentsPerSegment,
								  });
					pos += 8;
				}
				
				return segTable;  
			}
			
			// -----------------------------
			function ParseAfrtBox(afrt, pos)		{
				
				if ( !afrt || afrt.length==0 ) return;
				
				var fragTable         = [];
				var version           = GetThemAll.jspack.ReadByte(afrt, pos);
				var flags             = GetThemAll.jspack.ReadInt24(afrt, pos + 1);
				var timescale         = GetThemAll.jspack.ReadInt32(afrt, pos + 4);
				var qualityEntryCount = GetThemAll.jspack.ReadByte(afrt, pos + 8);
				pos += 9;
				
				var qualitySegmentUrlModifiers = [];
				for (var i=0; i<qualityEntryCount; i++) {
					var x =  GetThemAll.jspack.ReadString(afrt, pos);
					pos = x.pos;
					qualitySegmentUrlModifiers.push( x.str );
				}
				
				var fragEntries = GetThemAll.jspack.ReadInt32(afrt, pos);
				pos += 4;
				
				for (var i = 0; i<fragEntries; i++)	{
					var firstFragment = GetThemAll.jspack.ReadInt32(afrt, pos);
					var firstFragmentTimestamp = GetThemAll.jspack.ReadInt64(afrt, pos + 4);
					var fragmentDuration       = GetThemAll.jspack.ReadInt32(afrt, pos + 12);
					var discontinuityIndicator = "";
					
					pos += 16;
					
					if (fragmentDuration == 0)		discontinuityIndicator = GetThemAll.jspack.ReadByte(afrt, pos++);
					
					fragTable.push({  firstFragment: firstFragment,
									  firstFragmentTimestamp: parseInt(firstFragmentTimestamp),
									  fragmentDuration: fragmentDuration,
									  discontinuityIndicator: discontinuityIndicator  });
				}
				  
				return fragTable;
			}
		
		}	
					   
		// -----------------------------------------------------------
		this.ParseSegAndFragTable = function( params ){

			var firstSegment  = params.segTable[0];
			var lastSegment   = params.segTable[params.segTable.length-1];

			var firstFragment = params.fragTable[0];
			var lastFragment  = params.fragTable[params.fragTable.length-1];

			if (lastFragment['fragmentDuration'] == 0 && lastFragment['discontinuityIndicator'] == 0)   {
				params.live = false;
				params.fragTable.pop();
				lastFragment  = params.fragTable[params.fragTable.length-1];
			}

			var invalidFragCount = false;
			var prev = params.segTable[0];
			params.fragCount  = prev['fragmentsPerSegment'];
			for (var i=1; i<params.segTable.length; i++) {
				params.fragCount += (params.segTable[i]['firstSegment'] - params.segTable[i-1]['firstSegment'] - 1) * params.segTable[i-1]['fragmentsPerSegment'];
				params.fragCount += params.segTable[i]['fragmentsPerSegment'];
			}	
			if (!(params.fragCount & 0x80000000))  {
				params.fragCount += firstFragment['firstFragment'] - 1;
			}  
			if (params.fragCount & 0x80000000)    {
				params.fragCount  = 0;
				var invalidFragCount = true;
			}
			if (params.fragCount < lastFragment['firstFragment'])   { 
				params.fragCount = lastFragment['firstFragment'];
			}	  
			
			if (params.live)  {
				params.segStart = lastSegment['firstSegment'];
			}	
			else  {
				params.segStart = firstSegment['firstSegment'];
			}
			if (params.segStart < 1) {
				params.segStart = 1;
			}

			if (params.live && !invalidFragCount) {
				params.fragStart = params.fragCount - 2;
			}	
			else  {
				params.fragStart = firstFragment['firstFragment'] - 1;
			}	
			if (params.fragStart < 0) {
				params.fragStart = 0;
			}	

		}	
		
		// -----------------------------			
		function GetSegmentFromFragment(fragNum, params)		{
			
			var firstSegment  = params.segTable[0];
			var lastSegment   = params.segTable[params.segTable.length-1];

			var firstFragment = params.fragTable[0];
			var lastFragment  = params.fragTable[params.fragTable.length-1];
			
			if (params.segTable.length == 1) {
				return firstSegment['firstSegment'];
			}	
			else {
				var prev  = firstSegment['firstSegment'];
				var start = firstFragment['firstFragment'];
				for (var i = firstSegment['firstSegment']; i <= lastSegment['firstSegment']; i++)  {
					if (params.segTable[i]) {
						var seg = params.segTable[i];
					}	  
					else {
						var seg = prev;
					}	
					var end = start + seg['fragmentsPerSegment'];
					if ( fragNum >= start && fragNum < end) {
						return i;
					}	  
					prev  = seg;
					start = end;
				}
			}
			return lastSegment['firstSegment'];
		}

		// -----------------------------			
		this.WriteMetadata = function( meta ){
			if (meta)	{
				
				var flvHeader = [0x46, 0x4c, 0x56, 0x01, 0x05, 0x00, 0x00, 0x00, 0x09, 0x00, 0x00, 0x00, 0x00];
				var flvHeaderLen = flvHeader.length;
				var tagHeaderLen = 11;
				var prevTagSize = 4;
				var metadataSize = meta.length;
				metadata = [];
				
				GetThemAll.jspack.WriteByte(metadata, 0, 0x12);
				GetThemAll.jspack.WriteInt24(metadata, 1, metadataSize);
				GetThemAll.jspack.WriteInt24(metadata, 4, 0);
				GetThemAll.jspack.WriteInt32(metadata, 7, 0);
				
				for (var i=0; i<metadataSize; i++)  metadata.push(meta[i]);
				
				GetThemAll.jspack.WriteByte(metadata, tagHeaderLen + metadataSize - 1, 0x09);
				GetThemAll.jspack.WriteInt32(metadata, tagHeaderLen + metadataSize, tagHeaderLen + metadataSize);
				
				for (var i=flvHeaderLen-1; i>=0; i--)	metadata.unshift(flvHeader[i]);  
				
				metadata.length = flvHeaderLen + tagHeaderLen + metadataSize + prevTagSize;
				
				return GetThemAll.jspack.bytesToString(metadata);
			}
			return false;
		}
		
		// -----------------------------			
		this.decodeAMF = function( data ){

			try {
				var values = [];
				var offset = 0;
				while(offset>=0 && offset<data.length) {
					var ret = DecodeValue(data, offset);
					values.push(ret.value);
					offset = ret.offset;
				}
				return values;
			} catch(e) {
				console.error("decode error",e.message || e);
				return null;
			}
		}

		function DecodeValue(data, offset, type) {
			if(typeof type=="undefined") {
				if(offset>=data.length) throw new Error("End of structure");
				type = data[offset];
			}

			switch(type) {
				case 0x02: // string
					var length = GetThemAll.jspack.ReadInt16(data,offset+1);
					var string = String.fromCharCode.apply(null, data.slice(offset+3,offset+3+length));
					return {
						offset: offset+3+length,
						value: string,
					}
				case 0x03: // anonymous
					var container = {};
					offset += 1;
					while(GetThemAll.jspack.ReadInt24(data,offset)!=0x09) {
						var ret = DecodeValue(data,offset-1,0x02);
						var name = ret.value;
						offset = ret.offset;
						ret = DecodeValue(data,offset);
						var value = ret.value;
						offset = ret.offset;
						container[name] = value;
					}
					return {
						offset: offset+3,
						value: container,
					};
					break;
				case 0x08: // object
					var count = GetThemAll.jspack.ReadInt32(data,offset+1);
					var container = {};
					offset += 5;
					while(GetThemAll.jspack.ReadInt24(data,offset)!=0x09) {
						var ret = DecodeValue(data, offset-1, 0x02);
						var name = ret.value;
						offset = ret.offset;
						ret = DecodeValue(data, offset);
						var value = ret.value;
						offset = ret.offset;
						container[name] = value;
					}
					return {
						offset: offset+3,
						value: container,
					};
				case 0x0A:
					var count = GetThemAll.jspack.ReadInt32(data,offset+1);
					var container = [];
					offset += 5;
					for(var i=0;i<count;i++) {
						var ret = DecodeValue(data,offset);
						var value = ret.value;
						offset = ret.offset;
						container.push(value);
					}
					return {
						offset: offset,
						value: container,
					};
				case 0x00: // number
					var number = GetThemAll.jspack.ReadDouble(data,offset+1);
					return {
						offset: offset+9,
						value: number,
					};
				case 0x01: // boolean
					return {
						offset: offset+2,
						value: !!data[offset+1],
					}
					break;
				default:
					throw new Error("AMF not supported type 0x"+type.toString(16));
			}


		}    

		// ====================================================================	
		const AUDIO = 0x08;
		const VIDEO = 0x09;
		const AKAMAI_ENC_AUDIO = 0x0A;
		const AKAMAI_ENC_VIDEO = 0x0B;
		const SCRIPT_DATA = 0x12;
		
		this.DecodeFragment = function( frag ){

			console.log('DecodeFragment: ', frag);
			
				try {

					var ad       = null,
						flvFile  = null,
						flvWrite = true,
						flvData  = null,
						flvTag   = "",
						packetTS = 0,
						packetType = '',
						packetSize = 0,
						fragLen  = frag.byteLength;
						
					var o = { fragPos: 0,	boxSize: 0,  boxType: ''	};

					var crypt = {};        

					while (o.fragPos < fragLen)  {
						self.ReadBoxHeader(frag, o);
						if (o.boxType == "mdat") {
							fragLen = o.fragPos + o.boxSize;
							break;
						}
						o.fragPos += o.boxSize;
					}

					while (o.fragPos < fragLen)  {

						packetType = GetThemAll.jspack.ReadByte(frag, o.fragPos);
						packetSize = GetThemAll.jspack.ReadInt24(frag, o.fragPos + 1);
						packetTS   = GetThemAll.jspack.ReadInt24(frag, o.fragPos + 4);
						packetTS   = packetTS | (GetThemAll.jspack.ReadByte(frag, o.fragPos + 7) << 24);
						if (packetTS & 0x80000000)  packetTS &= 0x7FFFFFFF;
						
						var totalTagLen = tagHeaderLen + packetSize + prevTagSize;
						var flvTag     = frag.slice(o.fragPos, o.fragPos + totalTagLen);
						
						if ((packetType == AKAMAI_ENC_AUDIO) || (packetType == AKAMAI_ENC_VIDEO))   {
							flvData = GetThemAll.jspack.concat(flvData, flvTag);
						}
						else {
							flvData = GetThemAll.jspack.concat(flvData, flvTag);
						}

						o.fragPos += totalTagLen;
					} 


					durationFrag = parseInt(packetTS / 1000);

					return flvData || [];
				}
				catch(ex) {
					console.error('ERROR: STREAMER.DecodeFragment: ', ex);
					return frag;
				}    

		}	

	};
	
	this.Bootstrap = new Bootstrap();
	
}).apply( GetThemAll );
