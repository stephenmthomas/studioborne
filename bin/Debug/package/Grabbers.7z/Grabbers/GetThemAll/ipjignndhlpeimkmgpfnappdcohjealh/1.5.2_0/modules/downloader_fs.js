if (window == chrome.extension.getBackgroundPage()) {
	
	(function(){
		
		const DEBUG = false;
		const MAX_LOAD_FILE = 3;
		const LOAD_TIMEOUT = 50000;  // 100сек
	
		// ======================================================================
		var DownloaderFile_FileSystem = function(options) {
			
			var that = this;
			
			var state = 0;
			var url = options.url;
			var name = options.name;
			var ext = options.ext;
			var type = null;
			
			var xhr = null;
			var timer = null;
			
			var filename;
			var size = 0;
			
			isRun = false;
				
			// ------------------------------------------------------------------	
			this.start = function(finish) {
				
				if (DEBUG) console.log('DownloaderFile_FileSystem.start', options);
				
				filename = name + (ext ? '.'+ext : '');
				
				state = 1;
				
				xhr = GetThemAll.FileSystem.request( url, function(rez){ 
				
					if (DEBUG) console.log(filename, ':', rez);
				
					if (rez.error) {
						console.log('-----ERROR-----');
						state = 9;
						finish( false );
					}
					else {
						state = 2;
						size = rez.stream.byteLength;	
						type = rez.type;
						GetThemAll.FileSystem.createFile(filename, new Blob([rez.stream], {type: type}), function(){ 
						
							state = 3;
							finish( filename );
							
						});
					}
					xhr = null;
					clearTimeout( timer );
					timer = null;
				});
				
				timer = setTimeout(function () { 
				
					state = 8;	
					xhr.abort();
					xhr = null;
					clearTimeout( timer );
					timer = null;
					finish( false );
							
				}, LOAD_TIMEOUT);
				
				
			}

			
			// ------------------------------------------------------------------	
			this.stop = function() {

				if (DEBUG) console.log('DownloaderFile_FileSystem.stop');
							
				if (xhr) xhr.abort();

			}	
			
			// ------------------------------------------------------------------	
			this.getState = function() {
				return state;
			}	
			this.setState = function( st ) {
				state = st;
			}	
			// ------------------------------------------------------------------	
			this.getFile = function() {
				return { name: filename, 
						 fileName: options.filename,
						 downloadName: options.downloadName,
						 ext: ext,
						 type: type	};
			}	
			// ------------------------------------------------------------------	
			this.getSize = function() {
				return size;
			}	

			
		}
	
		// ======================================================================
		var DownloaderWorker_FileSystem = function() {

			var isRun = false,
				isSave = false,
				isEnd = false;
			
			var funcMessage = null;
			var funcFinish = null;
			
			var fileName = "video";
			var fileExt = "mp4";
			var downloadName = "media";
			var options = {};
			
			var listFiles = null;  
			
			var countLoad = 0,
				countTSFiles = 0,
				sizeOfVideo = 0;
				
			var file = {};	
			var queue=0;
			
			var blockStartReadTS = 0;

			// ---------------------------
			this.start = function(params, onMessage, onFinish) {

				if (DEBUG) console.log('DownloaderWorker_FileSystem.start', params);
				
				isRun = true;
				
				funcMessage = onMessage;
				funcFinish = onFinish;
				
				listFiles = params.list;
				fileName = GetThemAll.FileSystem.Unique( );
				
				countTSFiles = listFiles.length;
				
				var jj = 0;
				
				for(var j = 0; j < listFiles.length; j++)  {

					var filename = fileName + '_' + (++jj).toString();
					
					var pp = { url: listFiles[j].url,
							   name: filename,
							   filename: listFiles[j].filename,
							   downloadName: listFiles[j].downloadName,
							   ext: listFiles[j].ext,
						     };

					file[jj] = new DownloaderFile_FileSystem(pp);
				}
				
				load()
				

			};
			
			// ---------------------------
			function load() {
			
				if (DEBUG) console.log( 'load     queue:', queue );

				if ( queue < MAX_LOAD_FILE && blockStartReadTS == 0) {
				
					blockStartReadTS = 1;
					
					for ( var num in file ) {
						
						if (isRun && file[num].getState()==0)      	{
						
							file[num].start( fragment_finish );
								
							queue++;
							
							if (queue >= MAX_LOAD_FILE)  {  // очеред заполнили
								blockStartReadTS = 0;
								return;
							}	
						}
					}	
				}
			
			
			}
			
			// -------------------------------------------------------------
			function fragment_finish( fn ) {
				
				if (DEBUG) console.log( 'fragment_finish:  ', fn );
				
				queue--;
			
				countLoad = 0;
				sizeOfVideo = 0;
				isEnd = true;
				for ( var num in file ) {
					var st = file[num].getState();	
					if ( st <= 2)  {		// есть не обработанные
						isEnd = false;
					}	
					if ( st == 3)  {		
						countLoad++;
						sizeOfVideo += file[num].getSize();
					}	
				}	
				
				funcMessage({'msg': 'load', size: sizeOfVideo, count: countLoad, total: countTSFiles });
				
				// дальнейшие действия
				if (isEnd || !isRun ) {
					finish();
					return;
				}
				
				if ( isRun ) {
					load();
				}
				
			}

			// -------------------------------------------------------------
			function finish( fn ) {

				var list = [];
				for ( var num in file ) {
					var st = file[num].getState();	
					if ( st == 3)  {		// есть не обработанные
						list.push(file[num].getFile());
					}	
				}	
			
				funcFinish(list);

			}
			
			// ---------------------------
			this.stop = function() {

				if (DEBUG) console.log( 'DownloaderWorker_FileSystem.stop' );
				
				isRun = false;
				
				for (var k in file)  file[k].stop();
				
				
			};



		}
		
		// ======================================================================
		var Downloader_FileSystem = function(){		
		
			var workers = {};
			var error;
			
			var id = 0;
		
			// -------------------------------------------------------------------
			this.start = function( params, callbackMessage, callbackFinish ){
				
				id++;
				if (DEBUG) console.log('DownloaderFS.start', id, params);
				
				workers[id] = new DownloaderWorker_FileSystem();

				workers[id].start( params,
									function(msg) {         // onMessage
										console.log(msg);
										callbackMessage(msg);
									},
									function(rez){
										callbackFinish(rez);
										delete workers[id];
									}); 

				return id;
				
				
			}
			
			// -------------------------------------------------------------------
			this.stop = function( id, callback ){
				
				if (DEBUG) console.log('DownloaderFS.stop', id);
				
				workers[id].stop();
				
			}

		}	
		
		this.DownloaderFS = new Downloader_FileSystem();
		
	}).apply(GetThemAll);
}
else{
	GetThemAll.DownloaderFS = chrome.extension.getBackgroundPage().GetThemAll.DownloaderFS;
}

