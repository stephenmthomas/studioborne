if (window == chrome.extension.getBackgroundPage()) {
	
	(function(){

		const DEBUG = false;
		
		// ======================================================================
		var StreamWorker = function(hash) {
			
			const MAX_STREAM_DOWNLOAD = 5;
			const MIN_STREAM_DOWNLOAD = 2;
			const LOAD_STREAM_TIMEOUT = 300000;  // 5мин

			const EXT_PATTERN = new RegExp("\\.([a-z0-9]{1,5})(?:\\?|#|$)", "i");
			const NAME_PATTERN = new RegExp("/([^/]+?)(?:\\.([a-z0-9]{1,5}))?(?:\\?|#|$)", "i");

			var isRun = false,
				isSave = false,
				isEnd = false,
				saveInitSector = true;				
			
			var funcMessage = null;
			var funcFinish = null;
			
			var fileName = "video";
			var fileExt = "mp4";
			var file_name = "video.mp4";
			var downloadName = "media";
			var options = {};
			
			var duration, runTime, concatByte;

			var countLoad = 0,
				countTSFiles = 0,
				sizeOfVideo = 0,
				startIndex = 0;
			
			var hash,
				url,
				playlist, 
				initSector = null,
				paramsBootstrap = null,	
				paramsMetadata = null,
				queue=0,
				file = [];

			var blockStartReadTS = 0;
			var coursePlaylist = null;

			const AUDIO = 0x08;
			const VIDEO = 0x09;
			const AKAMAI_ENC_AUDIO = 0x0A;
			const AKAMAI_ENC_VIDEO = 0x0B;
			const SCRIPT_DATA = 0x12;

			const tagHeaderLen = 11;
			const prevTagSize = 4;
			
			var baseUrl = null;
			
			var lastFileNumber = 0;
			
			this.start = function(hh, media, onMessage, onFinish) {

				if (DEBUG) console.log('--start--', hh, media);
				
				isRun = true;
				
				funcMessage = onMessage;
				funcFinish = onFinish;
				
				if (media.params)  options = media.params;
				
				if (options.init)  		initSector = options.init;
				if (options.bootstrap)  paramsBootstrap = options.bootstrap; 
				if (options.metadata)   paramsMetadata = options.metadata; 
				
				queue = 0;
				hash = media.hash;
				url = media.url;
				playlist = media.playlist || media.url;
				
				fileName = GetThemAll.FileSystem.Unique( );
				
				fileExt = media.ext;
				downloadName = media.downloadName;
				file_name = fileName + '.' + fileExt;
				
				funcMessage({'msg': 'playlist', 'hash': hash });
				
				load_playlist( function( list, met ) {
					
					for(var j = 0; j < list.length; j++)  {
						file.push( { index: j,
									 url: list[j].url,	   
									 name: list[j].filename,
									 state: 0,
									 stream:  null } );
					}	
					
					countTSFiles = list.length;
					
					createFile(function(){
				
						load();
				
					});
					
					
				}); 
				
			};

			// ---------------------------
			this.stop = function() {

				if (DEBUG) console.log( 'STREAMER.stop' );
				
				isRun = false;
				
			};
			
			// ---------------------------
			function load_playlist( callback) {
				
				if (DEBUG) console.log( 'StreamerWorker.load_playlist', playlist );
				
				var metod = null;
				
				if ( typeof playlist == 'object' ) {

					metod = 'playlist';
					
					var list = [];
				
					for(var j = 0; j < playlist.length; j++)  {
						list.push({ url: playlist[j],
									filename: fileName + '_' + getFileNumber()	
								 }); 
					}

					callback( list, metod );
					return;	
				}	
				
				if ( typeof playlist == 'string' ) {

					metod = 'playlist';
					
					loadText( playlist, function(list){ 
						callback( list, metod );
					});
				}	
				
				// -----------------------------------
				function loadText( url, callback ) {	
				
					if (DEBUG) console.log('StreamPlaylist.loadText', url );	
					
					if ( !url ) return callback( null );
				
					var domain = null, host = url, prot = "", search = null;
					var x = GetThemAll.Utils.parse_URL(url);
					host = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '') + x.path+'/';
					domain = x.protocol + '//' + x.hostname + (x.port ? ':'+x.port : '');
					search = x.search ? ('?'+x.search) : "";
					
					GetThemAll.FileSystem.loadText( url, function(rez){ 
					
						if (rez.error) {
							console.log('-----ERROR-----');
							callback( null );
						}
						else {
							
							var list = [];
							
							var lines = rez.response.split('\n');

							if ( lines.length<2 ) return;
							var line0 = lines[0].trim().replace(/\r/g,'');
							if ( line0 != '#EXTM3U' ) return;

							for (var i=0; i<lines.length; i++) {

								var line = lines[i].trim().replace(/\r/g,'');
								if (line=="")    continue;
								if (line[0]=="#") {
									//if( line.indexOf("#EXT") != 0 )   continue;
									//var m = line.match( /^#(EXT[^\s:]+)(?::(.*))/i ); 
									//if(!m)    continue;
								}
								else {
									var u = line;
									if (u.indexOf('http') != 0) {
										if (u.indexOf('/') == 0)  u = domain + u;
										else	u = host + u;
									}
									if (u.indexOf('?') == -1 && search) {
										u = u + search;
									}    
									
									list.push({ url: u,
												filename: fileName + '_' + getFileNumber()	
											 }); 
									
								}	
							}    
							
							callback( list );	
							
						}
					});
				}
			
			}
			
			// -------------------------------------------------------------------
			function load( ){
				
				if (DEBUG) console.log( 'load     queue:', queue );

				if ( queue < MIN_STREAM_DOWNLOAD && blockStartReadTS == 0) {
				
					countTSFiles = file.length;

					blockStartReadTS = 1;
					
					for(var i = 0; i < file.length; i++)     	{
						
						if (isRun && file[i].state==0)      	{
							
							loadStreamFile(file[i].url, file[i].index);
																
							if (queue >= MAX_STREAM_DOWNLOAD)  {  // очеред заполнили
								blockStartReadTS = 0;
								return;
							}	
						}
					}
				}
			}

			// -------------------------------------------------------------
			function IsRequestSuccessful (httpReq) {
				var success = (httpReq.status == 0 || (httpReq.status >= 200 && httpReq.status < 300) || httpReq.status == 304 || httpReq.status == 1223);
				return success;
			}
			function loadStreamFile(url, index)  {
				if (DEBUG) console.log( 'loadStreamFile: '+index, url );
				try	{
					var httpRequest = new XMLHttpRequest(); 
					file[index].req = httpRequest;					
					file[index].state = 1;
					
					httpRequest.open ("GET", url, true);
					httpRequest.ind = index;
					httpRequest.responseType = "arraybuffer"; 
					httpRequest.onreadystatechange = function() {
							if (httpRequest.readyState==4) {
								if (IsRequestSuccessful (httpRequest)) 	{
									var i = httpRequest.ind;
									
									file[i].req = null;
									clearTimeout( file[i].timer );
									file[i].timer = null;
									
									file[i].state = 2;						
									
									if (!isSave) {

										var t = httpRequest.getResponseHeader("Content-Type");

										var b = new Uint8Array(httpRequest.response);
										if (paramsBootstrap) {
											file[i].stream = GetThemAll.Bootstrap.DecodeFragment(b, i);
										}
										else {
											file[i].stream = b;
										}	
										file[i].size = file[i].stream.length;
										
										sizeOfVideo += file[i].size.length;
										countLoad++;
										
										endLoadStreamFile(false);	
									}	
									
								}
								else 	{
									console.log('===============ERROR===================== httpRequest ==========');
									endLoadStreamFile(true);
								}
								queue--;	// очередь скачки уменьшаем (на эту скачку)
								
							}
					};
					
					file[index].timer = setTimeout(function () { 
					
							httpRequest.onreadystatechange = null;
							httpRequest.abort();
							file[index].req = null;
							clearTimeout( file[index].timer );
							file[index].timer = null;
							file[index].state = 3;	

							endLoadStreamFile(true, index);		
							
							queue--;	// очередь скачки уменьшаем (на эту скачку)
							
						}, LOAD_STREAM_TIMEOUT);
					
					
					httpRequest.send();
					
					queue++;		// еще одна закачка
				}
				catch(err)	{
					console.log('===============CATCH===================== httpRequest ==========', err);
					endLoadStreamFile(true);
				}
			}
			
			// -------------------------------------------------------------
			function endLoadStreamFile(error)  {

				if (DEBUG) console.log( 'endLoadStreamFile:  error:',error, ', isSave:',isSave );
				
 				if (isSave) return;
				
				// подсчитаем состояние
				var indexLoad = -1, flagEmpty = false;
				countLoad = startIndex;
				isEnd = true;
				
				for (var j=startIndex; j<file.length; j++) {
					
					if (file[j].state > 1) countLoad++;			// скачано сегментов
					else isEnd = false;
					
					if (file[j].stream) {
						if ( !flagEmpty )  indexLoad = j; 
					}	
					else {
						if (file[j].state == 1) {			// на очереди на чтение, но не прочитано (
							flagEmpty = true;
						}	
					}	
				}
				
				// сообщение	
				funcMessage({'msg': 'progress', 'hash': hash, 'size': sizeOfVideo, 'count': countLoad, 'progress': Math.round( 100 * countLoad / countTSFiles ) });
				
				// дальнейшие действия
				if (isEnd || !isRun ) {
					if (coursePlaylist) {
						setTimeout( function() {
							addPlaylist();
						}, 1000);	
					}
					else {	
						loadEnd();
					}	
					return;
				}
				
				if ( indexLoad != -1 ) {
					loadSave(indexLoad);
					return;
				}
				
				if ( isRun ) {
					load();
				}
 				
			}
			
			// -------------------------------------------------------------
			function loadEnd()  {

				if (DEBUG) console.log('loadEnd', sizeOfVideo);					
				
				var blobs = [];
				
				isSave = true;
				
				for(var j = startIndex; j < file.length; j++)     	{
					if (file[j].stream) {
						blobs.push(file[j].stream);
					}
				}
				
				if ( blobs.length > 0 ) {
					var blob = new Blob(blobs, {type: "video/mp4"});
					GetThemAll.FileSystem.writeFile(file_name, blob, function(){

						funcMessage({'msg': 'finish', 'hash': hash, 'count':countLoad, size: sizeOfVideo});
						funcFinish({ error: false, hash: hash, size: sizeOfVideo, filename: file_name});
										
					})
				}
				else {
					
					funcMessage({'msg': 'finish', 'hash': hash, 'count':countLoad, size: sizeOfVideo});
					funcFinish({ error: false, hash: hash, size: sizeOfVideo, filename: file_name});
				}

			}
			
			// -------------------------------------------------------------
			function loadSave( kk )  {

				if ( kk >= file.length ) kk =file.length;
				
				isSave = true;

				var blobs = [];	
					
				for(var j = startIndex; j <= kk; j++)     	{
					if (file[j].stream) {
						blobs.push(file[j].stream);
						file[j].stream = null;
						file[j].state = 3;
					}
				}
				
				if ( blobs.length > 0 ) {
					var blob = new Blob(blobs, {type: "video/mp4"});
					GetThemAll.FileSystem.writeFile(file_name, blob, function(){
						isSave = false;
						startIndex = kk+1;
						endLoadStreamFile(false);
					})
				}
				else {
					isSave = false;
					endLoadStreamFile(false);
				}
				
				
			}
			
			// ---------------------------
			function createFile(cb) {
				
				var b;
				if (initSector) {
					b = b64toBlob(initSector, 'video/mp4');
				}	
				else {
					b = new Blob([], {type: 'video/mp4'});
				}	
				
				GetThemAll.FileSystem.createFile(file_name, b, cb);
			}
			
			// ---------------------------
			this.playlist = function(list) {

				if (DEBUG) console.log( 'STREAMER.playlist', list.length );
			
				coursePlaylist = list;			

			}	
			
			// -------------------------------------------------------------------
			function addPlaylist( ){

				if (DEBUG) console.log( 'addPlaylist', coursePlaylist.length );
			
				for(var i=0; i<coursePlaylist.length; i++)  {
					
					var f = _find(coursePlaylist[i])

					if ( f == -1 ) {
						file.push({ index: file.length,	
									url: coursePlaylist[i],
									state: 0,
									stream: null,
							   });
					}	
				}
				
				coursePlaylist = null;
				blockStartReadTS = 0;
				
				if (DEBUG) console.log( 'File: ', file.length, file );
				
				load( );

				// ----------------	
				function _find(url) {
					for(var j=0; j<file.length; j++)  {
						if ( file[j].url == url )  return j;
					}
					return -1;
				}	
			}	
			
			// --------------------------------------------------------------------------------
			function getAJAX( url, callback ){
				var ajax = new XMLHttpRequest();
				ajax.open('GET', url, true);
				ajax.setRequestHeader('Cache-Control', 'no-cache');
				ajax.onload = function(){
							var content = this.responseText;
							callback( content );
				}
				ajax.onerror = function(){
					callback( null );
				}
				ajax.send( null );
			}
			
			// -------------------------------------------------------------------
			function b64toBlob(b64Data, contentType, sliceSize)	{
				contentType = contentType || '';
				sliceSize = sliceSize || 512;

				var byteArrays = [];
				for (var offset = 0; offset < b64Data.length; offset += sliceSize) 
				{
					var slice = b64Data.slice(offset, offset + sliceSize);

					var byteNumbers = new Array(slice.length);
					for (var i = 0; i < slice.length; i++) 
					{
						byteNumbers[i] = slice.charCodeAt(i);
					}

					var byteArray = new Uint8Array(byteNumbers);
					byteArrays.push(byteArray);
				}

				var blob = new Blob(byteArrays, {type: contentType});
				return blob;
			}
			
			// ---------------------------
			function getFileNumber() {
				lastFileNumber++;
				var str = '00000' + lastFileNumber.toString();
				return str.substring(str.length - 5, str.length);
			}	
			

		}	

		// ======================================================================
		var StreamConvertWorker = function(hash) {
			
			var funcMessage = null;
			var funcFinish = null;
			
			var fileName = "video";
			var fileExt = "mp4";
			var downloadName = "media";
			var hash = null;

			var audioStream = null;

			var worker_video = null, worker_audio = null;
			var rez_video = null, rez_audio = null;
		

			// ---------------------------
			this.start = function(hh, media, onMessage, onFinish) {

				if (DEBUG) console.log('STREAMER_CONVERT.start', hh, media);
				
				hash = hh;

				funcMessage = onMessage;
				funcFinish = onFinish;
				
				audioStream = media.params.audio_stream;

				fileName = GetThemAll.FileSystem.Unique( );
				
				fileExt = media.ext;
				downloadName = media.downloadName;
				audioStream.downloadName = fileName;
				
				worker_video = new StreamWorker(media.hash);

				worker_audio = new StreamWorker(audioStream.hash);
				
				worker_video.start(media.hash, media,
									function(msg) {         // onMessage
										message('video', msg);
									},
									function(params){
										if ( !params.error ) {
											rez_video = params.filename
											finish('video', params);
										}	
									});

				worker_audio.start(audioStream.hash, audioStream,
									function(msg) {         // onMessage
										message('audio', msg);
									},
									function(params){
										if ( !params.error ) {
											rez_audio = params.filename
											finish('audio', params);
										}	
									});



					  
			};

			// ---------------------------
			this.stop = function() {

				if (DEBUG) console.log( 'STREAMER_CONVERT.stop' );
				
				worker_video.stop();

				worker_audio.stop();
				
			};
			
			// ---------------------------
			function message( type, msg ) {

				//if (DEBUG) console.log( 'STREAMER_CONVERT.message', type, msg );

				if (type == 'video') funcMessage( msg );
				
				
			};
			
			// ---------------------------
			function finish( type, par ) {

				if (DEBUG) console.log( 'STREAMER_CONVERT.finish', type, par );

				if (rez_video && rez_audio) {
					
					funcMessage({'msg': 'finish', 'hash': hash, filename: fileName, error: false });
					
					funcFinish({ error: false, hash: hash, filename: [rez_video, rez_audio]});

				}
			};

		}	
		
	
		// ======================================================================
		var Streamer = function(){		
		
			var workers = {};
			var isRun = false;
			var error;
			
			// -------------------------------------------------------------------
			// параметры:
			//    hash        - видео к скачиванию
			//    callbackFinish   - обработка  завершение
			//    callbackMessage  - отображения хода загрузки
			//
			this.start = function( hash, callbackMessage, callbackFinish ){
				
				var media = GetThemAll.Storage.getDataForHash(hash);
				console.log('Streamer.start', hash, media);
				
				var hash = media.hash;
				var downloadName = media.downloadName;

				if ( media.params && media.params.audio_stream ) {
					workers[hash] = new StreamConvertWorker(hash);
					
					callbackMessage( { msg: "start", hash: hash, status: 'start', size: 0, count: 0 });

					workers[hash].start(hash, media,
										function(msg) {         // onMessage
											callbackMessage(msg);
										},
										function(params){
											
											callbackFinish( { error: params.error,
															  hash: params.hash,
															  filename: [
																{	type: 'video',  
																	dirPath: downloadName,
																	downloadName: 'video',  
																	filename:  params.filename[0]  
																},
																{	type: 'audio',  
																	dirPath: downloadName,
																	downloadName: 'audio',  
																	filename:  params.filename[1]  
																}
															  ] 
															} );
											
											delete workers[hash];
										}); 
					
				}
				else {
					workers[hash] = new StreamWorker(hash);
					
					callbackMessage( { msg: "start", hash: hash, status: 'start', size: 0, count: 0 });

					workers[hash].start(hash, media,
										function(msg) {         // onMessage
											callbackMessage(msg);
										},
										function(params){
											
											callbackFinish( { error: params.error,
															  hash: params.hash,
															  filename: [
																{	type: 'full',  
																	dirPath: null,
																	downloadName: downloadName,  
																	filename:  params.filename  
																},
															  ] 
															} );
											
											delete workers[hash];
										}); 
					
				}	


				return hash;
				
			}
			
			// -------------------------------------------------------------------
			// параметры:
			//  hash        - видео к скачиванию
			//
			this.stop = function( hash, callback ){
				
				console.log('Streamer.stop', hash);
				
				workers[hash].stop();
				
			}
			
			// -------------------------------------------------------------------
			// параметры:
			//  hash        - видео к скачиванию
			//  list        - новый playlist
			//
			this.playlist = function( hash, list ){
				
				console.log('Streamer.playlist', hash, list.length);
				
				if (workers[hash]) {
					workers[hash].playlist(list);
				}
			}
			
			
 			// -------------------------------------------------------------------
			this.remove = function( hash ){

				console.log('Streamer.remove', hash);

				if (workers[hash]) {	
					delete workers[hash];
				}	


			} 
			
			// -------------------------------------------------------------------
			this.getError = function( ){
			
				if(error !== "")
				{
					return error;
				}
				else
				{
					return "No Error!";	
				}
			}

			
			// -------------------------------------------------------------------
		};
		
		this.Streamer = new Streamer();
		
	}).apply(GetThemAll);
}
else{
	GetThemAll.Streamer = chrome.extension.getBackgroundPage().GetThemAll.Streamer;
}

