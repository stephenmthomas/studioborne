if (window == chrome.extension.getBackgroundPage()) {
	
	(function(){
		
		const DEBUG = false;
	
		// ======================================================================
		var ZiperWorker = function() {

			var isRun = false,
				isSave = false,
				isEnd = false;
			
			var funcFinish = null;
			
			var listFiles = null;  
			
			var writer;
			var zipWriter = null;	

			// ---------------------------
			this.start = function(params, onFinish) {

				if (DEBUG) console.log('ZiperWorker.start', params);
				
				isRun = true;
				
				funcFinish = onFinish;
				
				listFiles = params.list;
				
				var removeList = [];
				
				createZipWriter( function() {			

					console.log('---createZipWriter---');

					var j = 0;
					
					GetThemAll.Utils.Async.arrayProcess( listFiles, 
														 function( file, apCallback ){
															removeList.push(file.name);	
															GetThemAll.FileSystem.readFile( file.name, function( data ){

																if (data) {
																	var blob = new Blob([data], {type: file.type});

																	var fn = file.fileName + '.' + file.ext;

																	addFiles(fn, blob, function(){

																		apCallback(true);

																	});	
																}	
																else {
																	apCallback(false);	
																}
															});
														 }, 
														 function(){

															zipFiles(function(url) {
																onFinish(url);
																if (!DEBUG) GetThemAll.FileSystem.removeListFile( removeList );
															});

														 } 
					);
					
				});

			};
			
			// ---------------------------------------------------------------
			function createZipWriter( callback ) {

				console.log('createZipWriter' );
			
				writer = new zip.BlobWriter();

				zip.createWriter(writer, function(writer) {
					zipWriter = writer;
					callback();
				}, onerror, true);
			}
			
			// ---------------------------------------------------------------
			function addFiles(fileName, fileBlob, callback) {
				
				console.log('addFiles', fileName );
				
				if (zipWriter) {
					zipWriter.add(fileName, new zip.BlobReader(fileBlob), function() {
						callback();
					}, onprogress);
				}	
				else {
					console.log('ERROR: addFiles: no zipWriter:', zipWriter);
				} 
				
				function onprogress() {  }
			}

			// ---------------------------------------------------------------
			function zipFiles(callback) {  

				zipWriter.close(function(blob) {
					var blobURL = window.URL.createObjectURL(blob);
					callback(blobURL);
					zipWriter = null;
				});
			
			}
			
			
			// ---------------------------
			this.stop = function() {

				if (DEBUG) console.log( 'ZiperWorker.stop' );
				
				
				
			};



		}
		
		// ======================================================================
		var Ziper = function(){		
		
			var workers = {};
			var error;
			
			var id = 0;
		
			// -------------------------------------------------------------------
			this.start = function( params, callbackFinish ){
				
				id++;
				if (DEBUG) console.log('Ziper.start', id, params);
				
				workers[id] = new ZiperWorker();

				workers[id].start(  params,
									function(rez){
										callbackFinish(rez);
										delete workers[id];
									}); 

				return id;
				
				
			}
			
			// -------------------------------------------------------------------
			this.stop = function( id, callback ){
				
				if (DEBUG) console.log('Ziper.stop', id);
				
				workers[id].stop();
				
			}

		}	
		
		this.Ziper = new Ziper();
		
	}).apply(GetThemAll);
}
else{
	GetThemAll.Ziper = chrome.extension.getBackgroundPage().GetThemAll.Ziper;
}

